/* sync-config.js — إعدادات الربط السحابي لكل متجر (ملف محلي، غير مرفوع على GitHub) */
window.__SYNC_CONFIG = {
    url: 'https://aeoepwrolfckvinygajs.supabase.co',
    anonKey: 'sb_publishable_mNylVDfx8BNFTILWZrmAqg_H8JUZanB',
    storeName: 'DataGris Store',
    storeId: 'dg_nabosallem01'
};