/* sw.js — التخزين المؤقت ليعمل التطبيق أوفلاين */
const CACHE = 'dg-cache-v2';
const ASSETS = ['./', './index.html', './style.css', './script.js', './sync.js', './html5-qrcode.min.js', './xlsx.full.min.js', './manifest.json', './icon-192.png', './icon-512.png', './logo.png'];

self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
    e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
    if(e.request.method !== 'GET') return;
    e.respondWith(
        caches.match(e.request).then((hit) => {
            const net = fetch(e.request).then((res) => {
                if(res && res.status === 200 && res.type === 'basic') {
                    const clone = res.clone();
                    caches.open(CACHE).then((c) => c.put(e.request, clone));
                }
                return res;
            }).catch(() => hit);
            return hit || net;
        })
    );
});