﻿// ================= نظام التنبيهات (Toasts & Modals) =================
function showToast(message, type = 'warning') {
    const container = document.getElementById('toast-container');
    if(!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let iconClass = 'fa-info-circle';
    if(type === 'error') iconClass = 'fa-exclamation-circle';
    if(type === 'success') iconClass = 'fa-check-circle';
    if(type === 'warning') iconClass = 'fa-exclamation-triangle';

    toast.innerHTML = `
        <i class="fas ${iconClass} toast-icon"></i>
        <span class="toast-message">${message}</span>
    `;

    container.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 10);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

function showConfirm(title, message, onConfirm) {
    const modal = document.getElementById('custom-confirm-modal');
    if(!modal) return;
    
    document.getElementById('confirm-title').textContent = title;
    document.getElementById('confirm-message').textContent = message;
    
    modal.classList.remove('hidden');

    const btnYes = document.getElementById('btn-confirm-yes');
    const btnNo = document.getElementById('btn-confirm-no');

    const newBtnYes = btnYes.cloneNode(true);
    const newBtnNo = btnNo.cloneNode(true);
    btnYes.parentNode.replaceChild(newBtnYes, btnYes);
    btnNo.parentNode.replaceChild(newBtnNo, btnNo);

    newBtnYes.addEventListener('click', () => {
        modal.classList.add('hidden');
        onConfirm();
    });

    newBtnNo.addEventListener('click', () => {
        modal.classList.add('hidden');
    });
}

function showConfirmModal(title, message, onConfirm) {
    showConfirm(title, message, onConfirm);
}

// ---- باركود Code128 حقيقي (مشفّر محلياً، قابل للمسح) ----
function code128Bars(text) {
    const BARS = [
        11011001100, 11001101100, 11001100110, 10010011000, 10010001100,
        10001001100, 10011001000, 10011000100, 10001100100, 11001001000,
        11001000100, 11000100100, 10110011100, 10011011100, 10011001110,
        10111001100, 10011101100, 10011100110, 11001110010, 11001011100,
        11001001110, 11011100100, 11001110100, 11101101110, 11101001100,
        11100101100, 11100100110, 11101100100, 11100110100, 11100110010,
        11011011000, 11011000110, 11000110110, 10100011000, 10001011000,
        10001000110, 10110001000, 10001101000, 10001100010, 11010001000,
        11000101000, 11000100010, 10110111000, 10110001110, 10001101110,
        10111011000, 10111000110, 10001110110, 11101110110, 11010001110,
        11000101110, 11011101000, 11011100010, 11011101110, 11101011000,
        11101000110, 11100010110, 11101101000, 11101100010, 11100011010,
        11101111010, 11001000010, 11110001010, 10100110000, 10100001100,
        10010110000, 10010000110, 10000101100, 10000100110, 10110010000,
        10110000100, 10011010000, 10011000010, 10000110100, 10000110010,
        11000010010, 11001010000, 11110111010, 11000010100, 10001111010,
        10100111100, 10010111100, 10010011110, 10111100100, 10011110100,
        10011110010, 11110100100, 11110010100, 11110010010, 11011011110,
        11011110110, 11110110110, 10101111000, 10100011110, 10001011110,
        10111101000, 10111100010, 11110101000, 11110100010, 10111011110,
        10111101110, 11101011110, 11110101110, 11010000100, 11010010000,
        11010011100, 1100011101011
    ];
    const START_B = 104;
    const data = [];
    for(let i = 0; i < text.length; i++) {
        const v = text.charCodeAt(i) - 32;
        if(v < 0 || v > 95) return null;
        data.push(v);
    }
    let checksum = START_B;
    data.forEach((v, i) => checksum += v * (i + 1));
    checksum %= 103;
    let bitString = String(BARS[START_B]);
    data.forEach(c => bitString += String(BARS[c]));
    bitString += String(BARS[checksum]) + String(BARS[106]);
    const widths = [];
    let current = bitString[0], count = 1;
    for(let i = 1; i < bitString.length; i++) {
        if(bitString[i] === current) count++;
        else { widths.push({ bar: current === '1', w: count }); current = bitString[i]; count = 1; }
    }
    widths.push({ bar: current === '1', w: count });
    return widths;
}

function barcodeSVG(text, barWidth, height) {
    const widths = code128Bars(text);
    if(!widths) return '';
    const bw = barWidth || 1;
    const h = height || 40;
    const quiet = 10 * bw;
    const totalW = quiet * 2 + widths.reduce((s, e) => s + e.w, 0) * bw;
    let x = quiet, rects = '';
    widths.forEach(e => {
        if(e.bar) rects += `<rect x="${x.toFixed(2)}" y="0" width="${(e.w * bw).toFixed(2)}" height="${h}" fill="#000"/>`;
        x += e.w * bw;
    });
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalW.toFixed(2)} ${h}" preserveAspectRatio="none"><g>${rects}</g></svg>`;
}

document.addEventListener('DOMContentLoaded', () => {
    // ---- قراءة إعدادات المتجر مبكراً (تُستخدم أثناء التهيئة) ----
    let storeSettings = Object.assign({
        storeName: 'DataGris Store',
        currency: 'ج.م',
        adminPassword: '0',
        defaultDiscount: 0,
        defaultProductCommission: 5,
        onlineOrderCommission: 10,
        targetBonusActive: true,
        targetBonusQty: 60,
        targetBonusAmount: 10,
        lunchTransportActive: true,
        lunchTransportAllowance: 20,
        latePenaltyPerHour: 30,
        extraHourBonus: 30,
        gracePeriodMins: 15,
        notifEnabled: { sale: true, commission: true, salary: true, return: true, withdrawal: true, online: true, warning: true, system: true },
        waTemplates: {
            preparing: 'مرحباً {الاسم} 🌟\nطلبك رقم {رقم_الطلب} جاري الآن تجهيزه 📦\nالمنتجات:\n{المنتج}\nالإجمالي: {السعر}\nشكراً لثقتك بنا 🙏',
            delivering: 'مرحباً {الاسم} 🛵\nطلبك رقم {رقم_الطلب} في الطريق إليك الآن!\nالمنتجات:\n{المنتج}\nالإجمالي: {السعر}\nفوري خلال دقائق 🚀',
            delivered: 'مرحباً {الاسم} ✅\nتم تسليم طلبك رقم {رقم_الطلب} بنجاح!\nنتمنى أن ينال إعجابك، وننتظرك دائماً 🌹',
            customer: 'مرحباً {الاسم} 👋\nنشكرك على تعاملك معنا، يسعدنا خدمتك دائماً.\nلأي استفسار نحن في خدمتك 💬'
        },
        endOfDayPassword: '',
        autoBackupEnabled: false,
        taxEnabled: false,
        taxPercent: 14,
        taxIncluded: false,
        thermalAutoPrint: false
    }, JSON.parse(localStorage.getItem('storeSettings')) || {});

    // ================= منطق الساعة والتاريخ =================
    const currentDateEl = document.getElementById('current-date');
    const currentTimeEl = document.getElementById('current-time');

    function updateClock() {
        const now = new Date();
        const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        currentDateEl.textContent = now.toLocaleDateString('ar-EG', optionsDate);
        
        const optionsTime = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
        currentTimeEl.textContent = now.toLocaleTimeString('ar-EG', optionsTime);
    }
    
    updateClock();
    setInterval(updateClock, 1000);

    // ================= زر تحديث الصفحة =================
    document.getElementById('btn-refresh-page').addEventListener('click', () => {
        window.location.reload();
    });

    // تبديل الوضع الليلي والنهاري
    const themeToggle = document.getElementById('theme-toggle');
    const icon = themeToggle.querySelector('i');
    
    // التحقق من الوضع المحفوظ مسبقاً
    if(localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-theme');
        icon.classList.replace('fa-sun', 'fa-moon');
    }

    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        
        if (document.body.classList.contains('dark-theme')) {
            icon.classList.replace('fa-sun', 'fa-moon');
            localStorage.setItem('theme', 'dark');
        } else {
            icon.classList.replace('fa-moon', 'fa-sun');
            localStorage.setItem('theme', 'light');
        }
    });

    // تفاعل أزرار التصنيفات
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // تفاعل القائمة الجانبية
    const navItems = document.querySelectorAll('.nav-item');
    const appSections = document.querySelectorAll('.app-section');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault(); // لمنع الانتقال الافتراضي للرابط
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // إخفاء كل الأقسام
            appSections.forEach(sec => sec.classList.add('d-none'));
            
            // إظهار القسم المناسب
            const text = item.textContent.trim();
            const directSection = item.getAttribute('data-nav-section');
            const sectionMap = {
                'المبيعات': 'section-sales',
                'لوحة التحكم': 'section-dashboard',
                'الطلبات الأونلاين': 'section-online',
                'الحضور والانصراف': 'section-attendance',
                'الملاحظات': 'section-notes',
                'السلف': 'section-loans',
                'المشتريات': 'section-purchases',
                'مناديب التوصيل': 'section-delivery',
                'قاعدة بيانات العملاء': 'section-customers',
                'المنتجات': 'section-products',
                'الموظفين': 'section-employees',
                'التقارير': 'section-reports',
                'الإحصائيات': 'section-stats',
                'إحصائيات الموظفين': 'section-employee-stats',
                'العمولات': 'section-commissions',
                'السجلات': 'section-records',
                'المرتبات': 'section-salaries',
                'المرتجعات': 'section-returns',
                'الإشعارات': 'section-notifications',
                'المصروفات': 'section-expenses',
                'الإعدادات': 'section-settings'
            };
            let matched = directSection || null;
            if(!matched) {
                Object.keys(sectionMap).forEach(key => {
                    if(text.includes(key)) matched = sectionMap[key];
                });
            }
            if(matched) {
                const sec = document.getElementById(matched);
                if(sec) sec.classList.remove('d-none');

                // تشغيل الرندر الديناميكي عند فتح كل قسم
                if(matched === 'section-dashboard') { renderDashboard(); }
                else if(matched === 'section-online') { renderOnlineOrders(); }
                else if(matched === 'section-employees') { renderEmployees(); }
                else if(matched === 'section-reports') { renderReport(); refreshReportSummary(); }
                else if(matched === 'section-stats') { renderStats(); }
                else if(matched === 'section-employee-stats') { renderEmployeeStats(); }
                else if(matched === 'section-commissions') { renderCommissions(); }
                else if(matched === 'section-records') { renderRecords(); }
                else if(matched === 'section-salaries') { renderSalaries(); }
                else if(matched === 'section-returns') { renderReturns(); }
                else if(matched === 'section-notifications') { renderNotifications(); }
                else if(matched === 'section-expenses') { renderExpenses(); }
                else if(matched === 'section-settings') { loadSettings(); }
            }
        });
    });

    // ================= إنهاء اليوم =================
    function endDayFlow() {
        showConfirm('إنهاء الوردية', 'هل أنت متأكد من إنهاء الوردية والعودة للشاشة الترحيبية؟', () => {
            localStorage.removeItem('shiftStartTime');
            localStorage.removeItem('sessionMode');
            window.location.reload();
        });
    }

    function askPassword(title, message, onSuccess) {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.innerHTML = `
            <div class="modal-card" style="max-width: 380px; text-align: center; width: 100%;">
                <div style="font-size: 46px; color: var(--warning, #f59e0b); margin-bottom: 12px;"><i class="fas fa-lock"></i></div>
                <h3 style="margin-bottom: 8px; font-size: 20px; color: var(--text-main, #111);">${title}</h3>
                <p style="color: var(--text-muted, #666); margin-bottom: 20px; font-size: 14px; line-height: 1.6; font-weight: 600;">${message}</p>
                <input type="password" class="custom-input glass-input" placeholder="كلمة المرور..." style="width: 100%; text-align: center; direction: ltr; margin-bottom: 18px;" id="ask-password-input">
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button class="btn-primary" id="ask-password-ok" style="flex: 1; justify-content: center;">تأكيد</button>
                    <button class="btn-outline" id="ask-password-cancel" style="flex: 1; justify-content: center;">إلغاء</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#ask-password-input');
        const ok = overlay.querySelector('#ask-password-ok');
        const cancel = overlay.querySelector('#ask-password-cancel');
        const close = () => { overlay.remove(); };
        input.focus();
        const submit = () => {
            const typed = String(input.value || '');
            const required = String(storeSettings.endOfDayPassword || '');
            if(typed === required) { close(); onSuccess(); }
            else { showToast('كلمة المرور غير صحيحة', 'error'); input.value = ''; input.focus(); }
        };
        ok.addEventListener('click', submit);
        cancel.addEventListener('click', close);
        input.addEventListener('keydown', (e) => { if(e.key === 'Enter') submit(); });
    }

    document.body.addEventListener('click', (e) => {
        const btnEndDay = e.target.closest('#btn-end-day');
        if(btnEndDay) {
            if(String(storeSettings.endOfDayPassword || '')) {
                askPassword('إنهاء الوردية', 'أدخل كلمة مرور إنهاء اليوم للمتابعة.', () => endDayFlow());
            } else {
                endDayFlow();
            }
        }
    });

    // تأثير بسيط عند الضغط على المنتجات
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('click', () => {
            // تأثير نقرة خفيف
            card.style.transform = 'scale(0.95)';
            setTimeout(() => {
                card.style.transform = 'translateY(-3px)';
            }, 100);
        });
    });

    // ================= منطق الوردية والوقت =================
    const shiftTimerContainer = document.getElementById('shift-timer-container');
    const shiftTimerEl = document.getElementById('shift-timer');
    let timerInterval;

    function updateTimer(startTime) {
        const now = Date.now();
        const diff = Math.floor((now - startTime) / 1000);
        const hours = String(Math.floor(diff / 3600)).padStart(2, '0');
        const minutes = String(Math.floor((diff % 3600) / 60)).padStart(2, '0');
        const seconds = String(diff % 60).padStart(2, '0');
        shiftTimerEl.textContent = `${hours}:${minutes}:${seconds}`;
    }

    function startShiftTimer(startTime) {
        shiftTimerContainer.classList.remove('d-none');
        updateTimer(startTime);
        timerInterval = setInterval(() => updateTimer(startTime), 1000);
    }

    // ================= منطق شاشة الترحيب =================
    const welcomeScreen = document.getElementById('welcome-screen');
    const btnNewDay = document.getElementById('btn-new-day');
    const btnGuest = document.getElementById('btn-guest');

    // التحقق عند تحميل الصفحة من الجلسة المحفوظة
    const savedMode = localStorage.getItem('sessionMode');
    const savedStartTime = localStorage.getItem('shiftStartTime');
    const btnEndDayMain = document.getElementById('btn-end-day');

    if (savedMode === 'new_day' && savedStartTime) {
        window.__appBusy = true;
        welcomeScreen.style.display = 'none'; // إخفاء مباشر بدون حركة لتسريع الدخول
        startShiftTimer(parseInt(savedStartTime));
        if(btnEndDayMain) btnEndDayMain.classList.remove('d-none');
    } else {
        window.__appBusy = false;
        // إظهار الشاشة الترحيبية للزوار أو من لم يبدأ يومه
        welcomeScreen.style.display = 'flex';
        welcomeScreen.classList.remove('hidden');
        if(btnEndDayMain) btnEndDayMain.classList.add('d-none');
    }

    // دالة الدخول للتطبيق
    function enterApplication(mode) {
        window.__appBusy = true;
        // إخفاء شاشة الترحيب بتأثير حركي
        welcomeScreen.classList.add('hidden');
        
        // إزالة الشاشة من الـ DOM بعد انتهاء الحركة
        setTimeout(() => {
            welcomeScreen.style.display = 'none';
        }, 500);

        // حفظ حالة الجلسة
        localStorage.setItem('sessionMode', mode);

        if(mode === 'new_day') {
            console.log('تم الدخول: تسجيل يوم جديد');
            const startTime = Date.now();
            localStorage.setItem('shiftStartTime', startTime);
            startShiftTimer(startTime);
            if(btnEndDayMain) btnEndDayMain.classList.remove('d-none');
        } else if(mode === 'guest') {
            console.log('تم الدخول: كزائر');
            if(btnEndDayMain) btnEndDayMain.classList.add('d-none');
        }
    }

    btnNewDay.addEventListener('click', () => enterApplication('new_day'));
    btnGuest.addEventListener('click', () => enterApplication('guest'));

    // ================= منطق الدخول (مدير / موظف) =================
    const btnShowLogin = document.getElementById('btn-show-login');
    const loginModal = document.getElementById('login-modal');
    const btnCloseModal = loginModal.querySelector('.close-modal');
    const btnLoginSubmit = document.getElementById('btn-login-submit');
    const adminPasswordInput = document.getElementById('admin-password');
    const loginError = document.getElementById('login-error');

    let currentUser = null;

    function applyUserChip() {
        const chip = document.getElementById('user-chip');
        const nameEl = document.getElementById('user-chip-name');
        if(!chip || !nameEl) return;
        const role = currentUser ? (currentUser.type === 'admin' ? 'مدير' : 'موظف') : '';
        nameEl.textContent = currentUser ? `${currentUser.name} (${role})` : '';
        chip.title = currentUser ? `مسجل الدخول: ${currentUser.name}` : '';
    }

    function setUserSession(user) {
        currentUser = user;
        sessionStorage.setItem('dgSession', JSON.stringify(user));
        document.body.classList.add('logged-in');
        applyUserChip();
    }

    function clearUserSession() {
        currentUser = null;
        sessionStorage.removeItem('dgSession');
        document.body.classList.remove('admin-mode');
        document.body.classList.remove('logged-in');
        const sEl = document.getElementById('sales-emp-select');
        if(sEl) sEl.value = '';
        applyUserChip();
    }

    // استعادة الجلسة عند فتح الصفحة
    try {
        const sess = JSON.parse(sessionStorage.getItem('dgSession'));
        if(sess && sess.type === 'admin') {
            document.body.classList.add('admin-mode');
            setUserSession(sess);
        } else if(sess && sess.type === 'employee') {
            setUserSession(sess);
        }
    } catch(e) { /* تجاهل جلسة تالفة */ }

    // إظهار نافذة تسجيل الدخول
    btnShowLogin.addEventListener('click', () => {
        window.__appBusy = true;
        loginModal.classList.remove('hidden');
        adminPasswordInput.value = '';
        loginError.classList.add('hidden');
        setTimeout(() => adminPasswordInput.focus(), 100);
    });

    // إغلاق أي مودال عند الضغط في الخلفية أو زر الإغلاق
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if(e.target === modal) {
                modal.classList.add('hidden');
            }
        });
        const closeBtn = modal.querySelector('.close-modal');
        if(closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        }
    });

    // التحقق من كلمة المرور / رقم الموظف
    function handleLogin() {
        const input = (adminPasswordInput.value || '').trim();
        const adminPass = String(storeSettings.adminPassword != null ? storeSettings.adminPassword : '0');
        const isAdmin = (input === adminPass || input === '0');
        const empMatch = !isAdmin ? employeesLog.find(e => e.pin && String(e.pin).trim() === input) : null;

        if(isAdmin) {
            document.body.classList.add('admin-mode');
            setUserSession({ type: 'admin', name: storeSettings.storeName || 'المدير' });
            loginModal.classList.add('hidden');
            const sElAdmin = document.getElementById('sales-emp-select');
            if(sElAdmin) sElAdmin.value = '';

            navItems.forEach(nav => nav.classList.remove('active'));
            const adminDashboardNav = document.querySelector('.sidebar-nav .nav-item.admin-only');
            if(adminDashboardNav) adminDashboardNav.classList.add('active');

            showToast('مرحباً بك أيها المدير!', 'success');
            addNotification('دخول المدير إلى لوحة التحكم', 'system');
            console.log('تم تسجيل الدخول بصلاحيات المدير بنجاح');
        } else if(empMatch) {
setUserSession({ type: 'employee', empId: empMatch.id, name: empMatch.name });
            loginModal.classList.add('hidden');

            const salesEmpSelLogin = document.getElementById('sales-emp-select');
            if(salesEmpSelLogin && currentUser && currentUser.empId != null) {
                const empOpt = Array.from(salesEmpSelLogin.options).find(o => o.value === String(currentUser.empId));
                if(empOpt) salesEmpSelLogin.value = empOpt.value;
            }
            navItems.forEach(nav => nav.classList.remove('active'));
            const salesNav = Array.from(navItems).find(nav => nav.textContent.includes('المبيعات'));
            if(salesNav) salesNav.classList.add('active');

            showToast(`أهلاً ${empMatch.name}! تم فتح العدّة`, 'success');
            addNotification(`دخول الموظف ${empMatch.name} للوردية`, 'system');
            console.log('تم تسجيل دخول الموظف:', empMatch.name);
        } else {
            loginError.classList.remove('hidden');
            adminPasswordInput.classList.add('error-shake');
            setTimeout(() => adminPasswordInput.classList.remove('error-shake'), 400);
        }
    }

    btnLoginSubmit.addEventListener('click', handleLogin);

    // دعم الضغط على Enter في حقل الباسورد
    adminPasswordInput.addEventListener('keypress', (e) => {
        if(e.key === 'Enter') {
            handleLogin();
        }
    });

    // تسجيل الخروج
    const btnAdminLogout = document.getElementById('btn-admin-logout');
    btnAdminLogout.addEventListener('click', () => {
        window.__appBusy = false;
        clearUserSession();

        navItems.forEach(nav => nav.classList.remove('active'));
        const salesNav = Array.from(navItems).find(nav => nav.textContent.includes('المبيعات'));
        if(salesNav) salesNav.classList.add('active');

        showToast('تم تسجيل الخروج', 'info');
        console.log('تم العودة لوضع الضيف');
    });

    // ================= منطق الحضور والانصراف =================
    const empSelect = document.getElementById('emp-select');
    const btnClockIn = document.getElementById('btn-clock-in');
    const btnClockOut = document.getElementById('btn-clock-out');
    const btnResetLog = document.getElementById('btn-reset-log');
    const attendanceTbody = document.getElementById('attendance-tbody');

    let attendanceLog = JSON.parse(localStorage.getItem('attendanceLog')) || [];

    function saveAttendance() {
        localStorage.setItem('attendanceLog', JSON.stringify(attendanceLog));
    }

    function renderAttendance() {
        if(!attendanceTbody) return;
        attendanceTbody.innerHTML = '';
        
        if(attendanceLog.length === 0) {
            attendanceTbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">لا توجد سجلات حضور حتى الآن</td></tr>';
            return;
        }

        const sortedLog = [...attendanceLog].reverse();

        sortedLog.forEach(record => {
            const tr = document.createElement('tr');
            
            let workHours = '--:--';
            if (record.timeOutMs) {
                const diffMs = record.timeOutMs - record.timeInMs;
                const hours = Math.floor(diffMs / 3600000);
                const minutes = Math.floor((diffMs % 3600000) / 60000);
                workHours = `${hours}س ${minutes}د`;
            }

            const statusHtml = record.status === 'active' 
                ? `<span class="status-badge status-active">حاضر الآن</span>` 
                : `<span class="status-badge" style="background-color: var(--bg-color); color: var(--text-muted);">انصرف</span>`;

            const timeOutHtml = record.timeOut 
                ? `<span class="time-badge out">${record.timeOut}</span>` 
                : `<span class="time-badge out">--:--</span>`;

            const avatarHtml = record.photo
                ? `<div class="emp-avatar" style="background: transparent; box-shadow: none; border: 2px solid rgba(var(--primary-rgb), 0.3);"><img src="${record.photo}" alt="" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;"></div>`
                : `<div class="emp-avatar">${record.empName.charAt(0)}</div>`;

            tr.innerHTML = `
                <td>
                    <div class="emp-cell">
                        ${avatarHtml}
                        <span class="emp-name">${record.empName}</span>
                    </div>
                </td>
                <td>${record.date}</td>
                <td><span class="time-badge in">${record.timeIn}</span></td>
                <td>${timeOutHtml}</td>
                <td style="font-weight: 700;">${workHours}</td>
                <td>${statusHtml}</td>
            `;
            attendanceTbody.appendChild(tr);
        });
    }

    function getCurrentTimeString() {
        return new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: true });
    }

    function getCurrentDateString() {
        return new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    if(btnClockIn) {
        btnClockIn.addEventListener('click', () => {
            const empId = empSelect.value;
            if(!empId) {
                showToast('الرجاء اختيار الموظف أولاً', 'error');
                return;
            }
            
            const empName = empSelect.options[empSelect.selectedIndex].text;
            
            const alreadyIn = attendanceLog.find(r => r.empId === empId && r.status === 'active');
            if(alreadyIn) {
                showToast('هذا الموظف مسجل كحاضر مسبقاً ولم يتم تسجيل انصرافه!', 'warning');
                return;
            }

            const newRecord = {
                id: Date.now(),
                empId: empId,
                empName: empName,
                photo: (employeesLog.find(e => e.id == empId) || {}).photo || '',
                date: getCurrentDateString(),
                timeIn: getCurrentTimeString(),
                timeInMs: Date.now(),
                timeOut: null,
                timeOutMs: null,
                status: 'active'
            };

            attendanceLog.push(newRecord);
            saveAttendance();
            renderAttendance();
            showToast(`تم تسجيل حضور ${empName}`, 'success');
            empSelect.value = '';
        });
    }

    if(btnClockOut) {
        btnClockOut.addEventListener('click', () => {
            const empId = empSelect.value;
            if(!empId) {
                showToast('الرجاء اختيار الموظف أولاً', 'error');
                return;
            }

            const activeRecord = attendanceLog.find(r => r.empId === empId && r.status === 'active');
            if(!activeRecord) {
                showToast('لا يوجد تسجيل حضور نشط لهذا الموظف لتسجيل انصرافه!', 'warning');
                return;
            }

            activeRecord.timeOut = getCurrentTimeString();
            activeRecord.timeOutMs = Date.now();
            activeRecord.status = 'completed';

            saveAttendance();
            renderAttendance();
            showToast(`تم تسجيل انصراف ${activeRecord.empName}`, 'success');
            empSelect.value = '';
        });
    }

    if(btnResetLog) {
        btnResetLog.addEventListener('click', () => {
            showConfirm('تصفير السجل', 'هل أنت متأكد من رغبتك في تصفير السجل ومسح كافة الحركات؟ لا يمكن التراجع عن هذا الإجراء.', () => {
                attendanceLog = [];
                saveAttendance();
                renderAttendance();
                showToast('تم تصفير السجل بنجاح', 'success');
            });
        });
    }

    // التشغيل المبدئي للجدول
    renderAttendance();

    // ================= منطق المبيعات (نقطة البيع - POS) =================
    let currentInvoice = [];
    const posItems = document.querySelectorAll('.pos-item');
    const invoiceTbody = document.getElementById('invoice-tbody');
    const invoiceSubtotal = document.getElementById('invoice-subtotal');
    const invoiceTotal = document.getElementById('invoice-total');
    const invoiceDiscount = document.getElementById('invoice-discount');
    const btnClearInvoice = document.getElementById('btn-clear-invoice');
    const btnCheckout = document.getElementById('btn-checkout');
    const btnExchange = document.getElementById('btn-exchange');
    const salesEmpSelect = document.getElementById('sales-emp-select');

    function renderInvoice() {
        if (currentInvoice.length === 0) {
            invoiceTbody.innerHTML = `
                <tr id="empty-invoice-row">
                    <td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                        <i class="fas fa-shopping-cart" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                        الفاتورة فارغة، اضغط على المنتجات لإضافتها
                    </td>
                </tr>
            `;
            updateInvoiceTotals();
            return;
        }

        invoiceTbody.innerHTML = '';
        currentInvoice.forEach(item => {
            const tr = document.createElement('tr');
            const total = item.price * item.quantity;
            tr.innerHTML = `
                <td style="font-weight: 600;">${item.name}</td>
                <td style="color: var(--primary);">${fmt(item.price)}</td>
                <td style="text-align: center;">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                        <button class="btn-icon-only btn-decrease" data-id="${item.id}" style="width: 24px; height: 24px; border-radius: 4px; background: var(--bg-color); border: 1px solid var(--border-color); cursor: pointer;"><i class="fas fa-minus" style="font-size: 10px;"></i></button>
                        <span style="font-weight: bold; width: 20px;">${item.quantity}</span>
                        <button class="btn-icon-only btn-increase" data-id="${item.id}" style="width: 24px; height: 24px; border-radius: 4px; background: var(--bg-color); border: 1px solid var(--border-color); cursor: pointer;"><i class="fas fa-plus" style="font-size: 10px;"></i></button>
                    </div>
                </td>
                <td style="font-weight: bold;">${fmt(total)}</td>
                <td>
                    <button class="btn-icon-only btn-remove-item" data-id="${item.id}" style="color: var(--danger); background: transparent; border: none; cursor: pointer;">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            invoiceTbody.appendChild(tr);
        });

        // إضافة مستمعي الأحداث لأزرار الكمية والحذف
        document.querySelectorAll('.btn-increase').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.getAttribute('data-id');
                const item = currentInvoice.find(i => i.id === id);
                if(item) { item.quantity++; renderInvoice(); }
            });
        });

        document.querySelectorAll('.btn-decrease').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.getAttribute('data-id');
                const item = currentInvoice.find(i => i.id === id);
                if(item && item.quantity > 1) { 
                    item.quantity--; 
                    renderInvoice(); 
                } else if(item && item.quantity === 1) {
                    currentInvoice = currentInvoice.filter(i => i.id !== id);
                    renderInvoice();
                }
            });
        });

        document.querySelectorAll('.btn-remove-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.getAttribute('data-id');
                currentInvoice = currentInvoice.filter(i => i.id !== id);
                renderInvoice();
            });
        });

        updateInvoiceTotals();
    }

    function updateInvoiceTotals() {
        let subtotal = 0;
        currentInvoice.forEach(item => {
            subtotal += item.price * item.quantity;
        });

        let discount = parseFloat(invoiceDiscount.value) || 0;
        const base = Math.max(subtotal - discount, 0);

        const taxEnabled = storeSettings.taxEnabled !== false;
        const taxPct = Number(storeSettings.taxPercent) || 0;
        const taxIncluded = storeSettings.taxIncluded === true;

        let taxAmount = 0;
        let total = base;

        const taxLine = document.getElementById('invoice-tax-line');
        const taxAmountEl = document.getElementById('invoice-tax-amount');
        if(taxEnabled && taxPct > 0) {
            if(taxIncluded) {
                taxAmount = base - (base / (1 + taxPct / 100));
                if(taxLine && taxAmountEl) {
                    taxLine.style.display = 'flex';
                    taxAmountEl.textContent = `${fmt(taxAmount)} (شامل ${taxPct}%)`;
                    taxAmountEl.style.color = 'var(--text-muted)';
                }
            } else {
                taxAmount = base * taxPct / 100;
                total = base + taxAmount;
                if(taxLine && taxAmountEl) {
                    taxLine.style.display = 'flex';
                    taxAmountEl.textContent = `+${fmt(taxAmount)}`;
                    taxAmountEl.style.color = 'var(--primary)';
                }
            }
        } else if(taxLine) {
            taxLine.style.display = 'none';
        }

        let profit = currentInvoice.reduce((s, i) => s + ((Number(i.price) || 0) - (Number(i.cost) || 0)) * (i.quantity || 0), 0);
        profit = profit - discount;
        const profitLine = document.getElementById('invoice-profit-line');
        const profitAmountEl = document.getElementById('invoice-profit-amount');
        if(profitLine && profitAmountEl) {
            if(currentInvoice.some(i => (Number(i.cost) || 0) > 0)) {
                profitLine.style.display = 'flex';
                profitAmountEl.textContent = `+${fmt(profit)}`;
            } else {
                profitLine.style.display = 'none';
            }
        }

        invoiceSubtotal.textContent = fmt(subtotal);
        invoiceTotal.textContent = fmt(total);
    }

    // عند الضغط على منتج في القائمة
    if(posItems) {
        posItems.forEach(itemCard => {
            itemCard.addEventListener('click', () => {
                const id = itemCard.getAttribute('data-id');
                const name = itemCard.getAttribute('data-name');
                const price = parseFloat(itemCard.getAttribute('data-price'));

                const existingItem = currentInvoice.find(i => i.id === id);
                if(existingItem) {
                    existingItem.quantity++;
                } else {
                    currentInvoice.push({
                        id: id,
                        name: name,
                        price: price,
                        quantity: 1
                    });
                }
                renderInvoice();
            });
        });
    }

    // تحديث الإجمالي عند تغيير الخصم
    if(invoiceDiscount) {
        invoiceDiscount.addEventListener('input', updateInvoiceTotals);
    }

    // تفريغ الفاتورة
    if(btnClearInvoice) {
        btnClearInvoice.addEventListener('click', () => {
            if(currentInvoice.length === 0) return;
            showConfirm('تفريغ الفاتورة', 'هل أنت متأكد من مسح كافة المنتجات من الفاتورة الحالية؟', () => {
                currentInvoice = [];
                invoiceDiscount.value = 0;
                renderInvoice();
            });
        });
    }

    // ================= سجل المبيعات =================
    let salesLog = JSON.parse(localStorage.getItem('salesLog')) || [];
    const salesHistoryTbody = document.getElementById('sales-history-tbody');

    function saveSales() {
        localStorage.setItem('salesLog', JSON.stringify(salesLog));
    }

    function renderSalesLog() {
        if(!salesHistoryTbody) return;
        
        if(salesLog.length === 0) {
            salesHistoryTbody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align:center; padding:20px; color:var(--text-muted);">
                        لا توجد مبيعات مسجلة حتى الآن لهذا اليوم.
                    </td>
                </tr>
            `;
            return;
        }

        salesHistoryTbody.innerHTML = '';
        // نعرض الأحدث أولاً
        [...salesLog].reverse().forEach(sale => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight: bold; color: var(--primary);">#${sale.id}</td>
                <td>${sale.empName}</td>
                <td>${sale.description}</td>
                <td>${sale.totalQty}</td>
                <td style="font-weight: bold;">${fmt(sale.totalAmount)}</td>
                <td>${sale.time}</td>
                <td><span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">مكتمل</span></td>
                <td>
                    <div style="display:flex; justify-content:center; gap:8px;">
                        <button class="btn-icon-only" title="معاينة الفاتورة قبل الطباعة" onclick="window.printInvoice(${sale.id}, true)"><i class="fas fa-eye"></i></button>
                        <button class="btn-icon-only" title="طباعة الفاتورة A4" onclick="window.printInvoice(${sale.id})"><i class="fas fa-file-lines"></i></button>
                        <button class="btn-icon-only" title="طباعة حرارية 58مم" onclick="window.printThermalSale(${sale.id})"><i class="fas fa-print"></i></button>
                    </div>
                </td>
            `;
            salesHistoryTbody.appendChild(tr);
        });
    }

    // ================= طباعة الفاتورة =================
    window.printInvoice = function(id, preview) {
        const sale = salesLog.find(s => s.id === id);
        if(!sale) { showToast('الفاتورة غير موجودة', 'error'); return; }

        let items;
        if(sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
            items = sale.items;
        } else {
            items = String(sale.description || '').split('،').filter(Boolean).map(part => {
                const m = part.match(/^(.*?)\s*\((\d+)\)\s*$/);
                const qty = m ? parseInt(m[2]) : 1;
                const name = m ? m[1].trim() : part.trim();
                return { name, price: Math.round((sale.totalAmount / Math.max(sale.totalQty || 1, 1)) * 100) / 100, quantity: qty };
            });
        }

        const discount = sale.discount || 0;
        const subtotal = sale.subtotal || items.reduce((s, it) => s + (it.price * it.quantity), 0);
        const taxPct = sale.taxPercent || 0;
        const taxAmt = sale.taxAmount || 0;
        const taxIncluded = sale.taxIncluded === true;
        let finalTotal = sale.totalAmount;
        if(sale.discount === undefined) finalTotal = Math.max(subtotal - discount, 0);

        const itemRows = items.map(it => `
            <tr>
                <td style="font-weight: 600;">${it.name}</td>
                <td style="text-align:center;">${it.quantity}</td>
                <td style="text-align:left;">${fmt(it.price)}</td>
                <td style="text-align:left; font-weight:700; color:#0f2440;">${fmt(it.price * it.quantity)}</td>
            </tr>`).join('');

        const date = sale.date || new Date().toLocaleDateString('ar-EG');
        const storeName = (storeSettings.storeName || 'DataGris Store').trim();
        const initial = storeName.charAt(0).toUpperCase() || 'D';
        const payLabels = { cash: 'كاش', card: 'شبكة / كارت', wallet: 'محفظة', credit: 'آجل (مديونية)' };
        const payLabel = payLabels[sale.paymentMethod] || 'كاش';

        const win = window.open('', '_blank', 'width=460,height=700');
        if(!win) { showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'error'); return; }

        win.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>فاتورة #${sale.id}</title>
                <style>
                    * { box-sizing: border-box; margin: 0; padding: 0; }
                    body { font-family: 'Segoe UI', 'Cairo', Tahoma, sans-serif; background: #eef1f6; padding: 24px; color: #1e293b; }
                    .receipt { max-width: 430px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 12px 32px rgba(15, 36, 64, 0.18); }
                    .header { background: linear-gradient(135deg, #0f2440, #1e3a5f); color: #fff; padding: 26px 18px 24px; text-align: center; position: relative; }
                    .header::after { content: ''; position: absolute; bottom: 0; right: 0; left: 0; height: 4px; background: linear-gradient(90deg, #e8b460, #f7c977, #e8b460); }
                    .logo { width: 64px; height: 64px; border-radius: 50%; background: linear-gradient(135deg, #e8b460, #f7c977); color: #0f2440; font-weight: 900; font-size: 32px; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; box-shadow: 0 6px 14px rgba(0,0,0,0.25); }
                    .store-name { font-size: 23px; font-weight: 800; letter-spacing: 0.3px; }
                    .store-tag { font-size: 13px; opacity: 0.85; margin-top: 5px; }
                    .meta { padding: 18px 20px; border-bottom: 1px dashed #cbd5e1; font-size: 14.5px; color: #475569; }
                    .meta table { width: 100%; border-collapse: collapse; }
                    .meta td { padding: 5px 0; }
                    .meta td:last-child { text-align: left; font-weight: 700; color: #0f2440; }
                    .invoice-title { text-align: center; color: #0f2440; font-size: 15px; font-weight: 800; margin: 18px 0 10px; }
                    .invoice-title span { display: inline-block; background: #f8fafc; border: 1px solid #e2e8f0; border-right: 4px solid #e8b460; padding: 7px 18px; border-radius: 8px; }
                    .items { padding: 0 20px 16px; }
                    table.items-table { width: 100%; border-collapse: collapse; font-size: 14px; }
                    .items-table th { background: #f8fafc; color: #0f2440; font-size: 13px; padding: 10px 7px; border-bottom: 2px solid #e8b460; }
                    .items-table td { padding: 9px 7px; border-bottom: 1px solid #f1f5f9; font-size: 13.5px; }
                    .totals { padding: 8px 20px 0; font-size: 15px; }
                    .totals table { width: 100%; border-collapse: collapse; }
                    .totals td { padding: 6px 0; color: #475569; }
                    .totals td.amount { font-weight: 700; color: #0f2440; }
                    .grand-row td { padding-top: 12px; }
                    .grand-row td.amount { color: #b45309; font-size: 21px; font-weight: 900; }
                    .grand-divider { border-top: 2px dashed #cbd5e1; margin-top: 8px; }
                    .footer { text-align: center; padding: 16px 20px 22px; font-size: 13px; color: #94a3b8; }
                    .footer .thanks { color: #0f2440; font-weight: 800; margin-bottom: 6px; font-size: 15px; }
                    .footer .divider { border-top: 1px dashed #e2e8f0; margin: 10px 0; }
                    .bwrap { text-align: center; margin: 12px 0 6px; }
                    .bwrap svg { height: 46px; display: block; margin: 0 auto; }
                    .bcode-text { font-size: 11.5px; color: #64748b; letter-spacing: 1.5px; margin-top: 4px; direction: ltr; }
                    @media print {
                        body { background: #fff; padding: 0; }
                        .receipt { box-shadow: none; border-radius: 0; max-width: 100%; }
                    }
                </style>
            </head>
            <body>
                <div class="receipt">
                    <div class="header">
                        <div class="logo">${initial}</div>
                        <div class="store-name">${storeName}</div>
                        <div class="store-tag">فاتورة مبيعات</div>
                    </div>
                    <div class="meta">
                        <table>
                            <tr><td>رقم الفاتورة</td><td>#${sale.id}</td></tr>
                            <tr><td>التاريخ</td><td>${date}</td></tr>
                            <tr><td>الوقت</td><td>${sale.time || ''}</td></tr>
                            <tr><td>الموظف</td><td>${sale.empName || '-'}</td></tr>
                            <tr><td>العميل</td><td>${sale.customer || '-'}</td></tr>
                            <tr><td>طريقة الدفع</td><td>${payLabel}</td></tr>
                        </table>
                    </div>
                    <div class="invoice-title"><span>تفاصيل الفاتورة</span></div>
                    <div class="items">
                        <table class="items-table">
                            <thead><tr><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>
                            <tbody>${itemRows}</tbody>
                        </table>
                    </div>
                    <div class="totals">
                        <table>
                            <tr><td>الإجمالي الفرعي</td><td class="amount" style="text-align:left;">${fmt(subtotal)}</td></tr>
                            <tr><td>الخصم</td><td class="amount" style="text-align:left;">${fmt(discount)}</td></tr>
                            ${taxPct > 0 ? `<tr><td>الضريبة (${taxIncluded ? 'مضمنة في الإجمالي ' + taxPct + '%' : taxPct + '%'})</td><td class="amount" style="text-align:left;">${fmt(taxAmt)}${taxIncluded ? ' (داخلة)' : ''}</td></tr>` : ''}
                            <tr class="grand-row"><td style="color:#0f2440; font-size:16px; font-weight:800;">الإجمالي النهائي</td><td class="amount" style="text-align:left;">${fmt(finalTotal)}</td></tr>
                        </table>
                    </div>
                    <div class="footer">
                        <div class="grand-divider"></div>
                        <div class="bwrap">${barcodeSVG('INV-' + sale.id, 1.4, 46)}</div>
                        <div class="bcode-text">INV-${sale.id}</div>
                        <div class="divider"></div>
                        <div class="thanks">شكراً لزيارتكم</div>
                        <div>نتمنى لكم يوماً سعيداً • ${storeName}</div>
                    </div>
                </div>
                <script>window.onload = function(){ window.focus(); if(!${preview ? 'true' : 'false'}) window.print(); }<\/script>
                ${preview ? `<div style="position:fixed; bottom:18px; right:50%; transform:translateX(50%); z-index:99;">
                    <button onclick="window.print()" style="background:#0f2440; color:#fff; border:none; padding:12px 26px; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; box-shadow:0 6px 18px rgba(0,0,0,0.25);"><i class="fas fa-print"></i> طباعة</button>
                </div>` : ''}
            </body>
            </html>`);
        win.document.close();
    };

    // طباعة حرارية 58مم
    window.printThermalSale = function(id) {
        const sale = salesLog.find(s => s.id === id);
        if(!sale) { showToast('الفاتورة غير موجودة', 'error'); return; }

        let items;
        if(sale.items && Array.isArray(sale.items) && sale.items.length > 0) {
            items = sale.items;
        } else {
            items = String(sale.description || '').split('،').filter(Boolean).map(part => {
                const m = part.match(/^(.*?)\s*\((\d+)\)\s*$/);
                const qty = m ? parseInt(m[2]) : 1;
                const name = m ? m[1].trim() : part.trim();
                return { name, price: Math.round((sale.totalAmount / Math.max(sale.totalQty || 1, 1)) * 100) / 100, quantity: qty };
            });
        }

        const discount = sale.discount || 0;
        const subtotal = sale.subtotal || items.reduce((s, it) => s + (it.price * it.quantity), 0);
        const taxPct = sale.taxPercent || 0;
        const taxAmt = sale.taxAmount || 0;
        const taxIncluded = sale.taxIncluded === true;
        const finalTotal = sale.totalAmount;

        const storeName = (storeSettings.storeName || 'DataGris Store').trim();
        const date = sale.date || new Date().toLocaleDateString('ar-EG');
        const f = n => (isNaN(Number(n)) ? 0 : Number(n)).toFixed(2);
        const payLabelsT = { cash: 'كاش', card: 'شبكة/كارت', wallet: 'محفظة', credit: 'آجل' };
        const payLabelT = payLabelsT[sale.paymentMethod] || 'كاش';

        const itemRows = items.map(it => `
            <div class="l">${it.name}</div>
            <div class="r">${it.quantity} × ${f(it.price)} = ${f(it.price * it.quantity)}</div>`).join('');

        const win = window.open('', '_blank', 'width=300,height=600');
        if(!win) { showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'error'); return; }

        win.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>فاتورة حرارية #${sale.id}</title>
                <style>
                    * { box-sizing: border-box; margin: 0; padding: 0; }
                    @page { size: 58mm auto; margin: 0; }
                    body { font-family: 'Courier New', Tahoma, monospace; font-size: 12px; color: #000; width: 58mm; padding: 4mm 3mm; }
                    .center { text-align: center; }
                    .store { font-size: 16px; font-weight: 900; text-align: center; margin-bottom: 2px; }
                    .tag { text-align: center; font-size: 11px; margin-bottom: 2px; }
                    .divider { border-top: 1px dashed #000; margin: 4px 0; }
                    .row { display: flex; justify-content: space-between; align-items: center; }
                    .l { font-weight: 700; }
                    .r { text-align: left; direction: ltr; }
                    .items { margin: 4px 0; }
                    .total { font-size: 15px; font-weight: 900; }
                    .bwrap { text-align: center; margin: 5px 0 2px; }
                    .bwrap svg { width: 44mm; height: auto; display: block; margin: 0 auto; }
                    .bcode-text { font-size: 10px; text-align: center; direction: ltr; letter-spacing: 1px; }
                    .thanks { text-align: center; margin-top: 6px; font-weight: 700; }
                    @media print { body { padding: 2mm; width: 58mm; } }
                </style>
            </head>
            <body>
                <div class="store">${storeName}</div>
                <div class="tag">فاتورة مبيعات</div>
                <div class="divider"></div>
                <div class="row"><span>رقم الفاتورة</span><span>#${sale.id}</span></div>
                <div class="row"><span>التاريخ</span><span>${date} ${sale.time || ''}</span></div>
                <div class="row"><span>الموظف</span><span>${sale.empName || '-'}</span></div>
                ${sale.customer ? `<div class="row"><span>العميل</span><span>${sale.customer}</span></div>` : ''}
                <div class="row"><span>الدفع</span><span>${payLabelT}</span></div>
                <div class="divider"></div>
                <div class="items">${itemRows}</div>
                <div class="divider"></div>
                <div class="row"><span>الإجمالي الفرعي</span><span>${f(subtotal)}</span></div>
                ${discount > 0 ? `<div class="row"><span>الخصم</span><span>${f(discount)}</span></div>` : ''}
                ${taxPct > 0 ? `<div class="row"><span>الضريبة ${taxIncluded ? '(مضمنة)' : '(' + taxPct + '%)'}</span><span>${f(taxAmt)}</span></div>` : ''}
                <div class="row total"><span>الإجمالي</span><span>${f(finalTotal)}</span></div>
                <div class="bwrap">${barcodeSVG('INV-' + sale.id, 1.2, 38)}</div>
                <div class="bcode-text">INV-${sale.id}</div>
                <div class="divider"></div>
                <div class="thanks">شكراً لزيارتكم 🌹</div>
                <div class="center">${storeName}</div>
                <script>window.onload = function(){ window.focus(); window.print(); }<\/script>
            </body>
            </html>`);
        win.document.close();
    };

    // إتمام البيع
    if(btnCheckout) {
        btnCheckout.addEventListener('click', () => {
            if(currentInvoice.length === 0) {
                showToast('الفاتورة فارغة!', 'error');
                return;
            }
            if(!salesEmpSelect.value && currentUser && currentUser.type === 'employee') {
                showToast('الرجاء اختيار الموظف أولاً قبل إتمام البيع', 'error');
                return;
            }

            const posPaymentEl = document.getElementById('pos-payment-method');
            const paymentMethod = posPaymentEl ? posPaymentEl.value : 'cash';
            if(paymentMethod === 'credit') {
                const cNameEl = document.getElementById('pos-customer-name');
                if(!cNameEl || !cNameEl.value.trim()){
                    showToast('للبيع بالآجل يجب كتابة اسم العميل أولاً', 'error');
                    return;
                }
            }

            let empName = 'بدون موظف';
            if(salesEmpSelect.value) empName = salesEmpSelect.options[salesEmpSelect.selectedIndex].text;
            else if(currentUser && currentUser.type === 'admin') empName = 'المدير';
            else if(currentUser && currentUser.name) empName = currentUser.name;
            
            let totalQty = 0;
            let descriptionItems = [];
            currentInvoice.forEach(item => {
                totalQty += item.quantity;
                descriptionItems.push(`${item.name} (${item.quantity})`);
            });

            const discount = parseFloat(invoiceDiscount.value) || 0;
            let subtotal = 0;
            currentInvoice.forEach(i => subtotal += (i.price * i.quantity));
            const taxEnabled = storeSettings.taxEnabled !== false;
            const taxPct = Number(storeSettings.taxPercent) || 0;
            const taxIncluded = storeSettings.taxIncluded === true;
            const base = Math.max(subtotal - discount, 0);
            let taxAmount = 0;
            let finalTotal = base;
            if(taxEnabled && taxPct > 0) {
                if(taxIncluded) {
                    taxAmount = base - (base / (1 + taxPct / 100));
                } else {
                    taxAmount = base * taxPct / 100;
                    finalTotal = base + taxAmount;
                }
            }
            if(finalTotal < 0) finalTotal = 0;

            let nextId = salesLog.length > 0 ? salesLog[salesLog.length - 1].id + 1 : 1;

            let grossProfit = 0;
            currentInvoice.forEach(i => grossProfit += ((Number(i.price) || 0) - (Number(i.cost) || 0)) * (i.quantity || 0));
            grossProfit = Math.max(grossProfit - discount, 0);

            const newSale = {
                id: nextId,
                empName: empName,
                description: descriptionItems.join('، '),
                totalQty: totalQty,
                totalAmount: finalTotal,
                discount: discount,
                subtotal: subtotal,
                taxPercent: taxEnabled ? taxPct : 0,
                taxAmount: taxEnabled ? taxAmount : 0,
                taxIncluded: taxIncluded,
                paymentMethod: paymentMethod,
                grossProfit: grossProfit,
                items: currentInvoice.map(i => ({ name: i.name, price: i.price, cost: Number(i.cost) || 0, quantity: i.quantity })),
                date: new Date().toLocaleDateString('ar-EG'),
                time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
            };

            // Update Customer if filled
            const posCustomerName = document.getElementById('pos-customer-name');
            const posCustomerPhone = document.getElementById('pos-customer-phone');
            
            if(posCustomerName && posCustomerName.value.trim() !== "") {
                const cName = posCustomerName.value.trim();
                const cPhone = posCustomerPhone ? posCustomerPhone.value.trim() : "";
                
                let existingCustomer = window.customersLog.find(c => c.name === cName);
                
                if(existingCustomer) {
                    existingCustomer.purchasesCount += 1;
                    existingCustomer.totalSpent += finalTotal;
                    existingCustomer.lastPurchase = new Date().toLocaleDateString('ar-EG');
                    if(cPhone && !existingCustomer.phone) existingCustomer.phone = cPhone;
                    if(paymentMethod === 'credit') existingCustomer.balance = (Number(existingCustomer.balance) || 0) + finalTotal;
                } else {
                    const newCustomer = {
                        name: cName,
                        phone: cPhone,
                        address: '',
                        balance: paymentMethod === 'credit' ? finalTotal : 0,
                        purchasesCount: 1,
                        totalSpent: finalTotal,
                        lastPurchase: new Date().toLocaleDateString('ar-EG')
                    };
                    window.customersLog.push(newCustomer);
                }
                
                window.saveCustomersToLocal();
                window.renderCustomers();
                newSale.customer = cName;
            }

            const targetActive = storeSettings.targetBonusActive !== false;
            const targetQty = Number(storeSettings.targetBonusQty) || 60;
            let justHitTarget = false;
            if(targetActive && empName && empName !== 'مجهول') {
                const dayKey = normEmpDate(newSale.date);
                const beforePieces = salesLog.filter(s => (s.empName === empName) && normEmpDate(s.date) === dayKey).reduce((s, x) => s + (x.totalQty || 0), 0);
                const afterPieces = beforePieces + (newSale.totalQty || 0);
                if(beforePieces < targetQty && afterPieces >= targetQty) justHitTarget = true;
            }

            salesLog.push(newSale);
            saveSales();
            renderSalesLog();

            if(justHitTarget) {
                addNotification(`🎯 ${empName} حقق هدف المبيعات اليومي (${targetQty} قطعة)!`, 'commission');
            } else {
                addNotification(`بيع جديد #${nextId} لـ ${empName} بقيمة ${fmt(finalTotal)}`, 'sale');
            }

            showToast('تم إتمام عملية البيع بنجاح!', 'success');
            if(storeSettings.thermalAutoPrint && typeof window.printThermalSale === 'function') {
                setTimeout(() => { try { window.printThermalSale(nextId); } catch(err) {} }, 350);
            }
            currentInvoice = [];
            invoiceDiscount.value = 0;
            salesEmpSelect.value = '';
            if(currentUser && currentUser.type === 'employee' && currentUser.empId != null) {
                const empOpt2 = Array.from(salesEmpSelect.options).find(o => o.value === String(currentUser.empId));
                if(empOpt2) salesEmpSelect.value = empOpt2.value;
            }
            if(posCustomerName) posCustomerName.value = '';
            if(posCustomerPhone) posCustomerPhone.value = '';
            const posBarcodeInput = document.getElementById('pos-barcode-input');
            if(posBarcodeInput) posBarcodeInput.value = '';
            if(posPaymentEl) posPaymentEl.value = 'cash';
            renderInvoice();
        });
    }

    const posBarcodeInput = document.getElementById('pos-barcode-input');
    if(posBarcodeInput) {
        posBarcodeInput.addEventListener('keydown', (e) => {
            if(e.key !== 'Enter') return;
            const code = posBarcodeInput.value.trim();
            if(!code) return;
            const prod = window.productsLog.find(p => p.barcode && String(p.barcode).trim() === code);
            if(prod) {
                posAddProduct(prod);
                posBarcodeInput.value = '';
                showToast(`تم إضافة " ${prod.name} "`, 'success');
            } else {
                showToast('لا يوجد منتج بهذا الباركود', 'error');
                posBarcodeInput.select();
            }
        });
    }

    // ماسح الباركود بالكاميرا
    const btnOpenScanner = document.getElementById('btn-open-scanner');
    const scannerModal = document.getElementById('scanner-modal');
    const scannerRegion = document.getElementById('scanner-region');
    const scannerStatus = document.getElementById('scanner-status');
    let html5Scanner = null;

    function stopScanner() {
        if(html5Scanner) {
            try {
                if(html5Scanner.isScanning) {
                    html5Scanner.stop().then(() => { try { html5Scanner.clear(); } catch(e) {} }).catch(() => {});
                }
            } catch(e) {}
        }
        html5Scanner = null;
    }

    function closeScannerModal() {
        stopScanner();
        if(scannerModal) scannerModal.classList.add('hidden');
    }

    if(btnOpenScanner && scannerModal) {
        btnOpenScanner.addEventListener('click', async () => {
            scannerModal.classList.remove('hidden');
            if(scannerRegion) scannerRegion.innerHTML = '';
            if(scannerStatus) scannerStatus.textContent = 'بانتظار الكاميرا...';

            try { await window.loadLib('qr'); }
            catch(e) {
                if(scannerStatus) scannerStatus.textContent = 'تعذر تحميل مكتبة المسح — تأكد من اتصال الإنترنت';
                return;
            }
            if(typeof Html5Qrcode === 'undefined') {
                if(scannerStatus) scannerStatus.textContent = 'مكتبة المسح غير محمّلة — تأكد من ملف html5-qrcode.min.js';
                return;
            }
            if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                if(scannerStatus) scannerStatus.textContent = 'الكاميرا غير مدعومة في هذا المتصفح — استخدم سكانر USB';
                return;
            }

            stopScanner();
            try {
                html5Scanner = new Html5Qrcode('scanner-region');
            } catch(e) {
                if(scannerStatus) scannerStatus.textContent = 'تعذر تشغيل الكاميرا: ' + e.message;
                return;
            }

            html5Scanner.start(
                { facingMode: 'environment' },
                { fps: 10, qrbox: { width: 240, height: 150 } },
                (decodedText) => {
                    const code = String(decodedText || '').trim();
                    if(!code) return;
                    const prod = window.productsLog.find(p => p.barcode && String(p.barcode).trim() === code);
                    if(prod) {
                        posAddProduct(prod);
                        if(scannerStatus) scannerStatus.textContent = `تمت إضافة "${prod.name}" ✅`;
                        showToast(`تمت إضافة "${prod.name}"`, 'success');
                        setTimeout(closeScannerModal, 700);
                    } else {
                        if(scannerStatus) scannerStatus.textContent = `لا يوجد منتج بهذا الباركود: ${code}`;
                    }
                },
                () => { if(scannerStatus) scannerStatus.textContent = 'جارٍ الاتصال بالكاميرا...'; }
            ).catch(err => {
                if(scannerStatus) scannerStatus.textContent = 'خطأ في الكاميرا: ' + ((err && err.message) ? err.message : err);
            });
        });

        const closeBtns = scannerModal.querySelectorAll('.close-modal');
        closeBtns.forEach(b => b.addEventListener('click', closeScannerModal));
        scannerModal.addEventListener('click', (e) => { if(e.target === scannerModal) closeScannerModal(); });
    }

    if(btnExchange) {
        btnExchange.addEventListener('click', () => {
             if(currentInvoice.length === 0) {
                showToast('الفاتورة فارغة!', 'error');
                return;
            }
            showToast('جاري فتح نافذة الاستبدال...', 'info');
        });
    }

    // تشغيل جدول السجل
    renderSalesLog();

    // ================= منطق الملاحظات =================
    let notesLog = JSON.parse(localStorage.getItem('notesLog')) || [];
    const notesTbody = document.getElementById('notes-tbody');
    const noteEmpSelect = document.getElementById('note-emp-select');
    const noteInput = document.getElementById('note-input');
    const btnAddNote = document.getElementById('btn-add-note');
    let editingNoteId = null;

    function saveNotes() {
        localStorage.setItem('notesLog', JSON.stringify(notesLog));
    }

    // جعل الدالة متاحة عالمياً لكي نتمكن من الحذف
    window.deleteNote = function(id) {
        showConfirm('حذف ملاحظة', 'هل أنت متأكد من حذف هذه الملاحظة؟', () => {
            notesLog = notesLog.filter(note => note.id !== id);
            saveNotes();
            renderNotes();
            showToast('تم حذف الملاحظة بنجاح', 'success');
        });
    };

    window.editNote = function(id) {
        const noteToEdit = notesLog.find(note => note.id === id);
        if(noteToEdit) {
            editingNoteId = id;
            noteInput.value = noteToEdit.content;
            
            // محاولة إيجاد الموظف في القائمة بناءً على الاسم
            for(let i = 0; i < noteEmpSelect.options.length; i++) {
                if(noteEmpSelect.options[i].text === noteToEdit.empName) {
                    noteEmpSelect.selectedIndex = i;
                    break;
                }
            }

            btnAddNote.innerHTML = '<i class="fas fa-save"></i> حفظ التعديل';
            btnAddNote.classList.remove('btn-primary');
            btnAddNote.classList.add('btn-soft'); // تغيير لون الزر ليدل على التعديل
            
            noteInput.focus();
        }
    };

    function renderNotes() {
        if(!notesTbody) return;

        if(notesLog.length === 0) {
            notesTbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                        <i class="fas fa-file-alt" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                        لا توجد ملاحظات مسجلة بعد.
                    </td>
                </tr>
            `;
            return;
        }

        notesTbody.innerHTML = '';
        [...notesLog].reverse().forEach(note => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight: 600; color: var(--primary);">${note.empName}</td>
                <td style="text-align: right; max-width: 300px; white-space: normal;">${note.content}</td>
                <td>${note.date}</td>
                <td>${note.time}</td>
                <td>
                    <div style="display: flex; gap: 5px; justify-content: center;">
                        <button class="btn-icon-only" title="تعديل" onclick="editNote(${note.id})" style="color: var(--primary); background: transparent; border: none; cursor: pointer;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deleteNote(${note.id})" style="color: var(--danger); background: transparent; border: none; cursor: pointer;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            notesTbody.appendChild(tr);
        });
    }

    if(btnAddNote) {
        btnAddNote.addEventListener('click', () => {
            if(!noteEmpSelect.value) {
                showToast('الرجاء اختيار الموظف أولاً', 'error');
                return;
            }
            if(!noteInput.value.trim()) {
                showToast('الرجاء كتابة الملاحظة', 'error');
                return;
            }

            const empName = noteEmpSelect.options[noteEmpSelect.selectedIndex].text;
            const now = new Date();

            if (editingNoteId) {
                // وضع التعديل
                const noteIndex = notesLog.findIndex(n => n.id === editingNoteId);
                if(noteIndex !== -1) {
                    notesLog[noteIndex].empName = empName;
                    notesLog[noteIndex].content = noteInput.value.trim();
                    // نحدث الوقت أيضاً ليشير لوقت التعديل
                    notesLog[noteIndex].time = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) + ' (معدلة)';
                }
                
                showToast('تم تعديل الملاحظة بنجاح', 'success');
                editingNoteId = null;
                btnAddNote.innerHTML = '<i class="fas fa-plus"></i> إضافة ملاحظة';
                btnAddNote.classList.remove('btn-soft');
                btnAddNote.classList.add('btn-primary');

            } else {
                // إضافة جديدة
                const newNote = {
                    id: Date.now(),
                    empName: empName,
                    content: noteInput.value.trim(),
                    date: now.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
                    time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
                };
                notesLog.push(newNote);
                showToast('تم تسجيل الملاحظة بنجاح', 'success');
            }

            saveNotes();
            renderNotes();

            noteInput.value = '';
            noteEmpSelect.value = '';
        });
    }

    // عرض الملاحظات عند التحميل
    renderNotes();

    // ================= منطق السلف والخصومات =================
    let loansLog = JSON.parse(localStorage.getItem('loansLog')) || [];
    const loansTbody = document.getElementById('loans-tbody');
    const loanEmpSelect = document.getElementById('loan-emp-select');
    const loanAmount = document.getElementById('loan-amount');
    const loanReason = document.getElementById('loan-reason');
    const btnAddLoan = document.getElementById('btn-add-loan');
    let editingLoanId = null;

    function saveLoans() {
        localStorage.setItem('loansLog', JSON.stringify(loansLog));
    }

    window.deleteLoan = function(id) {
        showConfirm('حذف سحب', 'هل أنت متأكد من حذف هذا السجل؟', () => {
            loansLog = loansLog.filter(loan => loan.id !== id);
            saveLoans();
            renderLoans();
            showToast('تم الحذف بنجاح', 'success');
        });
    };

    window.editLoan = function(id) {
        const loanToEdit = loansLog.find(loan => loan.id === id);
        if(loanToEdit) {
            editingLoanId = id;
            loanAmount.value = loanToEdit.amount;
            loanReason.value = loanToEdit.reason === '---' ? '' : loanToEdit.reason;
            
            for(let i = 0; i < loanEmpSelect.options.length; i++) {
                if(loanEmpSelect.options[i].text === loanToEdit.empName) {
                    loanEmpSelect.selectedIndex = i;
                    break;
                }
            }

            btnAddLoan.innerHTML = '<i class="fas fa-save"></i> حفظ التعديل';
            btnAddLoan.classList.remove('btn-primary');
            btnAddLoan.classList.add('btn-soft'); 
            
            loanAmount.focus();
        }
    };

    function renderLoans() {
        if(!loansTbody) return;

        if(loansLog.length === 0) {
            loansTbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                        <i class="fas fa-wallet" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                        لا توجد سحوبات مسجلة.
                    </td>
                </tr>
            `;
            return;
        }

        loansTbody.innerHTML = '';
        [...loansLog].reverse().forEach(loan => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight: 600; color: var(--primary);">${loan.empName}</td>
                <td style="font-weight: bold;">${loan.amount} ج.م</td>
                <td>${loan.reason}</td>
                <td>${loan.time} ${loan.date}</td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 5px; justify-content: center;">
                        <button class="btn-icon-only" title="تعديل" onclick="editLoan(${loan.id})" style="color: var(--primary); background: transparent; border: none; cursor: pointer;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deleteLoan(${loan.id})" style="color: var(--danger); background: transparent; border: none; cursor: pointer;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            loansTbody.appendChild(tr);
        });
    }

    if(btnAddLoan) {
        btnAddLoan.addEventListener('click', () => {
            if(!loanEmpSelect.value) {
                showToast('الرجاء اختيار الموظف أولاً', 'error');
                return;
            }
            if(!loanAmount.value || parseFloat(loanAmount.value) <= 0) {
                showToast('الرجاء إدخال مبلغ صحيح', 'error');
                return;
            }
            const empName = loanEmpSelect.options[loanEmpSelect.selectedIndex].text;
            const now = new Date();
            const reasonText = loanReason.value.trim() ? loanReason.value.trim() : '---';
            
            if (editingLoanId) {
                const loanIndex = loansLog.findIndex(l => l.id === editingLoanId);
                if(loanIndex !== -1) {
                    loansLog[loanIndex].empName = empName;
                    loansLog[loanIndex].amount = parseFloat(loanAmount.value);
                    loansLog[loanIndex].reason = reasonText;
                    loansLog[loanIndex].time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ' (معدلة)';
                }
                showToast('تم تعديل السجل بنجاح', 'success');
                editingLoanId = null;
                btnAddLoan.innerHTML = '<i class="fas fa-plus"></i> تسجيل سحب/خصم';
                btnAddLoan.classList.remove('btn-soft');
                btnAddLoan.classList.add('btn-primary');
            } else {
                const newLoan = {
                    id: Date.now(),
                    empName: empName,
                    amount: parseFloat(loanAmount.value),
                    reason: reasonText,
                    date: now.toLocaleDateString('en-GB').replace(/\//g, '-'), 
                    time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
                };
                loansLog.push(newLoan);
                showToast('تم تسجيل السحب بنجاح', 'success');
                addNotification(`سحب/خصم ${fmt(newLoan.amount)} لـ ${empName}`, 'withdrawal');
            }

            saveLoans();
            renderLoans();

            loanAmount.value = '';
            loanReason.value = '';
            loanEmpSelect.value = '';
        });
    }

    // عرض السلف عند التحميل
    renderLoans();

    // ================= المشتريات والموردين =================
    let suppliersLog = JSON.parse(localStorage.getItem('suppliersLog')) || [];
    let purchasesLog = JSON.parse(localStorage.getItem('purchasesLog')) || [];
    let editingSupplierIndex = -1;
    let editingPurchaseIndex = -1;
    let suppliersSearchQuery = '';
    let purchasesSearchQuery = '';

    const suppliersTbody = document.getElementById('suppliers-tbody');
    const purchasesTbody = document.getElementById('purchases-tbody');
    const purchaseSupplierSelect = document.getElementById('purchase-supplier');

    function saveSuppliersToLocal() {
        localStorage.setItem('suppliersLog', JSON.stringify(suppliersLog));
    }

    function savePurchasesToLocal() {
        localStorage.setItem('purchasesLog', JSON.stringify(purchasesLog));
    }

    window.renderPurchasesSummary = function() {
        const countEl = document.getElementById('purchases-summary-count');
        const totalEl = document.getElementById('purchases-summary-total');
        const debtEl = document.getElementById('purchases-summary-debt');
        if(countEl) countEl.textContent = purchasesLog.length;
        if(totalEl) totalEl.textContent = fmt(purchasesLog.reduce((s, p) => s + (p.total || 0), 0));
        if(debtEl) debtEl.textContent = fmt(suppliersLog.reduce((s, sp) => s + (sp.balance || 0), 0));
    };

    function renderSuppliers() {
        if(!suppliersTbody) return;
        suppliersTbody.innerHTML = '';

        if(purchaseSupplierSelect) {
            purchaseSupplierSelect.innerHTML = '<option value="" disabled selected>اختر المورد...</option>';
            suppliersLog.forEach(supp => {
                purchaseSupplierSelect.innerHTML += `<option value="${supp.name}">${supp.name}</option>`;
            });
        }

        const q = (suppliersSearchQuery || '').toLowerCase();
        const filtered = q ? suppliersLog.filter(s => String(s.name || '').toLowerCase().includes(q) || String(s.phone || '').toLowerCase().includes(q)) : suppliersLog;

        if(filtered.length === 0) {
            suppliersTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-users-slash" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>${suppliersLog.length === 0 ? 'لا يوجد موردون مسجلون' : 'لا يوجد موردون مطابقون للبحث'}</td></tr>`;
            window.renderPurchasesSummary();
            return;
        }

        filtered.forEach((supplier) => {
            const index = suppliersLog.indexOf(supplier);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${supplier.name}</strong></td>
                <td style="color: var(--text-muted);">${supplier.phone || '-'}</td>
                <td style="color: var(--text-muted);">${supplier.address || '-'}</td>
                <td style="color: var(--text-muted);">${supplier.notes || '-'}</td>
                <td style="font-weight: 700; color: ${supplier.balance > 0 ? 'var(--primary)' : 'var(--text-main)'};">${fmt(supplier.balance)}</td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 15px; justify-content: center;">
                        <button class="btn-icon-only" title="تسديد للمورد" onclick="window.settleSupplier(${index})" style="color: var(--success); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-money-bill-wave"></i></button>
                        <button class="btn-icon-only" title="تعديل" onclick="editSupplier(${index})" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deleteSupplier(${index})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            suppliersTbody.appendChild(tr);
        });
        window.renderPurchasesSummary();
    }

    function renderPurchases() {
        if(!purchasesTbody) return;
        purchasesTbody.innerHTML = '';
        const q = (purchasesSearchQuery || '').toLowerCase();
        const filtered = q ? purchasesLog.filter(p => String(p.invoice || '').toLowerCase().includes(q) || String(p.supplier || '').toLowerCase().includes(q)) : purchasesLog;
        if(filtered.length === 0) {
            purchasesTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-boxes" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>${purchasesLog.length === 0 ? 'لا توجد مشتريات مسجلة' : 'لا توجد فواتير مطابقة للبحث'}</td></tr>`;
            window.renderPurchasesSummary();
            return;
        }

        filtered.forEach((purchase) => {
            const index = purchasesLog.indexOf(purchase);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>#${purchase.invoice}</strong></td>
                <td style="color: var(--text-muted);">${purchase.date}</td>
                <td><strong>${purchase.supplier}</strong></td>
                <td style="color: var(--text-muted);">${purchase.reference || '-'}</td>
                <td style="font-weight: 700; color: var(--success);">${fmt(purchase.total)}</td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 15px; justify-content: center;">
                        <button class="btn-icon-only" title="تعديل" onclick="editPurchase(${index})" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deletePurchase(${index})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            purchasesTbody.appendChild(tr);
        });
        window.renderPurchasesSummary();
    }

    window.editSupplier = function(index) {
        editingSupplierIndex = index;
        const supp = suppliersLog[index];
        document.getElementById('supplier-name').value = supp.name;
        document.getElementById('supplier-phone').value = supp.phone;
        document.getElementById('supplier-address').value = supp.address;
        document.getElementById('supplier-balance').value = supp.balance;
        document.getElementById('supplier-notes').value = supp.notes;
        document.getElementById('supplier-modal').classList.remove('hidden');
    };

    window.deleteSupplier = function(index) {
        showConfirmModal('حذف المورد', 'هل أنت متأكد من حذف هذا المورد نهائياً؟', () => {
            suppliersLog.splice(index, 1);
            saveSuppliersToLocal();
            renderSuppliers();
            showToast('تم حذف المورد', 'success');
        });
    };

    window.editPurchase = function(index) {
        editingPurchaseIndex = index;
        const pur = purchasesLog[index];
        document.getElementById('purchase-invoice').value = pur.invoice;
        document.getElementById('purchase-supplier').value = pur.supplier;
        document.getElementById('purchase-reference').value = pur.reference;
        document.getElementById('purchase-total').value = pur.total;
        document.getElementById('purchase-modal').classList.remove('hidden');
    };

    window.deletePurchase = function(index) {
        showConfirmModal('حذف الفاتورة', 'هل أنت متأكد من حذف هذه الفاتورة نهائياً؟', () => {
            const pur = purchasesLog[index];
            const supp = suppliersLog.find(s => s.name === pur.supplier);
            if(supp) {
                supp.balance -= pur.total;
                saveSuppliersToLocal();
                renderSuppliers();
            }
            purchasesLog.splice(index, 1);
            savePurchasesToLocal();
            renderPurchases();
            showToast('تم حذف الفاتورة وتحديث رصيد المورد', 'success');
        });
    };

    window.askAmount = function(title, message, onSuccess) {
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.innerHTML = `
            <div class="modal-card" style="max-width: 360px; text-align: center; width: 100%;">
                <div style="font-size: 44px; color: var(--success, #16a34a); margin-bottom: 12px;"><i class="fas fa-money-bill-wave"></i></div>
                <h3 style="margin-bottom: 8px; font-size: 20px; color: var(--text-main, #111);">${title}</h3>
                <p style="color: var(--text-muted, #666); margin-bottom: 20px; font-size: 14px; line-height: 1.6; font-weight: 600;">${message}</p>
                <input type="number" min="0" step="any" class="custom-input glass-input" placeholder="0" style="width: 100%; text-align: center; margin-bottom: 18px;" id="ask-amount-input">
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button class="btn-primary" id="ask-amount-ok" style="flex: 1; justify-content: center;">تأكيد</button>
                    <button class="btn-outline" id="ask-amount-cancel" style="flex: 1; justify-content: center;">إلغاء</button>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        const input = overlay.querySelector('#ask-amount-input');
        const ok = overlay.querySelector('#ask-amount-ok');
        const cancel = overlay.querySelector('#ask-amount-cancel');
        const close = () => overlay.remove();
        input.focus();
        const submit = () => {
            const val = parseFloat(input.value);
            if(isNaN(val) || val <= 0) { showToast('أدخل مبلغاً صحيحاً أكبر من صفر', 'error'); input.focus(); return; }
            close();
            onSuccess(val);
        };
        ok.addEventListener('click', submit);
        cancel.addEventListener('click', close);
        input.addEventListener('keydown', (e) => { if(e.key === 'Enter') submit(); });
    };

    window.settleSupplier = function(index) {
        const supplier = suppliersLog[index];
        if(!supplier) return;
        if((supplier.balance || 0) <= 0) { showToast('لا يوجد رصيد مستحق لهذا المورد', 'error'); return; }
        window.askAmount('تسديد للمورد', `المبلغ المسدد للمورد "${supplier.name}" — الرصيد المستحق حالياً: ${fmt(supplier.balance)}`, (amount) => {
            supplier.balance = Math.max((supplier.balance || 0) - amount, 0);
            saveSuppliersToLocal();
            renderSuppliers();
            showToast('تم تسجيل التسديد بنجاح', 'success');
            addNotification(`تسديد ${fmt(amount)} للمورد ${supplier.name}`, 'withdrawal');
        });
    };

    const btnAddSupplierBtn = document.getElementById('btn-add-supplier');
    const supplierModal = document.getElementById('supplier-modal');
    const btnSaveSupplier = document.getElementById('btn-save-supplier');
    
    const btnAddPurchaseBtn = document.getElementById('btn-add-purchase');
    const purchaseModal = document.getElementById('purchase-modal');
    const btnSavePurchase = document.getElementById('btn-save-purchase');

    if(btnAddSupplierBtn && supplierModal) {
        btnAddSupplierBtn.addEventListener('click', () => {
            editingSupplierIndex = -1;
            document.getElementById('supplier-name').value = '';
            document.getElementById('supplier-phone').value = '';
            document.getElementById('supplier-address').value = '';
            document.getElementById('supplier-balance').value = '';
            document.getElementById('supplier-notes').value = '';
            supplierModal.classList.remove('hidden');
        });
    }

    if(btnAddPurchaseBtn && purchaseModal) {
        btnAddPurchaseBtn.addEventListener('click', () => {
            editingPurchaseIndex = -1;
            document.getElementById('purchase-invoice').value = '';
            document.getElementById('purchase-supplier').value = '';
            document.getElementById('purchase-reference').value = '';
            document.getElementById('purchase-total').value = '';
            purchaseModal.classList.remove('hidden');
        });
    }

    if(btnSaveSupplier) {
        btnSaveSupplier.addEventListener('click', () => {
            const name = document.getElementById('supplier-name').value.trim();
            const phone = document.getElementById('supplier-phone').value.trim();
            const address = document.getElementById('supplier-address').value.trim();
            const balance = document.getElementById('supplier-balance').value.trim();
            const notes = document.getElementById('supplier-notes').value.trim();

            if(!name) {
                showToast('الرجاء إدخال اسم المورد', 'error');
                return;
            }

            const newSupplier = {
                name, phone, address, notes, balance: balance ? parseFloat(balance) : 0
            };

            if(editingSupplierIndex > -1) {
                suppliersLog[editingSupplierIndex] = newSupplier;
                showToast('تم تعديل المورد بنجاح', 'success');
            } else {
                suppliersLog.push(newSupplier);
                showToast('تم إضافة المورد بنجاح', 'success');
            }
            
            saveSuppliersToLocal();
            renderSuppliers();
            supplierModal.classList.add('hidden');
        });
    }

    if(btnSavePurchase) {
        btnSavePurchase.addEventListener('click', () => {
            const invoice = document.getElementById('purchase-invoice').value.trim();
            const supplier = document.getElementById('purchase-supplier').value;
            const reference = document.getElementById('purchase-reference').value.trim();
            const total = document.getElementById('purchase-total').value.trim();

            if(!invoice || !supplier || !total) {
                showToast('الرجاء إكمال البيانات الأساسية (الفاتورة، المورد، الإجمالي)', 'error');
                return;
            }

            const today = new Date();
            const dateStr = today.toLocaleDateString('ar-EG');
            const totalVal = parseFloat(total);

            const newPurchase = {
                invoice,
                supplier,
                reference,
                total: totalVal,
                date: dateStr
            };

            if (editingPurchaseIndex > -1) {
                const oldPurchase = purchasesLog[editingPurchaseIndex];
                
                // التراجع عن التأثير القديم على المورد
                const oldSupp = suppliersLog.find(s => s.name === oldPurchase.supplier);
                if (oldSupp) oldSupp.balance -= oldPurchase.total;

                // تطبيق التأثير الجديد
                const newSupp = suppliersLog.find(s => s.name === supplier);
                if (newSupp) newSupp.balance += totalVal;

                newPurchase.date = oldPurchase.date; // الاحتفاظ بالتاريخ القديم
                purchasesLog[editingPurchaseIndex] = newPurchase;
                showToast('تم تعديل الفاتورة بنجاح', 'success');
            } else {
                purchasesLog.push(newPurchase);
                // إضافة القيمة لحساب المورد
                const suppObj = suppliersLog.find(s => s.name === supplier);
                if(suppObj) suppObj.balance += totalVal;
                showToast('تم تسجيل الفاتورة وإضافتها لحساب المورد', 'success');
            }

            saveSuppliersToLocal();
            savePurchasesToLocal();
            renderSuppliers();
            renderPurchases();
            purchaseModal.classList.add('hidden');
        });
    }

    // عرض البيانات عند التحميل
    const purchasesSearchInput = document.getElementById('purchases-search-input');
    if(purchasesSearchInput) {
        purchasesSearchInput.addEventListener('input', () => {
            purchasesSearchQuery = purchasesSearchInput.value.trim();
            renderPurchases();
        });
    }
    const suppliersSearchInput = document.getElementById('suppliers-search-input');
    if(suppliersSearchInput) {
        suppliersSearchInput.addEventListener('input', () => {
            suppliersSearchQuery = suppliersSearchInput.value.trim();
            renderSuppliers();
        });
    }
    renderSuppliers();
    renderPurchases();
    window.renderPurchasesSummary();

    // ================= مناديب التوصيل =================
    let deliveryLog = JSON.parse(localStorage.getItem('deliveryLog')) || [];
    let deliveryShipmentsLog = JSON.parse(localStorage.getItem('deliveryShipmentsLog')) || [];
    let editingDeliveryIndex = -1;
    let editingShipmentIndex = -1;
    let deliverySearchQuery = '';
    
    const deliveryTbody = document.getElementById('delivery-tbody');
    const deliveryModal = document.getElementById('delivery-modal');
    const btnAddDelivery = document.getElementById('btn-add-delivery');
    const btnSaveDelivery = document.getElementById('btn-save-delivery');

    function saveDeliveryToLocal() {
        localStorage.setItem('deliveryLog', JSON.stringify(deliveryLog));
    }

    function saveShipmentsToLocal() {
        localStorage.setItem('deliveryShipmentsLog', JSON.stringify(deliveryShipmentsLog));
    }

    function shipmentDriverCounts() {
        const counts = {};
        deliveryShipmentsLog.forEach(s => {
            if(!counts[s.driver]) counts[s.driver] = { assigned: 0, delivered: 0, pending: 0 };
            counts[s.driver].assigned++;
            if(s.status === 'delivered') counts[s.driver].delivered++;
            else if(s.status === 'pending') counts[s.driver].pending++;
        });
        return counts;
    }

    window.renderDeliverySummary = function() {
        const driversEl = document.getElementById('delivery-summary-drivers');
        const pendingEl = document.getElementById('delivery-summary-pending');
        const deliveredEl = document.getElementById('delivery-summary-delivered');
        const commEl = document.getElementById('delivery-summary-commission');
        if(driversEl) driversEl.textContent = deliveryLog.length;
        if(pendingEl) pendingEl.textContent = deliveryShipmentsLog.filter(s => s.status === 'pending').length;
        if(deliveredEl) deliveredEl.textContent = deliveryShipmentsLog.filter(s => s.status === 'delivered').length;
        if(commEl) commEl.textContent = fmt(deliveryShipmentsLog.filter(s => s.status === 'delivered').reduce((sum, s) => sum + (s.commission || 0), 0));
    };

    function renderDelivery() {
        if(!deliveryTbody) return;
        deliveryTbody.innerHTML = '';
        const counts = shipmentDriverCounts();
        const q = (deliverySearchQuery || '').toLowerCase();
        const filtered = q ? deliveryLog.filter(d => String(d.name || '').toLowerCase().includes(q) || String(d.phone || '').toLowerCase().includes(q)) : deliveryLog;
        if(filtered.length === 0) {
            deliveryTbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-motorcycle" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>${deliveryLog.length === 0 ? 'لا يوجد مناديب مسجلون' : 'لا يوجد مناديب مطابقون للبحث'}</td></tr>`;
            window.renderDeliverySummary();
            return;
        }

        filtered.forEach((driver) => {
            const index = deliveryLog.indexOf(driver);
            const c = counts[driver.name] || { assigned: 0, delivered: 0, pending: 0 };
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${driver.name}</strong></td>
                <td style="color: var(--text-muted);">${driver.phone || '-'}</td>
                <td style="font-weight: 700; color: var(--gold-deep);">${fmt(driver.commission)}</td>
                <td><span style="background: var(--bg-color); padding: 5px 10px; border-radius: 20px; font-weight: 600;">${c.assigned}</span></td>
                <td><span style="color: var(--success); font-weight: 700;">${c.delivered}</span></td>
                <td><span style="color: var(--warning); font-weight: 700;">${c.pending}</span></td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 15px; justify-content: center;">
                        <button class="btn-icon-only" title="تعديل" onclick="editDelivery(${index})" style="color: var(--gold-deep); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deleteDelivery(${index})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            deliveryTbody.appendChild(tr);
        });
        window.renderDeliverySummary();
    }

    window.editDelivery = function(index) {
        editingDeliveryIndex = index;
        const driver = deliveryLog[index];
        document.getElementById('delivery-name').value = driver.name;
        document.getElementById('delivery-phone').value = driver.phone;
        document.getElementById('delivery-commission').value = driver.commission;
        deliveryModal.classList.remove('hidden');
    };

    window.deleteDelivery = function(index) {
        showConfirmModal('حذف المندوب', 'هل أنت متأكد من حذف هذا المندوب؟', () => {
            deliveryLog.splice(index, 1);
            saveDeliveryToLocal();
            renderDelivery();
            showToast('تم حذف المندوب بنجاح', 'success');
        });
    };

    if(btnAddDelivery && deliveryModal) {
        btnAddDelivery.addEventListener('click', () => {
            editingDeliveryIndex = -1;
            document.getElementById('delivery-name').value = '';
            document.getElementById('delivery-phone').value = '';
            document.getElementById('delivery-commission').value = '0';
            deliveryModal.classList.remove('hidden');
        });
    }

    if(btnSaveDelivery) {
        btnSaveDelivery.addEventListener('click', () => {
            const name = document.getElementById('delivery-name').value.trim();
            const phone = document.getElementById('delivery-phone').value.trim();
            const commission = document.getElementById('delivery-commission').value.trim();

            if(!name) {
                showToast('الرجاء إدخال اسم المندوب', 'error');
                return;
            }

            const newDriver = {
                name,
                phone,
                commission: commission ? parseFloat(commission) : 0,
                assigned: 0,
                delivered: 0,
                pending: 0
            };

            if(editingDeliveryIndex > -1) {
                // Keep the old order stats when editing
                newDriver.assigned = deliveryLog[editingDeliveryIndex].assigned;
                newDriver.delivered = deliveryLog[editingDeliveryIndex].delivered;
                newDriver.pending = deliveryLog[editingDeliveryIndex].pending;
                
                deliveryLog[editingDeliveryIndex] = newDriver;
                showToast('تم تعديل بيانات المندوب بنجاح', 'success');
            } else {
                deliveryLog.push(newDriver);
                showToast('تم إضافة المندوب بنجاح', 'success');
            }

            saveDeliveryToLocal();
            renderDelivery();
            deliveryModal.classList.add('hidden');
        });
    }

    const shipmentsTbody = document.getElementById('shipments-tbody');
    const shipmentModal = document.getElementById('shipment-modal');
    const btnAddShipment = document.getElementById('btn-add-shipment');
    const btnSaveShipment = document.getElementById('btn-save-shipment');
    const shipmentDriverSelect = document.getElementById('shipment-driver');

    function populateShipmentDriverSelect() {
        if(!shipmentDriverSelect) return;
        shipmentDriverSelect.innerHTML = '<option value="" disabled selected>اختر المندوب...</option>';
        deliveryLog.forEach(d => {
            shipmentDriverSelect.innerHTML += `<option value="${d.name}">${d.name}</option>`;
        });
    }

    function shipmentActionsHtml(ship) {
        if(ship.status === 'delivered' || ship.status === 'cancelled') {
            return `<div style="display: flex; gap: 10px; justify-content: center;">
                        <button class="btn-icon-only" title="حذف" onclick="window.deleteShipment(${ship.id})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 15px;"><i class="fas fa-trash"></i></button>
                    </div>`;
        }
        return `<div style="display: flex; gap: 10px; justify-content: center;">
                    <button class="btn-icon-only" title="تم التسليم" onclick="window.markShipmentDelivered(${ship.id})" style="color: var(--success); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-circle-check"></i></button>
                    <button class="btn-icon-only" title="إلغاء الشحنة" onclick="window.markShipmentCancelled(${ship.id})" style="color: var(--warning); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-ban"></i></button>
                    <button class="btn-icon-only" title="تعديل" onclick="window.editShipment(${ship.id})" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 15px;"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon-only" title="حذف" onclick="window.deleteShipment(${ship.id})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 15px;"><i class="fas fa-trash"></i></button>
                </div>`;
    }

    function renderShipments() {
        if(!shipmentsTbody) return;
        shipmentsTbody.innerHTML = '';
        if(deliveryShipmentsLog.length === 0) {
            shipmentsTbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-boxes-packing" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>لا توجد شحنات مسجلة</td></tr>`;
            window.renderDeliverySummary();
            return;
        }
        [...deliveryShipmentsLog].reverse().forEach(ship => {
            const tr = document.createElement('tr');
            const statusHtml = ship.status === 'delivered'
                ? `<span class="status-badge" style="background-color: rgba(37,211,102,0.12); color: var(--success);">تم التسليم</span>`
                : ship.status === 'cancelled'
                ? `<span class="status-badge" style="background-color: rgba(201,58,46,0.12); color: var(--danger);">ملغي</span>`
                : `<span class="status-badge" style="background-color: rgba(217,119,6,0.12); color: var(--warning);">معلق</span>`;
            tr.innerHTML = `
                <td><strong>${ship.customer || '-'}</strong>${ship.notes ? `<div style="font-size:11px; color:var(--text-muted); margin-top:2px;">${ship.notes}</div>` : ''}</td>
                <td style="color: var(--text-muted);">${ship.phone || '-'}</td>
                <td style="color: var(--text-muted);">${ship.address || '-'}</td>
                <td><span style="background: var(--bg-color); padding: 4px 10px; border-radius: 20px; font-weight: 600;">${ship.driver || '-'}</span></td>
                <td style="font-weight: 700; color: var(--gold-deep);">${fmt(ship.commission)}</td>
                <td style="color: var(--text-muted);">${ship.date || '-'}</td>
                <td>${statusHtml}</td>
                <td>${shipmentActionsHtml(ship)}</td>
            `;
            shipmentsTbody.appendChild(tr);
        });
        window.renderDeliverySummary();
    }

    function openAddShipmentModal() {
        editingShipmentIndex = -1;
        populateShipmentDriverSelect();
        document.getElementById('shipment-customer').value = '';
        document.getElementById('shipment-phone').value = '';
        document.getElementById('shipment-address').value = '';
        document.getElementById('shipment-commission').value = '0';
        document.getElementById('shipment-notes').value = '';
        shipmentModal.classList.remove('hidden');
    }

    window.editShipment = function(id) {
        editingShipmentIndex = deliveryShipmentsLog.findIndex(s => s.id === id);
        const ship = deliveryShipmentsLog[editingShipmentIndex];
        if(!ship) return;
        populateShipmentDriverSelect();
        shipmentDriverSelect.value = ship.driver || '';
        document.getElementById('shipment-customer').value = ship.customer || '';
        document.getElementById('shipment-phone').value = ship.phone || '';
        document.getElementById('shipment-address').value = ship.address || '';
        document.getElementById('shipment-commission').value = ship.commission || 0;
        document.getElementById('shipment-notes').value = ship.notes || '';
        shipmentModal.classList.remove('hidden');
    };

    window.deleteShipment = function(id) {
        showConfirmModal('حذف الشحنة', 'هل أنت متأكد من حذف هذه الشحنة نهائياً؟', () => {
            deliveryShipmentsLog = deliveryShipmentsLog.filter(s => s.id !== id);
            saveShipmentsToLocal();
            renderShipments();
            renderDelivery();
            showToast('تم حذف الشحنة', 'success');
        });
    };

    window.markShipmentDelivered = function(id) {
        const ship = deliveryShipmentsLog.find(s => s.id === id);
        if(!ship) return;
        ship.status = 'delivered';
        saveShipmentsToLocal();
        renderShipments();
        renderDelivery();
        addNotification(`تم تسليم شحنة "${ship.customer}" بواسطة ${ship.driver}`, 'online');
        showToast('تم تسليم الشحنة', 'success');
    };

    window.markShipmentCancelled = function(id) {
        const ship = deliveryShipmentsLog.find(s => s.id === id);
        if(!ship) return;
        ship.status = 'cancelled';
        saveShipmentsToLocal();
        renderShipments();
        renderDelivery();
        addNotification(`إلغاء شحنة "${ship.customer}" للمندوب ${ship.driver}`, 'warning');
        showToast('تم إلغاء الشحنة', 'success');
    };

    if(btnAddShipment) btnAddShipment.addEventListener('click', openAddShipmentModal);

    if(btnSaveShipment) {
        btnSaveShipment.addEventListener('click', () => {
            const driver = document.getElementById('shipment-driver').value;
            const customer = document.getElementById('shipment-customer').value.trim();
            const phone = document.getElementById('shipment-phone').value.trim();
            const address = document.getElementById('shipment-address').value.trim();
            const commission = parseFloat(document.getElementById('shipment-commission').value) || 0;
            const notes = document.getElementById('shipment-notes').value.trim();
            if(!driver) { showToast('اختر المندوب أولاً', 'error'); return; }
            if(!customer) { showToast('أدخل اسم العميل', 'error'); return; }
            if(editingShipmentIndex > -1) {
                const s = deliveryShipmentsLog[editingShipmentIndex];
                if(!s) return;
                s.driver = driver; s.customer = customer; s.phone = phone; s.address = address; s.commission = commission; s.notes = notes;
                showToast('تم تعديل الشحنة', 'success');
            } else {
                deliveryShipmentsLog.push({ id: Date.now(), driver, customer, phone, address, commission, notes, status: 'pending', date: new Date().toLocaleDateString('ar-EG') });
                showToast('تم تسجيل الشحنة', 'success');
            }
            saveShipmentsToLocal();
            renderShipments();
            renderDelivery();
            shipmentModal.classList.add('hidden');
        });
    }

    const deliverySearchInput = document.getElementById('delivery-search-input');
    if(deliverySearchInput) {
        deliverySearchInput.addEventListener('input', () => {
            deliverySearchQuery = deliverySearchInput.value.trim();
            renderDelivery();
        });
    }

    renderDelivery();
    renderShipments();

    // ================= العملاء =================
    window.customersLog = JSON.parse(localStorage.getItem('customersLog')) || [];
    let editingCustomerIndex = -1;
    
    const customersTbody = document.getElementById('customers-tbody');
    const customerModal = document.getElementById('customer-modal');
    const btnAddCustomer = document.getElementById('btn-add-customer');
    const btnSaveCustomer = document.getElementById('btn-save-customer');
    const posCustomerName = document.getElementById('pos-customer-name');
    const posCustomerPhone = document.getElementById('pos-customer-phone');
    const customersDatalist = document.getElementById('customers-datalist');

    window.saveCustomersToLocal = function() {
        localStorage.setItem('customersLog', JSON.stringify(window.customersLog));
    };

    window.populateCustomerSelect = function() {
        if(!customersDatalist) return;
        customersDatalist.innerHTML = '';
        window.customersLog.forEach((customer) => {
            const option = document.createElement('option');
            option.value = customer.name;
            customersDatalist.appendChild(option);
        });
    };
    
    // Auto-fill phone when selecting a name from datalist
    if(posCustomerName) {
        posCustomerName.addEventListener('input', () => {
            const found = window.customersLog.find(c => c.name === posCustomerName.value.trim());
            if(found && found.phone && posCustomerPhone) {
                posCustomerPhone.value = found.phone;
            }
        });
    }

    let customersSearchQuery = '';

    window.renderCustomersSummary = function() {
        const countEl = document.getElementById('customers-summary-count');
        const spentEl = document.getElementById('customers-summary-spent');
        const debtEl = document.getElementById('customers-summary-debt');
        if(countEl) countEl.textContent = window.customersLog.length;
        if(spentEl) spentEl.textContent = fmt(window.customersLog.reduce((s, c) => s + (c.totalSpent || 0), 0));
        if(debtEl) debtEl.textContent = fmt(window.customersLog.reduce((s, c) => s + (c.balance || 0), 0));
    };

    window.printDebtorsReport = function() {
        const debtors = window.customersLog.filter(c => (c.balance || 0) > 1).sort((a, b) => (b.balance || 0) - (a.balance || 0));
        const storeName = storeSettings.storeName || 'DataGris Store';
        const currency = storeSettings.currency || 'ج.م';
        const nowStr = new Date().toLocaleString('ar-EG');
        const totalDebt = debtors.reduce((s, c) => s + (c.balance || 0), 0);
        const rows = debtors.length ? debtors.map(c => `
            <tr>
                <td style="text-align:right; font-weight:700;">${c.name}</td>
                <td>${c.phone || '-'}</td>
                <td style="text-align:left;">${fmt(c.totalSpent || 0)}</td>
                <td style="text-align:left; font-weight:700; color:#b45309;">${fmt(c.balance)}</td>
            </tr>`).join('') : `<tr><td colspan="4" style="text-align:center; padding:30px; color:#6b7280;">لا يوجد عملاء مدينون حاليًا — كل الديون محصّلة</td></tr>`;

        const win = window.open('', '_blank', 'width=620,height=720');
        if(!win) { showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'error'); return; }
        win.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>كشف المديونيات - ${storeName}</title>
                <style>
                    * { box-sizing: border-box; margin: 0; padding: 0; }
                    body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; background: #fff; color: #111; padding: 24px; }
                    .report { max-width: 640px; margin: 0 auto; border: 1px solid #d1d5db; border-radius: 10px; padding: 26px 30px; }
                    h1 { font-size: 22px; font-weight: 800; text-align: center; }
                    .meta { font-size: 13px; line-height: 1.9; text-align: center; color: #374151; margin-top: 8px; }
                    .meta b { color: #111; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 13.5px; }
                    th { background: #f3f4f6; font-weight: 700; border: 1px solid #d1d5db; padding: 9px 10px; }
                    td { border: 1px solid #d1d5db; padding: 8px 10px; }
                    .total-box { display: flex; justify-content: space-between; align-items: center; border: 2px solid #111; border-radius: 8px; background: #fafafa; padding: 12px 18px; margin-top: 18px; font-weight: 700; font-size: 16px; }
                    .total-box .amt { font-size: 19px; font-weight: 900; color: #b45309; }
                    .footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 22px; font-size: 12px; color: #6b7280; }
                    .barcode svg { height: 36px; display: block; }
                    .bcode-text { font-size: 10px; color: #6b7280; text-align: center; direction: ltr; letter-spacing: 1px; }
                    @media print { body { padding: 0; } .report { border: none; border-radius: 0; } }
                </style>
            </head>
            <body>
                <div class="report">
                    <h1>كشف المديونيات المستحقة</h1>
                    <div class="meta"><b>المتجر:</b> ${storeName} &nbsp;•&nbsp; <b>التاريخ:</b> ${nowStr} &nbsp;•&nbsp; <b>العملة:</b> ${currency}</div>
                    <table>
                        <thead><tr><th style="text-align:right;">العميل</th><th>الهاتف</th><th style="text-align:left;">إجمالي الإنفاق</th><th style="text-align:left;">المديونية المستحقة</th></tr></thead>
                        <tbody>${rows}</tbody>
                    </table>
                    <div class="total-box">
                        <span>إجمالي المديونيات:</span>
                        <span class="amt">${fmt(totalDebt)} ${currency}</span>
                    </div>
                    <div class="footer">
                        <span>عدد المدينين: ${debtors.length}</span>
                        <span class="barcode">${barcodeSVG('TOT=' + totalDebt.toFixed(2), 1.2, 34)}<span class="bcode-text">TOT=${totalDebt.toFixed(2)}</span></span>
                        <span>${new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}</span>
                    </div>
                </div>
                <script>window.onload = function(){ window.focus(); window.print(); }<\/script>
            </body>
            </html>`);
        win.document.close();
    };

    const btnPrintDebtors = document.getElementById('btn-print-debtors');
    if(btnPrintDebtors) btnPrintDebtors.addEventListener('click', () => window.printDebtorsReport());

    function copyText(value, label) {
        if(!value) { showToast('لا يوجد ' + label, 'error'); return; }
        if(navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(value).then(() => showToast('تم نسخ ' + label, 'success')).catch(() => {});
        } else {
            showToast(value, 'info');
        }
    }
    window.copyText = copyText;

    window.viewCustomerPurchases = function(index) {
        const customer = window.customersLog[index];
        if(!customer) return;
        const modal = document.getElementById('customer-purchases-modal');
        const titleEl = document.getElementById('customer-purchases-title');
        const tbody = document.getElementById('customer-purchases-tbody');
        if(!modal || !tbody) return;
        titleEl.textContent = `الفواتير المسجلة باسم "${customer.name}" — هاتف: ${customer.phone || '-'}`;
        const purchases = [...salesLog].filter(s => String(s.customer || '') === String(customer.name)).sort((a, b) => (b.id || 0) - (a.id || 0));
        if(purchases.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:24px; color:var(--text-muted);"><i class="fas fa-receipt" style="font-size:30px; opacity:0.3; margin-bottom:10px; display:block;"></i>لا توجد فواتير مسجلة لهذا العميل</td></tr>`;
        } else {
            tbody.innerHTML = '';
            purchases.forEach(sale => {
                const tr = document.createElement('tr');
                const itemsText = (sale.items && sale.items.length ? sale.items.map(i => `${i.name} × ${i.quantity}`).join('، ') : sale.description || '-');
                tr.innerHTML = `
                    <td style="font-weight:bold; color:var(--primary);">#${sale.id}</td>
                    <td style="color:var(--text-muted);">${sale.date || '-'}</td>
                    <td style="color:var(--text-muted);">${sale.time || '-'}</td>
                    <td style="color:var(--text-muted);">${itemsText}</td>
                    <td style="font-weight:700; color:var(--success);">${fmt(sale.totalAmount)}</td>
                `;
                tbody.appendChild(tr);
            });
        }
        modal.classList.remove('hidden');
    };

    window.renderCustomers = function() {
        window.populateCustomerSelect();
        
        if(!customersTbody) return;
        customersTbody.innerHTML = '';
        const q = (customersSearchQuery || '').toLowerCase();
        const filtered = q ? window.customersLog.filter(c => String(c.name || '').toLowerCase().includes(q) || String(c.phone || '').toLowerCase().includes(q)) : window.customersLog;
        if(filtered.length === 0) {
            customersTbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-users-slash" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>${window.customersLog.length === 0 ? 'لا يوجد عملاء مسجلون' : 'لا يوجد عملاء مطابقون للبحث'}</td></tr>`;
            window.renderCustomersSummary();
            return;
        }

        filtered.forEach((customer) => {
            const index = window.customersLog.indexOf(customer);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${customer.name}</strong></td>
                <td style="color: var(--text-muted);">${customer.phone || '-'} ${customer.phone ? `<button class="btn-icon-only" title="نسخ الرقم" onclick="copyText('${String(customer.phone || '').replace(/'/g, '\\\'')}', 'الرقم')" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 12px; margin-right: 4px;"><i class="fas fa-copy"></i></button>` : ''}</td>
                <td style="color: var(--text-muted);">${customer.address || '-'} ${customer.address ? `<button class="btn-icon-only" title="نسخ العنوان" onclick="copyText('${String(customer.address || '').replace(/'/g, '\\\'')}', 'العنوان')" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 12px; margin-right: 4px;"><i class="fas fa-copy"></i></button>` : ''}</td>
                <td><span style="background: var(--bg-color); padding: 5px 10px; border-radius: 20px; font-weight: 600;">${customer.purchasesCount || 0}</span></td>
                <td style="font-weight: 700; color: var(--success);">${fmt(customer.totalSpent || 0)}</td>
                <td style="font-weight: 700; color: ${(customer.balance || 0) > 0 ? 'var(--danger)' : 'var(--text-main)'};">${fmt(customer.balance || 0)}</td>
                <td style="color: var(--text-muted);">${customer.lastPurchase || '-'}</td>
                <td>
                    <button class="btn-icon-only" title="مراسلة عبر واتساب" onclick="window.chatCustomerWhatsApp('${String(customer.name || '').replace(/'/g, '\\\'')}', '${customer.phone || ''}')" style="color: #25D366; background: transparent; border: none; cursor: pointer; font-size: 20px;"><i class="fab fa-whatsapp"></i></button>
                </td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 15px; justify-content: center;">
                        <button class="btn-icon-only" title="عرض المشتريات" onclick="window.viewCustomerPurchases(${index})" style="color: var(--warning); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-receipt"></i></button>
                        ${(customer.balance || 0) > 0 ? `<button class="btn-icon-only" title="تحصيل من العميل" onclick="window.collectCustomerBalance(${index})" style="color: var(--success); background: transparent; border: none; cursor: pointer; font-size: 16px; font-weight: 700;">💰</button>` : ''}
                        <button class="btn-icon-only" title="تعديل" onclick="editCustomer(${index})" style="color: var(--primary); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="deleteCustomer(${index})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            customersTbody.appendChild(tr);
        });
        window.renderCustomersSummary();
    }

    window.collectCustomerBalance = function(index) {
        const customer = window.customersLog[index];
        if(!customer || !(customer.balance > 0)) return;
        const due = Number(customer.balance) || 0;
        window.askAmount('تحصيل من العميل', `استلام دفعة من "${customer.name}" — المتبقي عليه: ${fmt(due)}`, (amount) => {
            customer.balance = Math.max(due - amount, 0);
            window.saveCustomersToLocal();
            window.renderCustomers();
            addNotification(`تحصيل ${fmt(amount)} من العميل ${customer.name}`, 'sale');
            showToast(`تم تحصيل ${fmt(amount)} من ${customer.name}`, 'success');
        });
    };

    window.editCustomer = function(index) {
        editingCustomerIndex = index;
        const customer = window.customersLog[index];
        document.getElementById('customer-name').value = customer.name;
        document.getElementById('customer-phone').value = customer.phone;
        document.getElementById('customer-address').value = customer.address;
        document.getElementById('customer-balance').value = customer.balance;
        customerModal.classList.remove('hidden');
    };

    window.deleteCustomer = function(index) {
        showConfirmModal('حذف العميل', 'هل أنت متأكد من حذف هذا العميل؟', () => {
            window.customersLog.splice(index, 1);
            window.saveCustomersToLocal();
            window.renderCustomers();
            showToast('تم حذف العميل بنجاح', 'success');
        });
    };

    function openAddCustomerModal() {
        editingCustomerIndex = -1;
        document.getElementById('customer-name').value = '';
        document.getElementById('customer-phone').value = '';
        document.getElementById('customer-address').value = '';
        document.getElementById('customer-balance').value = '0';
        customerModal.classList.remove('hidden');
    }

    if(btnAddCustomer && customerModal) {
        btnAddCustomer.addEventListener('click', openAddCustomerModal);
    }

    if(btnSaveCustomer) {
        btnSaveCustomer.addEventListener('click', () => {
            const name = document.getElementById('customer-name').value.trim();
            const phone = document.getElementById('customer-phone').value.trim();
            const address = document.getElementById('customer-address').value.trim();
            const balance = document.getElementById('customer-balance').value.trim();

            if(!name) {
                showToast('الرجاء إدخال اسم العميل', 'error');
                return;
            }

            const newCustomer = {
                name,
                phone,
                address,
                balance: balance ? parseFloat(balance) : 0,
                purchasesCount: 0,
                totalSpent: 0,
                lastPurchase: '-'
            };

            if(editingCustomerIndex > -1) {
                newCustomer.purchasesCount = window.customersLog[editingCustomerIndex].purchasesCount;
                newCustomer.totalSpent = window.customersLog[editingCustomerIndex].totalSpent;
                newCustomer.lastPurchase = window.customersLog[editingCustomerIndex].lastPurchase;
                
                window.customersLog[editingCustomerIndex] = newCustomer;
                showToast('تم تعديل بيانات العميل بنجاح', 'success');
            } else {
                window.customersLog.push(newCustomer);
                showToast('تم إضافة العميل بنجاح', 'success');
            }

            window.saveCustomersToLocal();
            window.renderCustomers();
            customerModal.classList.add('hidden');
        });
    }

    window.renderCustomers();

    const customersSearchInput = document.getElementById('customers-search-input');
    if(customersSearchInput) {
        customersSearchInput.addEventListener('input', () => {
            customersSearchQuery = customersSearchInput.value.trim();
            window.renderCustomers();
        });
    }

    // ================= المنتجات والتصنيفات =================
    window.categoriesLog = JSON.parse(localStorage.getItem('categoriesLog')) || ['الكل'];
    window.productsLog = JSON.parse(localStorage.getItem('productsLog')) || [
        {id: 1, name: 'هاتف ذكي X', category: 'الكل', price: 250, commission: 10},
        {id: 2, name: 'ساعة ذكية', category: 'الكل', price: 120.5, commission: 5}
    ];
    let editingProductIndex = -1;
    let currentPOSCategory = 'الكل';
    let productsSearchQuery = '';
    
    const btnAddCategory = document.getElementById('btn-add-category');
    const newCategoryInput = document.getElementById('new-category-name');
    const categoriesTbody = document.getElementById('categories-tbody');
    
    const btnOpenProductModal = document.getElementById('btn-open-product-modal');
    const productModal = document.getElementById('product-modal');
    const btnSaveProduct = document.getElementById('btn-save-product');
    const productsTbody = document.getElementById('products-tbody');
    const productCategorySelect = document.getElementById('product-category');
    
    const posCategoriesContainer = document.getElementById('pos-categories-container');
    const posProductsGrid = document.getElementById('pos-products-grid');

    window.saveCategoriesToLocal = function() {
        localStorage.setItem('categoriesLog', JSON.stringify(window.categoriesLog));
    };

    window.saveProductsToLocal = function() {
        localStorage.setItem('productsLog', JSON.stringify(window.productsLog));
    };

    window.renderCategories = function() {
        if(categoriesTbody) {
            categoriesTbody.innerHTML = '';
            window.categoriesLog.forEach((cat, index) => {
                if(cat === 'الكل') return;
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="font-weight:bold;">${cat}</td>
                    <td>
                        <button class="btn-icon-only" onclick="window.deleteCategory(${index})" style="color:var(--danger); border:none; background:transparent; cursor:pointer;" title="حذف"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                categoriesTbody.appendChild(tr);
            });
        }
        
        if(productCategorySelect) {
            productCategorySelect.innerHTML = '';
            window.categoriesLog.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat;
                option.textContent = cat;
                productCategorySelect.appendChild(option);
            });
        }
        
        if(posCategoriesContainer) {
            posCategoriesContainer.innerHTML = '';
            window.categoriesLog.forEach(cat => {
                const btn = document.createElement('button');
                btn.className = `category-btn ${currentPOSCategory === cat ? 'active' : ''}`;
                btn.textContent = cat;
                btn.onclick = () => {
                    currentPOSCategory = cat;
                    window.renderPOSProducts();
                };
                posCategoriesContainer.appendChild(btn);
            });
        }
    };

    window.deleteCategory = function(index) {
        const cat = window.categoriesLog[index];
        showConfirmModal('حذف تصنيف', `هل أنت متأكد من حذف تصنيف "${cat}"؟ قد تبقى المنتجات التابعة له كما هي.`, () => {
            window.categoriesLog.splice(index, 1);
            if(currentPOSCategory === cat) currentPOSCategory = 'الكل';
            window.saveCategoriesToLocal();
            window.renderCategories();
            showToast('تم حذف التصنيف', 'success');
        });
    };

    if(btnAddCategory) {
        btnAddCategory.addEventListener('click', () => {
            const val = newCategoryInput.value.trim();
            if(!val) { showToast('أدخل اسم التصنيف', 'error'); return; }
            if(window.categoriesLog.includes(val)) { showToast('هذا التصنيف موجود مسبقاً', 'error'); return; }
            window.categoriesLog.push(val);
            newCategoryInput.value = '';
            window.saveCategoriesToLocal();
            window.renderCategories();
            showToast('تم إضافة التصنيف بنجاح', 'success');
        });
    }

    window.renderProductsSummary = function() {
        const countEl = document.getElementById('products-summary-count');
        const catsEl = document.getElementById('products-summary-cats');
        const avgEl = document.getElementById('products-summary-avg');
        const lowEl = document.getElementById('products-summary-low');
        if(countEl) countEl.textContent = window.productsLog.length;
        if(catsEl) catsEl.textContent = window.categoriesLog.filter(c => c !== 'الكل').length;
        if(avgEl) {
            const sum = window.productsLog.reduce((s, p) => s + (p.price || 0), 0);
            avgEl.textContent = window.productsLog.length ? fmt(sum / window.productsLog.length) : fmt(0);
        }
        if(lowEl) lowEl.textContent = window.productsLog.filter(p => p.qty !== undefined && p.qty !== null && p.qty !== '' && Number(p.qty) <= (Number(p.minStock) || 0) && (Number(p.minStock) || 0) > 0).length;
    };

    window.renderProducts = function() {
        if(!productsTbody) return;
        productsTbody.innerHTML = '';
        const q = (productsSearchQuery || '').toLowerCase();
        const filtered = q ? window.productsLog.filter(p => String(p.name || '').toLowerCase().includes(q) || String(p.category || '').toLowerCase().includes(q)) : window.productsLog;
if(filtered.length === 0) {
            productsTbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:20px; color:var(--text-muted);">${window.productsLog.length === 0 ? 'لا توجد منتجات مسجلة' : 'لا توجد منتجات مطابقة للبحث'}</td></tr>`;
        } else {
            filtered.forEach((prod) => {
                const index = window.productsLog.indexOf(prod);
                const tr = document.createElement('tr');
                const hasQty = prod.qty !== undefined && prod.qty !== null && prod.qty !== '';
                const lowStock = hasQty && Number(prod.qty) <= (Number(prod.minStock) || 0) && (Number(prod.minStock) || 0) > 0;
                tr.innerHTML = `
                    <td style="font-weight:bold;">${prod.name}</td>
                    <td>${prod.category || 'الكل'}</td>
                    <td style="text-align:left; color:var(--primary); font-weight:bold;">${fmt(prod.price)}</td>
                    <td style="text-align:left;">${fmt(prod.cost || 0)}</td>
                    <td style="text-align:left; color:var(--warning); font-weight:bold;">${fmt(prod.commission)}</td>
                    <td>${hasQty ? (Number(prod.qty) > 0 ? `<span class="badge badge-success">${prod.qty}</span>` : `<span class="badge" style="background:var(--danger); color:#fff;">${prod.qty}</span>`) : `<span class="badge">∞</span>`}</td>
                    <td>${lowStock ? `<span class="badge" style="background:var(--danger); color:#fff;"><i class="fas fa-exclamation-triangle"></i> منخفض</span>` : `<span class="badge badge-success">متوفر</span>`}</td>
                    <td>
                        <div style="display:flex; gap:6px; justify-content:center;">
                            <button class="btn-icon-only" title="تعديل" onclick="window.editProduct(${index})"><i class="fas fa-edit"></i></button>
                            <button class="btn-icon-only" title="حذف" onclick="window.deleteProduct(${index})"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                `;
                productsTbody.appendChild(tr);
            });
        }
        window.renderPOSProducts();
        window.renderProductsSummary();
    };

    window.importProductsFromFile = async function(file) {
        if(!file) return;
        try { await window.loadLib('xlsx'); }
        catch(e) { showToast('تعذر تحميل مكتبة Excel — تأكد من اتصال الإنترنت', 'error'); return; }
        const reader = new FileReader();
        reader.onload = ev => {
            try {
                const data = new Uint8Array(ev.target.result);
                const wb = XLSX.read(data, { type: 'array' });
                const sheet = wb.Sheets[wb.SheetNames[0]];
                const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
                if(!rows || rows.length === 0) { showToast('الملف فارغ أو لا يحتوي على بيانات', 'error'); return; }
                const alias = {
                    'name': 'name', 'product': 'name', 'اسم المنتج': 'name', 'الاسم': 'name', 'اسم': 'name',
                    'price': 'price', 'السعر': 'price', 'سعر': 'price',
                    'cost': 'cost', 'التكلفة': 'cost', 'تكلفة': 'cost', 'سعر الشراء': 'cost',
                    'category': 'category', 'التصنيف': 'category', 'القسم': 'category', 'صنف': 'category',
                    'commission': 'commission', 'العمولة': 'commission', 'عمولة': 'commission',
                    'minstock': 'minStock', 'min stock': 'minStock', 'حد المخزون': 'minStock', 'الحد الادنى': 'minStock', 'الحد الأدنى': 'minStock',
                    'barcode': 'barcode', 'الباركود': 'barcode', 'كود': 'barcode', 'الكود': 'barcode', 'كود الباركود': 'barcode',
                    'qty': 'qty', 'الكمية': 'qty', 'المخزون': 'qty', 'quantity': 'qty', 'كمية': 'qty'
                };
                const fieldHeader = {};
                Object.keys(rows[0]).forEach(k => {
                    const norm = String(k).trim().toLowerCase().replace(/[\s_\-]+/g, ' ');
                    const f = alias[norm];
                    if(f && fieldHeader[f] === undefined) fieldHeader[f] = k;
                });
                const val = (field, row) => {
                    const h = fieldHeader[field];
                    return h === undefined ? undefined : row[h];
                };
                let added = 0, skipped = 0;
                let maxId = window.productsLog.reduce((m, p) => Math.max(m, Number(p.id) || 0), 0);
                rows.forEach(row => {
                    const name = String(val('name', row) || '').trim();
                    if(!name) { skipped++; return; }
                    const barcode = String(val('barcode', row) || '').trim();
                    if(barcode && window.productsLog.some(p => p.barcode && String(p.barcode).trim() === barcode)) { skipped++; return; }
                    const category = String(val('category', row) || 'الكل').trim() || 'الكل';
                    if(category !== 'الكل' && !window.categoriesLog.includes(category)) window.categoriesLog.push(category);
                    const num = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
                    const cmRaw = val('commission', row);
                    const commission = (cmRaw === undefined || cmRaw === '') ? (storeSettings.defaultProductCommission || 0) : num(cmRaw);
                    const qtyRaw = val('qty', row);
                    maxId++;
                    window.productsLog.push({
                        id: maxId,
                        name: name,
                        category: category,
                        price: num(val('price', row)),
                        cost: num(val('cost', row)),
                        commission: commission,
                        minStock: num(val('minStock', row)),
                        barcode: barcode,
                        qty: (qtyRaw === undefined || qtyRaw === '') ? '' : String(qtyRaw)
                    });
                    added++;
                });
                window.saveProductsToLocal();
                window.saveCategoriesToLocal();
                window.renderCategories();
                window.renderProducts();
                if(added > 0) showToast(`تم استيراد ${added} منتج بنجاح` + (skipped > 0 ? `، وتجاهل ${skipped} سطر (فارغ/تكرار باركود)` : ''), 'success');
                else showToast('لم يتم استيراد أي منتج. تأكد من أن أول صف هو عناوين الأعمدة', 'error');
            } catch(e) {
                showToast('خطأ في قراءة الملف: ' + e.message, 'error');
            }
        };
        reader.onerror = () => showToast('تعذر قراءة الملف', 'error');
        reader.readAsArrayBuffer(file);
    };

    window.exportProductsToExcel = async function() {
        try { await window.loadLib('xlsx'); }
        catch(e) { showToast('تعذر تحميل مكتبة Excel — تأكد من اتصال الإنترنت', 'error'); return; }
        const rows = window.productsLog.map(p => ({
            'اسم المنتج': p.name || '',
            'التصنيف': p.category || 'الكل',
            'السعر': p.price || 0,
            'التكلفة': p.cost || 0,
            'العمولة': p.commission || 0,
            'الباركود': p.barcode || '',
            'الكمية': (p.qty === undefined || p.qty === null || p.qty === '') ? '' : p.qty,
            'حد المخزون': p.minStock || 0
        }));
        const ws = XLSX.utils.json_to_sheet(rows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'المنتجات');
        XLSX.writeFile(wb, 'منتجات_' + new Date().toISOString().slice(0,10) + '.xlsx');
    };

    window.editProduct = function(index) {
        editingProductIndex = index;
        const prod = window.productsLog[index];
        document.getElementById('product-name').value = prod.name;
        document.getElementById('product-category').value = prod.category;
        document.getElementById('product-price').value = prod.price;
        document.getElementById('product-commission').value = prod.commission;
        document.getElementById('product-qty').value = (prod.qty !== undefined && prod.qty !== null && prod.qty !== '') ? prod.qty : '';
        document.getElementById('product-cost').value = prod.cost != null ? prod.cost : 0;
        document.getElementById('product-min-stock').value = prod.minStock != null ? prod.minStock : 0;
        document.getElementById('product-barcode').value = prod.barcode || '';
        productModal.classList.remove('hidden');
    };

    window.deleteProduct = function(index) {
        showConfirmModal('حذف منتج', 'هل أنت متأكد من حذف هذا المنتج نهائياً؟', () => {
            window.productsLog.splice(index, 1);
            window.saveProductsToLocal();
            window.renderProducts();
            showToast('تم حذف المنتج', 'success');
        });
    };

    if(btnOpenProductModal && productModal) {
        btnOpenProductModal.addEventListener('click', () => {
            editingProductIndex = -1;
            document.getElementById('product-name').value = '';
            document.getElementById('product-price').value = '0';
            document.getElementById('product-commission').value = '0';
            document.getElementById('product-qty').value = '';
            document.getElementById('product-cost').value = '0';
            document.getElementById('product-min-stock').value = '0';
            document.getElementById('product-barcode').value = '';
            if(window.categoriesLog.length > 0) document.getElementById('product-category').value = window.categoriesLog[0];
            productModal.classList.remove('hidden');
        });
    }

    const btnImportProducts = document.getElementById('btn-import-products');
    const btnExportProducts = document.getElementById('btn-export-products');
    const productsImportInput = document.getElementById('products-import-input');
    if(btnImportProducts && productsImportInput) {
        btnImportProducts.addEventListener('click', () => productsImportInput.click());
        productsImportInput.addEventListener('change', () => {
            if(productsImportInput.files && productsImportInput.files[0]) {
                window.importProductsFromFile(productsImportInput.files[0]);
            }
            productsImportInput.value = '';
        });
    }
    if(btnExportProducts) {
        btnExportProducts.addEventListener('click', () => window.exportProductsToExcel());
    }

    if(btnSaveProduct) {
        btnSaveProduct.addEventListener('click', () => {
            const name = document.getElementById('product-name').value.trim();
            const category = document.getElementById('product-category').value;
            const price = parseFloat(document.getElementById('product-price').value) || 0;
            const cost = parseFloat(document.getElementById('product-cost').value) || 0;
            const commission = parseFloat(document.getElementById('product-commission').value) || 0;
            const minStock = parseFloat(document.getElementById('product-min-stock').value) || 0;
            const barcode = (document.getElementById('product-barcode').value || '').trim();
            const qtyInput = document.getElementById('product-qty');
            const qtyRaw = qtyInput ? qtyInput.value.trim() : '';
            const qty = qtyRaw === '' ? '' : (parseFloat(qtyRaw) || 0);

            if(!name) { showToast('الرجاء إدخال اسم المنتج', 'error'); return; }

            const newProduct = {
                id: editingProductIndex > -1 ? window.productsLog[editingProductIndex].id : Date.now(),
                name,
                category,
                price,
                cost,
                commission,
                minStock,
                barcode,
                qty
            };

            if(editingProductIndex > -1) {
                window.productsLog[editingProductIndex] = newProduct;
                showToast('تم تعديل المنتج', 'success');
            } else {
                window.productsLog.push(newProduct);
                showToast('تم إضافة المنتج بنجاح', 'success');
            }

            window.saveProductsToLocal();
            window.renderProducts();
            productModal.classList.add('hidden');
        });
    }

    function posAddProduct(prod) {
        const existingItem = currentInvoice.find(i => i.id === prod.id);
        if(existingItem) {
            existingItem.quantity++;
        } else {
            currentInvoice.push({
                id: prod.id,
                name: prod.name,
                price: prod.price,
                cost: Number(prod.cost) || 0,
                quantity: 1
            });
        }
        renderInvoice();
    }

    window.renderPOSProducts = function() {
        if(!posProductsGrid) return;
        posProductsGrid.innerHTML = '';
        
        const filteredProducts = currentPOSCategory === 'الكل' 
            ? window.productsLog 
            : window.productsLog.filter(p => p.category === currentPOSCategory);

        if(filteredProducts.length === 0) {
            posProductsGrid.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 40px;"><i class="fas fa-box-open" style="font-size: 32px; opacity:0.3; margin-bottom:10px; display:block;"></i>لا توجد منتجات في هذا التصنيف</div>`;
            return;
        }

        const barcodeList = document.getElementById('barcodes-datalist');
        if(barcodeList) {
            const valids = window.productsLog.filter(p => p.barcode && String(p.barcode).trim().length > 0);
            barcodeList.innerHTML = valids.map(p => `<option value="${(p.barcode).trim()}">${p.name}</option>`).join('');
        }

        filteredProducts.forEach(prod => {
            const card = document.createElement('div');
            card.className = 'product-card pos-item-dynamic';
            card.style.padding = '15px';
            card.style.cursor = 'pointer';
            card.style.transition = 'transform 0.2s';
            card.onmouseover = () => card.style.transform = 'translateY(-3px)';
            card.onmouseout = () => card.style.transform = 'translateY(0)';
            
            const iconHTML = `<i class="fas fa-box" style="color:var(--primary); font-size:28px; margin-bottom:10px;"></i>`;
            
            card.innerHTML = `
                <div class="product-icon">${iconHTML}</div>
                <h3 style="font-size: 14px; margin-bottom: 5px; font-weight:700;">${prod.name}</h3>
                <p class="price" style="color: var(--primary); font-weight: 700; margin:0;">${fmt(prod.price)}</p>
                ${prod.commission > 0 ? `<p style="font-size:11px; color:var(--warning); margin:5px 0 0 0;"><i class="fas fa-hand-holding-dollar"></i> ${fmt(prod.commission)}</p>` : ''}
            `;
            
            card.onclick = () => {
                posAddProduct(prod);
            };
            
            posProductsGrid.appendChild(card);
        });
    };

    const productsSearchInput = document.getElementById('products-search-input');
    if(productsSearchInput) {
        productsSearchInput.addEventListener('input', () => {
            productsSearchQuery = productsSearchInput.value.trim();
            window.renderProducts();
        });
    }

    // =================================================================
    // ===================== الأقسام الإضافية (10) ====================
    // ==== (الموظفين - التقارير - الإحصائيات - إحصائيات الموظفين - ====
    // ====  العمولات - السجلات - المرتبات - المرتجعات - الإشعارات) ====
    // =================================================================

    // ---- قراءة وتوحيد البيانات القديمة مع الجديدة ----
    let employeesLog = JSON.parse(localStorage.getItem('employeesLog')) || [];
    let commissionsLog = JSON.parse(localStorage.getItem('commissionsLog')) || [];
    let salariesLog = JSON.parse(localStorage.getItem('salariesLog')) || [];
    let returnsLog = JSON.parse(localStorage.getItem('returnsLog')) || [];
    let notificationsLog = JSON.parse(localStorage.getItem('notificationsLog')) || [];
    window.renderCategories();
    window.renderProducts();

    // ================= المصروفات =================
    let expensesLog = JSON.parse(localStorage.getItem('expensesLog')) || [];

    function saveExpenses() {
        localStorage.setItem('expensesLog', JSON.stringify(expensesLog));
    }

    window.deleteExpense = function(id) {
        const exp = expensesLog.find(e => e.id === id);
        if(!exp) return;
        showConfirmModal('حذف مصروف', `هل أنت متأكد من حذف مصروف "${exp.title}" بمبلغ ${fmt(exp.amount)}؟`, () => {
            expensesLog = expensesLog.filter(e => e.id !== id);
            saveExpenses();
            renderExpenses();
            refreshReportSummary();
            addNotification(`حذف مصروف: ${exp.title}`, 'system');
            showToast('تم حذف المصروف', 'success');
        });
    };

    function renderExpenses() {
        const tbody = document.getElementById('expenses-tbody');
        const todayEl = document.getElementById('expenses-summary-today');
        const totalEl = document.getElementById('expenses-summary-total');
        const countEl = document.getElementById('expenses-summary-count');

        const dayKey = normEmpDate(new Date().toLocaleDateString('ar-EG'));
        let dayTotal = 0, todayCount = 0;
        expensesLog.forEach(e => {
            if(normEmpDate(e.date) === dayKey) { dayTotal += Number(e.amount) || 0; todayCount++; }
        });
        const allTotal = expensesLog.reduce((s, e) => s + (Number(e.amount) || 0), 0);
        if(todayEl) todayEl.textContent = fmt(dayTotal);
        if(countEl) countEl.textContent = todayCount;
        if(totalEl) totalEl.textContent = fmt(allTotal);

        if(!tbody) return;
        if(expensesLog.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-receipt" style="font-size:32px; margin-bottom:15px; display:block; opacity:0.3;"></i>لا توجد مصروفات مسجلة بعد.</td></tr>`;
            return;
        }
        tbody.innerHTML = '';
        [...expensesLog].sort((a, b) => (b.id || 0) - (a.id || 0)).forEach(e => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight:bold;">${e.title || '-'}</td>
                <td><span style="background:var(--bg-color); padding:4px 10px; border-radius:20px; font-size:12px; color:var(--text-muted);">${e.category || 'أخرى'}</span></td>
                <td style="font-weight:bold; color:var(--danger);">${fmt(e.amount)}</td>
                <td>${e.date || '-'}</td>
                <td>${e.empName || '-'}</td>
                <td>${e.note || '-'}</td>
                <td><button class="btn-icon-only" onclick="window.deleteExpense(${e.id})" style="color:var(--danger); background:transparent; border:none; cursor:pointer;" title="حذف"><i class="fas fa-trash"></i></button></td>
            `;
            tbody.appendChild(tr);
        });
    }

    const btnAddExpense = document.getElementById('btn-add-expense');
    if(btnAddExpense) {
        btnAddExpense.addEventListener('click', () => {
            const title = (document.getElementById('expense-title').value || '').trim();
            const amount = parseFloat(document.getElementById('expense-amount').value) || 0;
            const category = document.getElementById('expense-category').value;
            const note = (document.getElementById('expense-note').value || '').trim();
            let dateStr = document.getElementById('expense-date').value;
            if(!title) { showToast('أدخل بيان المصروف', 'error'); return; }
            if(amount <= 0) { showToast('أدخل مبلغاً صحيحاً', 'error'); return; }
            const todayVal = new Date();
            if(!dateStr) {
                dateStr = todayVal.toLocaleDateString('ar-EG');
            } else {
                const d = new Date(dateStr + 'T00:00:00');
                dateStr = d.toLocaleDateString('ar-EG');
            }
            expensesLog.push({
                id: Date.now(),
                title,
                amount,
                category,
                note,
                date: dateStr,
                time: todayVal.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
                empName: currentUser ? currentUser.name : ''
            });
            saveExpenses();
            renderExpenses();
            refreshReportSummary();
            addNotification(`مصروف جديد: ${title} بقيمة ${fmt(amount)}`, 'warning');
            showToast('تم تسجيل المصروف بنجاح', 'success');
            document.getElementById('expense-title').value = '';
            document.getElementById('expense-amount').value = '';
            document.getElementById('expense-note').value = '';
            document.getElementById('expense-date').value = '';
        });
    }

    // ================= الكسر والهالك =================
    let damageLog = JSON.parse(localStorage.getItem('damageLog')) || [];

    function saveDamage() {
        localStorage.setItem('damageLog', JSON.stringify(damageLog));
    }

    const damageModal = document.getElementById('damage-modal');
    const btnOpenDamage = document.getElementById('btn-open-damage-modal');
    const btnSaveDamage = document.getElementById('btn-save-damage');
    const btnCancelDamage = document.getElementById('btn-cancel-damage');
    const damageProductSelect = document.getElementById('damage-product-select');
    const damageQty = document.getElementById('damage-qty');
    const damageReason = document.getElementById('damage-reason');

    if(btnOpenDamage) {
        btnOpenDamage.addEventListener('click', () => {
            if(!damageProductSelect) return;
            damageProductSelect.innerHTML = '';
            const tracked = window.productsLog.filter(p => p.qty !== undefined && p.qty !== null && p.qty !== '');
            if(tracked.length === 0) {
                showToast('لا توجد منتجات بمخزون متابَع — أضف كمية للمنتج أولاً', 'warning');
                return;
            }
            tracked.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = `${p.name} (المخزون: ${p.qty})`;
                damageProductSelect.appendChild(opt);
            });
            if(damageQty) damageQty.value = 1;
            if(damageReason) damageReason.value = '';
            damageModal.classList.remove('hidden');
        });
    }

    if(btnSaveDamage) {
        btnSaveDamage.addEventListener('click', () => {
            const pid = damageProductSelect ? damageProductSelect.value : '';
            const prod = window.productsLog.find(p => p.id == pid);
            const qty = parseInt(damageQty.value) || 0;
            if(!prod) { showToast('اختر المنتج أولاً', 'error'); return; }
            if(qty <= 0) { showToast('أدخل كمية صحيحة', 'error'); return; }
            if(!(prod.qty !== undefined && prod.qty !== null && prod.qty !== '')) {
                showToast('هذا المنتج بلا مخزون متابَع', 'error'); return;
            }
            const available = Number(prod.qty) || 0;
            if(available < qty) { showToast('الكمية أكبر من المخزون المتاح!', 'error'); return; }
            prod.qty = available - qty;
            window.saveProductsToLocal();
            const now = new Date();
            damageLog.push({
                id: Date.now(),
                productId: prod.id,
                productName: prod.name,
                qty: qty,
                reason: (damageReason.value || '').trim(),
                date: now.toLocaleDateString('ar-EG'),
                time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
                empName: currentUser ? currentUser.name : ''
            });
            saveDamage();
            renderProducts();
            window.renderProductsSummary();
            damageModal.classList.add('hidden');
            showToast(`تم تسجيل الكسر: ${prod.name} (${qty})`, 'success');
            addNotification(`كسر/هالك: ${prod.name} -${qty} قطعة`, 'warning');
            if(typeof refreshReportSummary === 'function') refreshReportSummary();
        });
    }

    if(btnCancelDamage) {
        btnCancelDamage.addEventListener('click', () => { damageModal.classList.add('hidden'); });
    }

    // لو مفيش موظفين مسجلين، نزرع الافتراضيين للحفاظ على التوافق مع الشاشات القديمة
    function ensureDefaultEmployees() {
        if(employeesLog.length === 0) {
            employeesLog = [
                { id: 1, name: 'أحمد محمد', phone: '', job: 'كاشير', baseSalary: 3000, salaryType: 'monthly', hireDate: '', pin: '', shiftStart: null, shiftEnd: null, active: true, includeInSales: true },
                { id: 2, name: 'سارة جونسون', phone: '', job: 'مندوب مبيعات', baseSalary: 2500, salaryType: 'monthly', hireDate: '', pin: '', shiftStart: null, shiftEnd: null, active: true, includeInSales: true },
                { id: 3, name: 'خالد عبدالله', phone: '', job: 'كاشير', baseSalary: 2800, salaryType: 'monthly', hireDate: '', pin: '', shiftStart: null, shiftEnd: null, active: true, includeInSales: true }
            ];
            localStorage.setItem('employeesLog', JSON.stringify(employeesLog));
        }
    }
    ensureDefaultEmployees();

    function saveEmployees() { localStorage.setItem('employeesLog', JSON.stringify(employeesLog)); }
    function saveCommissions() { localStorage.setItem('commissionsLog', JSON.stringify(commissionsLog)); }
    function saveSalaries() { localStorage.setItem('salariesLog', JSON.stringify(salariesLog)); }
    function saveReturns() { localStorage.setItem('returnsLog', JSON.stringify(returnsLog)); }
    function saveNotifications() { localStorage.setItem('notificationsLog', JSON.stringify(notificationsLog)); }
    function saveSettings() {
        localStorage.setItem('storeSettings', JSON.stringify(storeSettings));
    }

    // ---- مساعد: رقم صحيح بالعملة ----
    function fmt(amount) {
        const safe = isNaN(Number(amount)) ? 0 : Number(amount);
        return safe.toFixed(2) + ' ' + storeSettings.currency;
    }

    // ---- إضافة إشعار داخلي ----
    function addNotification(message, type) {
        const t = type || 'info';
        const enabled = (storeSettings.notifEnabled || {})[t];
        if(enabled === false) return;
        const now = new Date();
        notificationsLog.push({
            id: Date.now(),
            type: t,
            message: message,
            date: now.toLocaleDateString('ar-EG'),
            time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
            read: false
        });
        saveNotifications();
        renderNotifications();
    }

    // =================> 1) الموظفين <=================
    const employeesTbody = document.getElementById('employees-tbody');
    const employeeSearchInput = document.getElementById('employee-search');
    const btnAddEmployee = document.getElementById('btn-add-employee');
    const employeeModal = document.getElementById('employee-modal');
    const btnSaveEmployee = document.getElementById('btn-save-employee');
    let editingEmployeeId = null;

    let employeePhotoData = '';
    function updateEmployeePhotoPreview() {
        const preview = document.getElementById('employee-photo-preview');
        if(!preview) return;
        if(employeePhotoData) {
            preview.innerHTML = `<img src="${employeePhotoData}" alt="" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">`;
        } else {
            preview.innerHTML = `<i class="fas fa-user"></i>`;
        }
    }

    const employeePhotoInput = document.getElementById('employee-photo-input');
    const btnEmployeePhotoUpload = document.getElementById('btn-employee-photo-upload');
    const btnEmployeePhotoRemove = document.getElementById('btn-employee-photo-remove');
    if(btnEmployeePhotoUpload) btnEmployeePhotoUpload.addEventListener('click', () => { if(employeePhotoInput) employeePhotoInput.click(); });
    if(employeePhotoInput) employeePhotoInput.addEventListener('change', () => {
        const file = employeePhotoInput.files && employeePhotoInput.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const maxSize = 300;
                let w = img.width, h = img.height;
                if(w > maxSize || h > maxSize) {
                    const ratio = Math.min(maxSize / w, maxSize / h);
                    w = Math.round(w * ratio);
                    h = Math.round(h * ratio);
                }
                const canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                employeePhotoData = canvas.toDataURL('image/jpeg', 0.7);
                updateEmployeePhotoPreview();
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
        employeePhotoInput.value = '';
    });
    if(btnEmployeePhotoRemove) btnEmployeePhotoRemove.addEventListener('click', () => {
        employeePhotoData = '';
        updateEmployeePhotoPreview();
    });

    // تعبئة كل قوائم الموظفين في النظام ديناميكياً
    function populateEmployeeSelects() {
        const selects = [
            'emp-select',        // الحضور والانصراف
            'sales-emp-select',  // المبيعات
            'note-emp-select',   // الملاحظات
            'loan-emp-select',   // السلف
            'commission-emp-filter', // العمولات
            'salary-emp-select',  // المرتبات
            'scheduled-note-emp-select' // الملاحظات المجدولة
        ];
        selects.forEach(id => {
            const sel = document.getElementById(id);
            if(!sel) return;
            const previous = sel.value;
            sel.innerHTML = '';
            const placeholder = id === 'emp-select' ? '-- يرجى اختيار الموظف أولاً --' : '-- اختر الموظف --';
            sel.innerHTML = `<option value="" disabled selected>${placeholder}</option>`;
            employeesLog.filter(e => e.active !== false && (id !== 'sales-emp-select' || e.includeInSales !== false)).forEach(emp => {
                const opt = document.createElement('option');
                opt.value = emp.id;
                opt.textContent = emp.name;
                sel.appendChild(opt);
            });
            if(previous && Array.from(sel.options).some(o => o.value === previous)) sel.value = previous;
            if(id === 'sales-emp-select' && currentUser && currentUser.type === 'employee' && currentUser.empId != null) {
                const empOpt = Array.from(sel.options).find(o => o.value === String(currentUser.empId));
                if(empOpt) sel.value = empOpt.value;
            }
        });
    }

    function renderEmployees() {
        if(!employeesTbody) return;
        const query = employeeSearchInput ? employeeSearchInput.value.trim().toLowerCase() : '';
        const filtered = employeesLog.filter(e => !query || e.name.toLowerCase().includes(query) || (e.job || '').toLowerCase().includes(query));

        if(filtered.length === 0) {
            employeesTbody.innerHTML = `
                <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-user-tie" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    ${employeesLog.length === 0 ? 'لا يوجد موظفون مسجلون' : 'لا توجد نتائج مطابقة للبحث'}
                </td></tr>`;
            return;
        }

        employeesTbody.innerHTML = '';
        filtered.forEach(emp => {
            const tr = document.createElement('tr');
            const statusHtml = emp.active !== false
                ? `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">مفعل</span>`
                : `<span class="status-badge" style="background-color: var(--bg-color); color: var(--text-muted);">موقوف</span>`;
            const shiftText = emp.shiftStart
                ? `من ${emp.shiftStart} إلى ${emp.shiftEnd}`
                : 'لا يوجد';
            const salaryTypeMap = { monthly: 'شهري', weekly: 'أسبوعي', hourly: 'بالساعة' };
            const salaryTypeText = salaryTypeMap[emp.salaryType] || 'شهري';
            const includeSalesHtml = emp.includeInSales === false
                ? ` <span class="status-badge" style="background-color: var(--bg-color); color: var(--text-muted);" title="غير ظاهر في المبيعات">بدون مبيعات</span>`
                : '';
            const avatarHtml = emp.photo
                ? `<div class="emp-avatar" style="background: transparent; box-shadow: none; border: 2px solid rgba(var(--primary-rgb), 0.3);"><img src="${emp.photo}" alt="" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;"></div>`
                : `<div class="emp-avatar" style="background: linear-gradient(135deg,var(--primary),var(--primary-hover)); color:white;">${emp.name.charAt(0)}</div>`;
            tr.innerHTML = `
                <td>
                    <div class="emp-cell">
                        ${avatarHtml}
                        <span class="emp-name">${emp.name}</span>
                    </div>
                </td>
                <td style="color: var(--text-muted);">${shiftText}</td>
                <td style="color: var(--text-muted);">${salaryTypeText}</td>
                <td style="font-weight: 700; color: var(--success);">${fmt(emp.baseSalary || 0)}</td>
                <td>${statusHtml}${includeSalesHtml}</td>
                <td class="admin-table-cell">
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button class="btn-icon-only" title="تعديل" onclick="window.editEmployee(${emp.id})" style="color: var(--gold-deep); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="window.deleteEmployee(${emp.id})" style="color: var(--danger); background: transparent; border: none; cursor: pointer; font-size: 16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            employeesTbody.appendChild(tr);
        });
    }

    window.editEmployee = function(id) {
        const emp = employeesLog.find(e => e.id === id);
        if(!emp) return;
        editingEmployeeId = id;
        document.getElementById('employee-modal-title').textContent = 'تعديل بيانات الموظف';
        document.getElementById('employee-name').value = emp.name;
        document.getElementById('employee-phone').value = emp.phone || '';
        document.getElementById('employee-job').value = emp.job || '';
        document.getElementById('employee-salary').value = emp.baseSalary || 0;
        document.getElementById('employee-salary-type').value = emp.salaryType || 'monthly';
        document.getElementById('employee-hiredate').value = emp.hireDate || '';
        document.getElementById('employee-pin').value = emp.pin || '';
        const hasShift = !!(emp.shiftStart && emp.shiftEnd);
        document.getElementById('employee-has-shift').checked = hasShift;
        const shiftInputs = document.getElementById('employee-shift-inputs');
        const shiftStart = document.getElementById('employee-shift-start');
        const shiftEnd = document.getElementById('employee-shift-end');
        if(hasShift) {
            if(shiftInputs) shiftInputs.style.opacity = '1';
            shiftStart.disabled = false;
            shiftEnd.disabled = false;
            shiftStart.value = emp.shiftStart || '';
            shiftEnd.value = emp.shiftEnd || '';
        } else {
            if(shiftInputs) shiftInputs.style.opacity = '0.5';
            shiftStart.disabled = true;
            shiftEnd.disabled = true;
            shiftStart.value = '';
            shiftEnd.value = '';
        }
        document.getElementById('employee-active').checked = emp.active !== false;
        document.getElementById('employee-include-sales').checked = emp.includeInSales !== false;
        employeePhotoData = emp.photo || '';
        updateEmployeePhotoPreview();
        employeeModal.classList.remove('hidden');
    };

    window.deleteEmployee = function(id) {
        const emp = employeesLog.find(e => e.id === id);
        if(!emp) return;
        showConfirm('حذف موظف', `هل أنت متأكد من حذف ${emp.name} نهائياً؟ ستبقى سجلاته التاريخية محفوظة.`, () => {
            employeesLog = employeesLog.filter(e => e.id !== id);
            saveEmployees();
            renderEmployees();
            populateEmployeeSelects();
            showToast('تم حذف الموظف بنجاح', 'success');
        });
    };

    const btnClearEmployees = document.getElementById('btn-clear-employees');
    if(btnClearEmployees) {
        btnClearEmployees.addEventListener('click', () => {
            if(employeesLog.length === 0) { showToast('لا يوجد موظفون لمسحهم', 'warning'); return; }
            showConfirm('حذف جميع الموظفين', 'هل أنت متأكد من حذف جميع الموظفين نهائياً؟ ستبقى السجلات التاريخية محفوظة. لا يمكن التراجع عن هذا الإجراء.', () => {
                employeesLog = [];
                saveEmployees();
                renderEmployees();
                populateEmployeeSelects();
                showToast('تم حذف جميع الموظفين بنجاح', 'success');
            });
        });
    }

    if(btnAddEmployee && employeeModal) {
        btnAddEmployee.addEventListener('click', () => {
            editingEmployeeId = null;
            document.getElementById('employee-modal-title').textContent = 'إضافة موظف جديد';
            document.getElementById('employee-name').value = '';
            document.getElementById('employee-phone').value = '';
            document.getElementById('employee-job').value = '';
            document.getElementById('employee-salary').value = '0';
            document.getElementById('employee-salary-type').value = 'monthly';
            document.getElementById('employee-hiredate').value = new Date().toISOString().slice(0, 10);
            document.getElementById('employee-pin').value = '';
            document.getElementById('employee-has-shift').checked = false;
            const shiftInputs = document.getElementById('employee-shift-inputs');
            const shiftStart = document.getElementById('employee-shift-start');
            const shiftEnd = document.getElementById('employee-shift-end');
            if(shiftInputs) shiftInputs.style.opacity = '0.5';
            shiftStart.disabled = true;
            shiftEnd.disabled = true;
            shiftStart.value = '';
            shiftEnd.value = '';
            document.getElementById('employee-active').checked = true;
            document.getElementById('employee-include-sales').checked = true;
            employeePhotoData = '';
            updateEmployeePhotoPreview();
            employeeModal.classList.remove('hidden');
        });
    }

    const employeeHasShift = document.getElementById('employee-has-shift');
    if(employeeHasShift) {
        employeeHasShift.addEventListener('change', () => {
            const shiftInputs = document.getElementById('employee-shift-inputs');
            const shiftStart = document.getElementById('employee-shift-start');
            const shiftEnd = document.getElementById('employee-shift-end');
            const on = employeeHasShift.checked;
            if(shiftInputs) shiftInputs.style.opacity = on ? '1' : '0.5';
            shiftStart.disabled = !on;
            shiftEnd.disabled = !on;
            if(!on) { shiftStart.value = ''; shiftEnd.value = ''; }
        });
    }

    if(btnSaveEmployee) {
        btnSaveEmployee.addEventListener('click', () => {
            const name = document.getElementById('employee-name').value.trim();
            if(!name) { showToast('الرجاء إدخال اسم الموظف', 'error'); return; }
            const phone = document.getElementById('employee-phone').value.trim();
            const job = document.getElementById('employee-job').value.trim();
            const baseSalary = parseFloat(document.getElementById('employee-salary').value) || 0;
            const salaryType = document.getElementById('employee-salary-type').value;
            const hireDate = document.getElementById('employee-hiredate').value;
            const pin = document.getElementById('employee-pin').value.trim();
            const hasShift = document.getElementById('employee-has-shift').checked;
            const shiftStart = document.getElementById('employee-shift-start').value;
            const shiftEnd = document.getElementById('employee-shift-end').value;
            const active = document.getElementById('employee-active').checked;
            const includeInSales = document.getElementById('employee-include-sales').checked;

            if(editingEmployeeId) {
                const emp = employeesLog.find(e => e.id === editingEmployeeId);
                if(emp) {
                    emp.name = name; emp.phone = phone; emp.job = job;
                    emp.baseSalary = baseSalary; emp.salaryType = salaryType;
                    emp.hireDate = hireDate; emp.pin = pin;
                    emp.shiftStart = hasShift ? shiftStart : null;
                    emp.shiftEnd = hasShift ? shiftEnd : null;
                    emp.active = active; emp.includeInSales = includeInSales;
                    emp.photo = employeePhotoData;
                }
                showToast('تم تعديل بيانات الموظف بنجاح', 'success');
            } else {
                employeesLog.push({ id: Date.now(), name, phone, job, baseSalary, salaryType, hireDate, pin, shiftStart: hasShift ? shiftStart : null, shiftEnd: hasShift ? shiftEnd : null, active, includeInSales, photo: employeePhotoData });
                showToast('تم إضافة الموظف بنجاح', 'success');
            }
            saveEmployees();
            renderEmployees();
            populateEmployeeSelects();
            employeeModal.classList.add('hidden');
        });
    }

    if(employeeSearchInput) {
        employeeSearchInput.addEventListener('input', renderEmployees);
    }

    populateEmployeeSelects();
    renderEmployees();

    // =================> 2) التقارير <=================
    const reportTypeFilter = document.getElementById('report-type-filter');
    const reportTbody = document.getElementById('report-tbody');
    const reportTypeLabels = {
        sales: 'المبيعات',
        purchases: 'المشتريات',
        expenses: 'المصروفات',
        loans: 'السحوبات والخصومات',
        returns: 'المرتجعات',
        damage: 'الكسر والهالك',
        attendance: 'الحضور والانصراف'
    };

    function getReportRange() {
        const fromEl = document.getElementById('report-from-date');
        const toEl = document.getElementById('report-to-date');
        const from = fromEl && fromEl.value ? fromEl.value : '';
        const to = toEl && toEl.value ? toEl.value : '';
        return { from, to };
    }

    function reportInRange(dateStr) {
        const { from, to } = getReportRange();
        if(!from && !to) return true;
        const key = normEmpDate(dateStr);
        if(!key) return true;
        if(from && key < from) return false;
        if(to && key > to) return false;
        return true;
    }

    function refreshReportSummary() {
        const fSales = salesLog.filter(x => reportInRange(x.date));
        const fPurchases = purchasesLog.filter(x => reportInRange(x.date));
        const fLoans = loansLog.filter(x => reportInRange(x.date));
        const fReturns = returnsLog.filter(x => reportInRange(x.date));
        const fExpenses = expensesLog.filter(x => reportInRange(x.date));

        const totalSales = fSales.reduce((s, x) => s + (x.totalAmount || 0), 0);
        const totalPurchases = fPurchases.reduce((s, x) => s + (x.total || 0), 0);
        const totalLoans = fLoans.reduce((s, x) => s + (x.amount || 0), 0);
        const totalReturns = fReturns.reduce((s, x) => s + (x.amount || 0), 0);
        const totalExpenses = fExpenses.reduce((s, x) => s + (x.amount || 0), 0);

        setText('report-total-sales', fmt(totalSales));
        setText('report-sales-count', fSales.length);
        setText('report-total-purchases', fmt(totalPurchases));
        setText('report-purchases-count', fPurchases.length);
        setText('report-total-loans', fmt(totalLoans));
        setText('report-loans-count', fLoans.length);
        setText('report-total-returns', fmt(totalReturns));
        setText('report-returns-count', fReturns.length);
        setText('report-total-expenses', fmt(totalExpenses));
        setText('report-expenses-count', fExpenses.length);
        let totalGrossProfit = 0;
        fSales.forEach(x => {
            if(x.grossProfit != null) {
                totalGrossProfit += Number(x.grossProfit) || 0;
            } else if(x.items && Array.isArray(x.items)) {
                x.items.forEach(it => totalGrossProfit += ((Number(it.price) || 0) - (Number(it.cost) || 0)) * (Number(it.quantity) || 1));
            }
        });
        totalGrossProfit = Math.max(totalGrossProfit, 0);
        setText('report-gross-profit', fmt(totalGrossProfit));
        const net = totalGrossProfit - totalReturns - totalExpenses;
        setText('report-net-profit', fmt(net));
        const netEl = document.getElementById('report-net-profit');
        if(netEl) netEl.style.color = net >= 0 ? 'var(--success)' : 'var(--danger)';
    }

    function setText(id, val) {
        const el = document.getElementById(id);
        if(el) el.textContent = val;
    }

    function renderReport() {
        if(!reportTbody) return;
        const type = reportTypeFilter ? reportTypeFilter.value : 'sales';
        const typeBadge = document.getElementById('report-current-type-badge');
        if(typeBadge) {
            typeBadge.textContent = reportTypeLabels[type] || 'التقرير';
            const badgeColors = {
                sales: 'var(--success)',
                purchases: 'var(--primary)',
                expenses: 'var(--danger)',
                loans: 'var(--warning)',
                returns: 'var(--danger)',
                damage: 'var(--danger)',
                attendance: 'var(--primary)'
            };
            typeBadge.style.color = badgeColors[type] || 'var(--primary)';
            typeBadge.style.backgroundColor = (badgeColors[type] || 'var(--primary)') + '1a';
        }
        let rows = [];

        if(type === 'sales') {
            rows = salesLog.filter(x => reportInRange(x.date)).map(s => ({
                emp: s.empName,
                desc: s.description,
                qty: s.totalQty,
                amount: s.totalAmount,
                when: `${s.time} - ${s.date || ''}`,
                status: 'مكتمل'
            }));
        } else if(type === 'loans') {
            rows = loansLog.filter(x => reportInRange(x.date)).map(l => ({
                emp: l.empName,
                desc: l.reason || 'سحب',
                qty: '-',
                amount: l.amount,
                when: `${l.time} ${l.date || ''}`,
                status: 'سحب'
            }));
        } else if(type === 'returns') {
            rows = returnsLog.filter(x => reportInRange(x.date)).map(r => ({
                emp: r.empName || '-',
                desc: `${r.product || ''}${r.reason ? ' ( ' + r.reason + ' )' : ''}`,
                qty: r.qty,
                amount: r.amount,
                when: `${r.time} ${r.date || ''}`,
                status: 'مرتجع'
            }));
        } else if(type === 'purchases') {
            rows = purchasesLog.filter(x => reportInRange(x.date)).map(p => ({
                emp: p.supplier || '-',
                desc: `فاتورة #${p.invoice}${p.reference ? ' - ' + p.reference : ''}`,
                qty: '-',
                amount: p.total,
                when: p.date || '',
                status: 'مشتريات'
            }));
        } else if(type === 'expenses') {
            rows = expensesLog.filter(x => reportInRange(x.date)).map(e => ({
                emp: e.empName || '-',
                desc: `${e.title || ''}${e.note ? ' ( ' + e.note + ' )' : ''}`,
                qty: e.category || 'أخرى',
                amount: e.amount,
                when: `${e.time || ''} ${e.date || ''}`,
                status: 'مصروف'
            }));
        } else if(type === 'attendance') {
            rows = attendanceLog.filter(x => reportInRange(x.date)).map(a => ({
                emp: a.empName,
                desc: a.timeOut
                    ? a.timeIn + ' ' + String.fromCharCode(8594) + ' ' + a.timeOut
                    : 'حضور ' + a.timeIn,
                qty: '-',
                amount: 0,
                when: a.date || '',
                status: a.status === 'active' ? 'حاضر' : 'انصرف'
            }));
        } else if(type === 'damage') {
            rows = damageLog.filter(x => reportInRange(x.date)).map(d => {
                const prod = window.productsLog ? window.productsLog.find(p => p.id == d.productId) : null;
                const unitPrice = prod ? (Number(prod.price) || 0) : 0;
                return {
                    emp: d.empName || '-',
                    desc: (d.productName || '') + (d.reason ? ' ( ' + d.reason + ' )' : ''),
                    qty: d.qty,
                    amount: unitPrice * d.qty,
                    when: d.time + ' ' + d.date,
                    status: 'كسر/هالك'
                };
            });
        }

        const countBadge = document.getElementById('report-record-count');
        if(countBadge) countBadge.textContent = rows.length + ' سجل';

        if(rows.length === 0) {
            reportTbody.innerHTML = `
                <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-chart-pie" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    لا توجد بيانات في هذا التقرير
                </td></tr>`;
            return;
        }

        reportTbody.innerHTML = '';
        [...rows].reverse().forEach(r => {
            const tr = document.createElement('tr');
            const badgeColor = r.status === 'مكتمل' ? 'var(--success)' : (r.status === 'مرتجع' || r.status === 'مصروف' || r.status === 'مشتريات' || r.status === 'كسر/هالك' ? 'var(--danger)' : 'var(--primary)');
            tr.innerHTML = `
                <td><strong>${r.emp}</strong></td>
                <td style="text-align: right;">${r.desc}</td>
                <td>${r.qty}</td>
                <td style="font-weight: 700; color: var(--primary);">${fmt(r.amount)}</td>
                <td>${r.when}</td>
                <td><span class="status-badge" style="background-color: ${badgeColor}1a; color: ${badgeColor};">${r.status}</span></td>
            `;
            reportTbody.appendChild(tr);
        });
    }

    function applyReportFilters() {
        renderReport();
        refreshReportSummary();
    }

    if(reportTypeFilter) reportTypeFilter.addEventListener('change', applyReportFilters);
    const reportFromEl = document.getElementById('report-from-date');
    const reportToEl = document.getElementById('report-to-date');
    if(reportFromEl) reportFromEl.addEventListener('change', applyReportFilters);
    if(reportToEl) reportToEl.addEventListener('change', applyReportFilters);
    document.querySelectorAll('[data-report-quick]').forEach(btn => {
        btn.addEventListener('click', () => {
            const q = btn.getAttribute('data-report-quick');
            const setD = (id, val) => { const el = document.getElementById(id); if(el) el.value = val; };
            const pad = n => String(n).padStart(2, '0');
            const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
            const today = new Date();
            let from = '', to = ymd(today);
            if(q === 'today') from = to;
            else if(q === 'week') { const w = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6); from = ymd(w); }
            else if(q === 'month') from = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-01`;
            else if(q === 'year') from = `${today.getFullYear()}-01-01`;
            else { from = ''; to = ''; }
            setD('report-from-date', from);
            setD('report-to-date', to);
            applyReportFilters();
        });
    });

    const btnPrintReport = document.getElementById('btn-print-report');
    if(btnPrintReport) {
        btnPrintReport.addEventListener('click', () => {
            const win = window.open('', '_blank', 'width=860,height=700');
            if(!win) { showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'error'); return; }

            const type = reportTypeFilter ? reportTypeFilter.value : 'sales';
            const typeTitle = (reportTypeLabels[type] || 'التقرير');
            const tbody = document.getElementById('report-tbody');
            const trs = tbody ? tbody.querySelectorAll('tr') : [];
            let rowsHtml = '';
            let total = 0;
            let firstDate = null, lastDate = null;
            trs.forEach(tr => {
                const cells = tr.querySelectorAll('td');
                if(cells.length < 6) return;
                const empty = tr.querySelector('td[colspan]');
                if(empty) return;
                const desc = cells[1].textContent.trim();
                const date = cells[4].textContent.trim();
                const amountText = cells[3].textContent.trim().replace(/[^\d.,-]/g, '');
                const amount = parseFloat(amountText.replace(/,/g, '')) || 0;
                total += amount;
                if(date) {
                    if(!firstDate) firstDate = date;
                    lastDate = date;
                }
                rowsHtml += `<tr>
                    <td style="text-align: right;">${desc}</td>
                    <td style="text-align: center;">${date}</td>
                    <td style="text-align: left;">${Number(amount).toFixed(2)}</td>
                </tr>`;
            });

            if(!rowsHtml) {
                rowsHtml = `<tr><td colspan="3" style="text-align:center; padding:16px; color:#6b7280;">لا توجد بيانات</td></tr>`;
            }

            const period = (firstDate && lastDate && firstDate !== lastDate)
                ? `من ${firstDate} إلى ${lastDate}`
                : (firstDate ? `من ${firstDate}` : new Date().toLocaleDateString('ar-EG'));
            const nowTime = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            const storeName = storeSettings.storeName || 'DataGris Store';
            const currency = storeSettings.currency || 'ج.م';

            // باركود Code128 حقيقي (يحمل إجمالي التقرير)
            const barcodeSvg = barcodeSVG('TOT=' + Number(total).toFixed(2), 1.2, 34);

            win.document.write(`
                <!DOCTYPE html>
                <html dir="rtl" lang="ar">
                <head>
                    <meta charset="UTF-8">
                    <title>${typeTitle} - ${storeName}</title>
                    <style>
                        * { box-sizing: border-box; margin: 0; padding: 0; }
                        body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; background: #fff; color: #111; padding: 24px; }
                        .report { max-width: 640px; margin: 0 auto; background: #fff; border: 1px solid #d1d5db; border-radius: 10px; padding: 26px 30px; }
                        .top { display: flex; justify-content: space-between; align-items: flex-start; gap: 14px; }
                        .dollar-icon { width: 40px; height: 40px; min-width: 40px; border: 2px solid #111; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 22px; color: #111; }
                        .title-wrap { flex: 1; text-align: center; }
                        h1 { font-size: 22px; font-weight: 800; color: #111; }
                        .meta { font-size: 13px; line-height: 1.9; text-align: right; color: #374151; }
                        .meta b { color: #111; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 13.5px; }
                        th { background: #f3f4f6; color: #111; font-weight: 700; border: 1px solid #d1d5db; padding: 9px 10px; }
                        td { border: 1px solid #d1d5db; padding: 8px 10px; }
                        .total-box { display: flex; justify-content: space-between; align-items: center; border: 2px solid #111; border-radius: 8px; background: #fafafa; padding: 12px 18px; margin-top: 18px; font-weight: 700; font-size: 16px; color: #111; }
                        .total-box .amt { font-size: 19px; font-weight: 900; }
                        .footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 22px; font-size: 12px; color: #6b7280; }
                        .footer .time { padding-top: 8px; }
                        .barcode { display: block; }
                        .barcode svg { height: 36px; display: block; }
                        .bcode-text { font-size: 10px; color: #6b7280; text-align: center; direction: ltr; letter-spacing: 1px; }
                        .page { padding-top: 8px; }
                        @media print {
                            body { padding: 0; }
                            .report { border: none; border-radius: 0; }
                        }
                    </style>
                </head>
                <body>
                    <div class="report">
                        <div class="top">
                            <div class="dollar-icon">$</div>
                            <div class="title-wrap"><h1>${typeTitle}</h1></div>
                            <div class="meta">
                                <div><b>اسم المتجر:</b> ${storeName}</div>
                                <div><b>الفترة:</b> ${period}</div>
                            </div>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th style="text-align: right;">البيان</th>
                                    <th style="text-align: center;">التاريخ</th>
                                    <th style="text-align: left;">المبلغ</th>
                                </tr>
                            </thead>
                            <tbody>${rowsHtml}</tbody>
                        </table>
                        <div class="total-box">
                            <span>إجمالي ${typeTitle}:</span>
                            <span class="amt">${Number(total).toFixed(2)} ${currency}</span>
                        </div>
                        <div class="footer">
                            <span class="time">${nowTime}</span>
                            <span class="barcode">${barcodeSvg}<span class="bcode-text">TOT=${Number(total).toFixed(2)}</span></span>
                            <span class="page">Page 1 of 1</span>
                        </div>
                    </div>
                    <script>window.onload = function(){ window.focus(); window.print(); }<\/script>
                </body>
                </html>`);
            win.document.close();
        });
    }

    // =================> 3) الإحصائيات العامة <=================
    function renderStats() {
        const totalSales = salesLog.reduce((s, x) => s + (x.totalAmount || 0), 0);
        const orderCount = salesLog.length;
        const avgInvoice = orderCount ? totalSales / orderCount : 0;
        const customersCount = window.customersLog ? window.customersLog.length : 0;
        const employeesCount = employeesLog.length;
        const productsCount = window.productsLog ? window.productsLog.length : 0;

        setText('stats-total-sales', fmt(totalSales));
        setText('stats-order-count', orderCount);
        setText('stats-avg-invoice', fmt(avgInvoice));
        setText('stats-customers-count', customersCount);
        setText('stats-employees-count', employeesCount);
        setText('stats-products-count', productsCount);

        const topProducts = {};
        salesLog.forEach(s => {
            if(!s.description) return;
            s.description.split('،').forEach(part => {
                const match = part.match(/^(.+?)\s*\((\d+)\)\s*$/);
                const name = match ? match[1].trim() : part.trim();
                const qty = match ? parseInt(match[2]) : 1;
                topProducts[name] = (topProducts[name] || 0) + qty;
            });
        });

        const topProductsEl = document.getElementById('stats-top-products');
        const topEmployeesEl = document.getElementById('stats-top-employees');
        const entries = Object.entries(topProducts).sort((a,b) => b[1] - a[1]).slice(0, 5);

        if(topProductsEl) {
            if(entries.length === 0) {
                topProductsEl.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:20px;">لا توجد بيانات بعد</div>';
            } else {
                topProductsEl.innerHTML = entries.map(([name, qty], i) => `
                    <div style="display:flex; align-items:center; gap:12px; padding:10px; background:var(--bg-color); border-radius:10px;">
                        <span style="width:28px; height:28px; border-radius:50%; background: linear-gradient(135deg, var(--primary), var(--primary-hover)); color:white; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px;">${i+1}</span>
                        <span style="flex:1; font-weight:700;">${name}</span>
                        <span style="font-weight:800; color:var(--primary);">${qty} قطعة</span>
                    </div>`).join('');
            }
        }

        const empSales = {};
        salesLog.forEach(s => {
            const key = s.empName || '-';
            if(!empSales[key]) empSales[key] = 0;
            empSales[key] += (s.totalAmount || 0);
        });
        const topEmps = Object.entries(empSales).sort((a,b) => b[1] - a[1]).slice(0, 5);

        if(topEmployeesEl) {
            if(topEmps.length === 0) {
                topEmployeesEl.innerHTML = '<div style="text-align:center; color:var(--text-muted); padding:20px;">لا توجد بيانات بعد</div>';
            } else {
                topEmployeesEl.innerHTML = topEmps.map(([name, total], i) => `
                    <div style="display:flex; align-items:center; gap:12px; padding:10px; background:var(--bg-color); border-radius:10px;">
                        <span style="width:28px; height:28px; border-radius:50%; background: linear-gradient(135deg,var(--primary),var(--primary-hover)); color:white; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px;">${i+1}</span>
                        <span style="flex:1; font-weight:700;">${name}</span>
                        <span style="font-weight:800; color:var(--success);">${fmt(total)}</span>
                    </div>`).join('');
            }
        }
    }

    // =================> 4) إحصائيات الموظفين <=================
    function calcSaleCommission(sale) {
        const def = storeSettings.defaultProductCommission || 0;
        let total = 0;
        if(sale && Array.isArray(sale.items) && sale.items.length > 0) {
            sale.items.forEach(item => {
                let pc = 0;
                if(window.productsLog && window.productsLog.length) {
                    const prod = window.productsLog.find(p => p.name === item.name);
                    pc = prod ? (Number(prod.commission) || 0) : 0;
                }
                if(pc <= 0) pc = def;
                total += pc * (Number(item.quantity) || 0);
            });
        } else {
            total = (sale.totalQty || 0) * def;
        }
        return total;
    }

    function normEmpDate(d) {
        if(!d) return '';
        const s = String(d)
            .replace(/[٠-٩]/g, ch => '٠١٢٣٤٥٦٧٨٩'.indexOf(ch))
            .replace(/[۰-۹]/g, ch => '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch));
        const months = { 'يناير': 1, 'فبراير': 2, 'مارس': 3, 'أبريل': 4, 'مايو': 5, 'يونيو': 6, 'يوليو': 7, 'أغسطس': 8, 'سبتمبر': 9, 'أكتوبر': 10, 'نوفمبر': 11, 'ديسمبر': 12 };
        let m = s.match(/(\d{1,4})\s+([\u0600-\u06FF]+)\s+(\d{1,4})/);
        if(m && months[m[2]]) {
            return `${Number(m[3])}-${String(months[m[2]]).padStart(2, '0')}-${String(Number(m[1])).padStart(2, '0')}`;
        }
        m = s.match(/(\d{1,4})[\/\-](\d{1,2})[\/\-](\d{1,4})/);
        if(m) {
            const a = Number(m[1]), b = Number(m[2]), c = Number(m[3]);
            let day, month, year;
            if(a > 31) { year = a; day = b; month = c; }
            else if(c > 31) { year = c; day = a; month = b; }
            else { day = a; month = b; year = c; }
            return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        }
        return s;
    }

    function renderEmployeeStats() {
        const empSelect = document.getElementById('emp-stats-emp-select');
        const daySelect = document.getElementById('emp-stats-day-select');
        const summaryEl = document.getElementById('emp-stats-summary');
        const attBody = document.getElementById('emp-stats-attendance-body');
        const salesBody = document.getElementById('emp-stats-sales-body');
        if(!empSelect || !daySelect || !summaryEl || !attBody || !salesBody) return;

        empSelect.onchange = renderEmployeeStats;
        daySelect.onchange = renderEmployeeStats;

        const prevEmp = empSelect.value;
        empSelect.innerHTML = '<option value="" disabled selected>-- الموظف --</option>';
        employeesLog.filter(e => e.active !== false).forEach(e => {
            const opt = document.createElement('option');
            opt.value = e.id;
            opt.textContent = e.name;
            empSelect.appendChild(opt);
        });
        if(prevEmp) {
            const stillThere = Array.from(empSelect.options).some(o => o.value === String(prevEmp));
            if(stillThere) empSelect.value = prevEmp;
        }

        const dayMap = new Map();
        [attendanceLog, salesLog, returnsLog].forEach(list => {
            list.forEach(r => {
                const key = normEmpDate(r.date);
                if(key && !dayMap.has(key)) dayMap.set(key, r.date);
            });
        });
        const sortedKeys = [...dayMap.keys()].sort((a, b) => (a < b ? 1 : a > b ? -1 : 0));

        const prevDay = daySelect.value;
        const prevKey = prevDay ? normEmpDate(prevDay) : '';
        daySelect.innerHTML = '<option value="" disabled selected>-- اختر اليوم --</option>';
        sortedKeys.forEach(k => {
            const opt = document.createElement('option');
            opt.value = dayMap.get(k);
            opt.textContent = dayMap.get(k);
            daySelect.appendChild(opt);
        });
        if(prevKey) {
            const match = Array.from(daySelect.options).find(o => normEmpDate(o.value) === prevKey);
            if(match) daySelect.value = match.value;
        }

        const emptyMsg = (cols, msg) => `<tr><td colspan="${cols}" style="text-align:center; padding:30px; color:var(--text-muted);">${msg}</td></tr>`;

        const empId = empSelect.value;
        const day = daySelect.value;
        if(!empId || !day) {
            summaryEl.innerHTML = '';
            attBody.innerHTML = emptyMsg(4, 'اختر الموظف واليوم لعرض سجل الحضور');
            salesBody.innerHTML = emptyMsg(7, 'اختر الموظف واليوم لعرض المبيعات');
            return;
        }

        const emp = employeesLog.find(e => e.id == empId);
        const dayKey = normEmpDate(day);
        const attRows = attendanceLog.filter(a => a.empId == empId && normEmpDate(a.date) === dayKey);
        const salesRows = salesLog.filter(s => (s.empName === emp.name || s.empId == empId) && normEmpDate(s.date) === dayKey);

        const returnsForDay = returnsLog.filter(r => r.empName === emp.name && normEmpDate(r.date) === dayKey);
        const returnedInvoices = new Set(returnsForDay.map(r => String(r.invoice).trim()));
        const activeSales = salesRows.filter(s => !returnedInvoices.has(String(s.id).trim()));

        const totalQty = activeSales.reduce((sum, x) => sum + (x.totalQty || 0), 0);
        const totalRevenue = activeSales.reduce((sum, x) => sum + (x.totalAmount || 0), 0);
        const commissions = activeSales.reduce((sum, x) => sum + calcSaleCommission(x), 0);
        const returnsCount = returnsForDay.length;

        summaryEl.innerHTML = `
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-header"><h3>قطع ناجحة</h3></div>
                    <div class="stat-value" style="color: var(--success);">${totalQty}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-header"><h3>إيرادات اليوم</h3></div>
                    <div class="stat-value" style="color: var(--primary);">${fmt(totalRevenue)}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-header"><h3>عمولة اليوم</h3></div>
                    <div class="stat-value" style="color: var(--warning);">${fmt(commissions)}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-header"><h3>مرتجعات اليوم</h3></div>
                    <div class="stat-value" style="color: var(--danger);">${returnsCount}</div>
                </div>
            </div>
        `;

        if(attRows.length === 0) {
            attBody.innerHTML = emptyMsg(4, 'لا يوجد حضور/انصراف مسجل في هذا اليوم');
        } else {
            attBody.innerHTML = '';
            attRows.forEach(a => {
                const hours = (a.timeInMs && a.timeOutMs)
                    ? (Math.max(0, (a.timeOutMs - a.timeInMs) - (a.breakTotalMs || 0)) / 3600000)
                    : (a.workHours || 0);
                const statusHtml = a.status === 'active'
                    ? `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">حاضر</span>`
                    : (a.status === 'absent'
                        ? `<span class="status-badge" style="background-color: var(--danger-bg); color: var(--danger);">غائب</span>`
                        : `<span class="status-badge" style="background-color: var(--warning); color: white;">منصرف</span>`);
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${statusHtml}</td>
                    <td style="font-weight:700;">${a.timeIn || '--:--'}</td>
                    <td style="font-weight:700;">${a.timeOut || '--:--'}</td>
                    <td style="font-weight:700;">${+hours.toFixed(1)} س</td>
                `;
                attBody.appendChild(tr);
            });
        }

        if(salesRows.length === 0) {
            salesBody.innerHTML = emptyMsg(7, 'لا توجد مبيعات في هذا اليوم');
        } else {
            salesBody.innerHTML = '';
            [...salesRows].sort((a, b) => ((a.time || '') > (b.time || '') ? 1 : -1)).forEach(s => {
                const comm = calcSaleCommission(s);
                const isRet = returnedInvoices.has(String(s.id).trim());
                const statusHtml = isRet
                    ? `<span class="status-badge" style="background-color: var(--danger-bg); color: var(--danger);">مرتجع</span>`
                    : `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">تم البيع</span>`;
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="font-weight:700;">#${s.id}</td>
                    <td style="text-align:right;">${s.description || '-'}</td>
                    <td style="font-weight:700;">${s.totalQty || 0}</td>
                    <td style="font-weight:700; color:var(--primary);">${fmt(s.totalAmount)}</td>
                    <td style="font-weight:700; color:var(--warning);">${comm} ${storeSettings.currency}</td>
                    <td style="font-weight:700;">${s.time || '-'}</td>
                    <td>${statusHtml}</td>
                `;
                salesBody.appendChild(tr);
            });
        }
    }

    // =================> 5) العمولات (نظام الكابتن) <=================
    const commFilterSel = document.getElementById('commission-filter-select');
    const commEmpFilter = document.getElementById('commission-emp-filter');
    const commDaySel = document.getElementById('commission-day-select');
    const commDayContainer = document.getElementById('commission-day-container');
    const commTableBody = document.getElementById('commission-table-body');
    const commAllowancesList = document.getElementById('commission-allowances-list');

    function hmToMins(str) {
        if(str == null || str === '') return null;
        let s = String(str);
        const ar = '٠١٢٣٤٥٦٧٨٩';
        s = s.replace(/[٠-٩]/g, ch => ar.indexOf(ch)).replace(/[۰-۹]/g, ch => '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch));
        const isPM = /م$|مساء|pm/i.test(s);
        const m = s.match(/(\d{1,2}):(\d{1,2})/);
        if(!m) return null;
        let h = Number(m[1]), mm = Number(m[2]);
        if(isPM && h !== 12) h += 12;
        if(!isPM && h === 12) h = 0;
        return h * 60 + mm;
    }

    function parseNormKey(key) {
        const p = String(key).split('-').map(Number);
        if(p.length !== 3 || p.some(n => isNaN(n))) return null;
        return new Date(p[0], p[1] - 1, p[2]);
    }

    function getCommissionsResetDay() {
        return localStorage.getItem('commissionsResetDay') || '';
    }

    function inCommissionPeriod(dateStr) {
        const key = normEmpDate(dateStr);
        if(!key) return false;
        const resetDay = getCommissionsResetDay();
        if(resetDay && key < resetDay) return false;
        if(!commFilterSel) return true;
        const filter = commFilterSel.value;
        const d = parseNormKey(key);
        if(!d) return true;
        const now = new Date();
        if(filter === 'monthly') {
            return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        } else if(filter === 'weekly') {
            const weekAgo = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
            return d >= weekAgo && d <= now;
        } else if(filter === 'daily') {
            if(commDaySel && commDaySel.value && normEmpDate(commDaySel.value) !== key) return false;
            return true;
        }
        return true;
    }

    function saveCommissionSettingsFromPage() {
        const get = id => document.getElementById(id);
        const gv = id => { const el = get(id); return el ? el.value : null; };
        if(gv('commission-default-amount') !== null) storeSettings.defaultProductCommission = parseFloat(gv('commission-default-amount')) || 0;
        if(gv('commission-online-amount') !== null) storeSettings.onlineOrderCommission = parseFloat(gv('commission-online-amount')) || 0;
        const taEl = get('commission-target-active');
        if(taEl) storeSettings.targetBonusActive = taEl.checked;
        if(gv('commission-target-qty') !== null) storeSettings.targetBonusQty = parseInt(gv('commission-target-qty')) || 0;
        if(gv('commission-target-amount') !== null) storeSettings.targetBonusAmount = parseFloat(gv('commission-target-amount')) || 0;
        const ltEl = get('commission-lunch-active');
        if(ltEl) storeSettings.lunchTransportActive = ltEl.checked;
        if(gv('commission-late-penalty') !== null) storeSettings.latePenaltyPerHour = parseFloat(gv('commission-late-penalty')) || 0;
        if(gv('commission-extra-bonus') !== null) storeSettings.extraHourBonus = parseFloat(gv('commission-extra-bonus')) || 0;
        if(gv('commission-grace-minutes') !== null) storeSettings.gracePeriodMins = parseFloat(gv('commission-grace-minutes')) || 0;
        localStorage.setItem('storeSettings', JSON.stringify(storeSettings));
    }

    function renderCommissionSettings() {
        const set = (id, val) => { const el = document.getElementById(id); if(el) el.value = val; };
        set('commission-default-amount', storeSettings.defaultProductCommission);
        set('commission-online-amount', storeSettings.onlineOrderCommission != null ? storeSettings.onlineOrderCommission : 10);
        const ta = document.getElementById('commission-target-active');
        if(ta) ta.checked = storeSettings.targetBonusActive !== false;
        set('commission-target-qty', storeSettings.targetBonusQty != null ? storeSettings.targetBonusQty : 60);
        set('commission-target-amount', storeSettings.targetBonusAmount != null ? storeSettings.targetBonusAmount : 10);
        const lt = document.getElementById('commission-lunch-active');
        if(lt) lt.checked = storeSettings.lunchTransportActive !== false;
        set('commission-late-penalty', storeSettings.latePenaltyPerHour != null ? storeSettings.latePenaltyPerHour : 30);
        set('commission-extra-bonus', storeSettings.extraHourBonus != null ? storeSettings.extraHourBonus : 30);
        set('commission-grace-minutes', storeSettings.gracePeriodMins != null ? storeSettings.gracePeriodMins : 15);
        const q = document.getElementById('commission-target-qty');
        const am = document.getElementById('commission-target-amount');
        const on = ta ? ta.checked : true;
        if(q) { q.disabled = !on; q.style.opacity = on ? '1' : '0.5'; }
        if(am) { am.disabled = !on; am.style.opacity = on ? '1' : '0.5'; }
        renderAllowancesList();
    }

    function renderAllowancesList() {
        if(!commAllowancesList) return;
        const isActive = document.getElementById('commission-lunch-active') ? document.getElementById('commission-lunch-active').checked : true;
        commAllowancesList.style.opacity = isActive ? '1' : '0.5';
        let html = '';
        employeesLog.filter(e => e.active !== false).forEach(emp => {
            const cond = emp.lunchTransportCondition || 'immediate';
            const hours = emp.lunchTransportHours || 10;
            const condDisplay = cond === 'hours' ? 'block' : 'none';
            html += `
                <div style="margin-bottom: 12px; padding-bottom: 10px; border-bottom: 1px dashed var(--border-color);">
                    <div style="display:flex; align-items:center; margin-bottom:5px;">
                        <span style="flex:1; font-weight:bold; color:var(--text-color); font-size:14px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${emp.name}</span>
                        <input type="number" class="custom-input glass-input" style="width:90px; padding:6px 10px;" placeholder="المبلغ" min="0" ${!isActive ? 'disabled' : ''} value="${emp.lunchTransportAllowance != null && emp.lunchTransportAllowance !== '' ? emp.lunchTransportAllowance : ''}" onchange="window.updateEmpAllowanceField(${emp.id}, 'lunchTransportAllowance', this.value)">
                    </div>
                    <div style="display:flex; flex-direction:column; gap:5px; margin-right:12px;">
                        <div class="select-wrapper">
                            <select class="custom-input glass-input" style="font-size:13px; padding:5px 10px;" ${!isActive ? 'disabled' : ''} onchange="window.updateEmpAllowanceField(${emp.id}, 'lunchTransportCondition', this.value); var h=document.getElementById('emp_allow_hours_${emp.id}'); if(h) h.style.display = this.value === 'hours' ? 'block' : 'none';">
                                <option value="immediate" ${cond === 'immediate' ? 'selected' : ''}>إضافة بمجرد الحضور</option>
                                <option value="checkout" ${cond === 'checkout' ? 'selected' : ''}>إضافة بعد الانصراف</option>
                                <option value="hours" ${cond === 'hours' ? 'selected' : ''}>بعد عدد ساعات محدد</option>
                            </select>
                            <i class="fas fa-chevron-down select-icon"></i>
                        </div>
                        <input type="number" id="emp_allow_hours_${emp.id}" class="custom-input glass-input" style="display:${condDisplay}; font-size:13px; padding:5px 10px;" placeholder="عدد الساعات..." min="1" ${!isActive ? 'disabled' : ''} value="${hours}" onchange="window.updateEmpAllowanceField(${emp.id}, 'lunchTransportHours', this.value)">
                    </div>
                </div>`;
        });
        commAllowancesList.innerHTML = html;
    }

    window.updateEmpAllowanceField = function(empId, field, value) {
        const emp = employeesLog.find(e => e.id == empId);
        if(!emp) return;
        if(field === 'lunchTransportCondition') emp[field] = value;
        else emp[field] = parseFloat(value) || 0;
        saveEmployees();
        showToast('تم تحديث البدل بنجاح');
    };

    function getShiftAllowance(a, emp) {
        if(!a || !a.timeIn || a.status === 'absent') return 0;
        if(!emp) return 0;
        const hasOwn = emp.lunchTransportAllowance !== undefined;
        const empVal = hasOwn ? (Number(emp.lunchTransportAllowance) || 0) : 0;
        const settingsVal = Number(storeSettings.lunchTransportAllowance) || 0;
        const empHasOwn = hasOwn || empVal > 0;
        if(storeSettings.lunchTransportActive === false && !empHasOwn) return 0;
        let conditionMet = false;
        let cond = (emp.lunchTransportCondition || '').toLowerCase() || 'immediate';
        if(cond.includes('checkout')) {
            conditionMet = !!a.timeOut && String(a.timeOut).trim() !== '';
        } else if(cond.includes('hour')) {
            let req = Number(emp.lunchTransportHours) || 10;
            let hoursWorked = (a.timeInMs && a.timeOutMs) ? Math.max(0, ((a.timeOutMs - a.timeInMs) - (a.breakTotalMs || 0)) / 3600000) : (a.timeInMs ? Math.max(0, (Date.now() - a.timeInMs - (a.breakTotalMs || 0)) / 3600000) : (Number(a.workHours) || 0));
            conditionMet = hoursWorked >= req;
        } else {
            conditionMet = true;
        }
        if(!conditionMet) return 0;
        if(hasOwn && empVal > 0) return empVal;
        return settingsVal;
    }

    function calcAllowances(emp, attArr) {
        let total = 0;
        const seen = new Set();
        (attArr || []).forEach(a => {
            const amt = getShiftAllowance(a, emp);
            if(amt > 0) {
                const key = a.id || (a.date + '_' + a.timeIn);
                if(!seen.has(key)) { seen.add(key); total += amt; }
            }
        });
        return total;
    }

    function calcHoursForAtt(a, emp) {
        let bonus = 0, penalty = 0, lateMins = 0;
        const grace = Number(storeSettings.gracePeriodMins) || 15;
        const penaltyPerHour = Number(storeSettings.latePenaltyPerHour) || 30;
        const extraBonus = Number(storeSettings.extraHourBonus) || 30;
        let actualHours = 0;
        if(a.timeInMs) {
            actualHours = ((a.timeOutMs
                ? Math.max(0, (a.timeOutMs - a.timeInMs - (a.breakTotalMs || 0)))
                : Math.max(0, (Date.now() - a.timeInMs - (a.breakTotalMs || 0)))) / 3600000);
        } else {
            actualHours = Number(a.workHours) || 0;
        }
        if(emp && emp.shiftStart && emp.shiftEnd) {
            const s = hmToMins(emp.shiftStart), e = hmToMins(emp.shiftEnd);
            if(s != null && e != null) {
                let expected = e - s; if(expected < 0) expected += 1440;
                if(actualHours > expected / 60) bonus = (actualHours - expected / 60) * extraBonus;
            }
        }
        if(emp && emp.shiftStart) {
            const expected = hmToMins(emp.shiftStart);
            if(expected != null) {
                let actual = null;
                if(a.timeInMs) { const d = new Date(a.timeInMs); actual = d.getHours() * 60 + d.getMinutes(); }
                else actual = hmToMins(a.timeIn);
                if(actual != null) {
                    let late = actual - expected;
                    if(late < -720) late += 1440;
                    if(late > 0) {
                        lateMins = late;
                        if(late > grace) penalty = (late - grace) * (penaltyPerHour / 60);
                    }
                }
            }
        }
        return { bonus, penalty, lateMins };
    }

    function calcCommissionsForEmp(salesArr) {
        const targetActive = storeSettings.targetBonusActive !== false;
        const targetQty = Number(storeSettings.targetBonusQty) || 60;
        const targetAmount = Number(storeSettings.targetBonusAmount) || 10;
        let total = 0, bonusCount = 0;
        if(!salesArr || salesArr.length === 0) return { total: 0, bonusCount: 0 };
        const byDay = {};
        salesArr.forEach(s => { const k = normEmpDate(s.date) || 'x'; if(!byDay[k]) byDay[k] = []; byDay[k].push(s); });
        Object.values(byDay).forEach(daySales => {
            let piecesSeen = 0;
            daySales.forEach(s => {
                const qty = Number(s.totalQty) || 0;
                if(qty <= 0) return;
                const pieceComm = calcSaleCommission(s) / qty;
                for(let i = 0; i < qty; i++) {
                    piecesSeen++;
                    let comm = pieceComm;
                    if(targetActive && piecesSeen > targetQty) {
                        comm = Math.max(comm, targetAmount);
                        bonusCount++;
                    }
                    total += comm;
                }
            });
        });
        return { total, bonusCount };
    }

    function renderCommissions() {
        renderCommissionSettings();
        if(!commEmpFilter || !commTableBody) return;
        const prevEmp = commEmpFilter.value;
        commEmpFilter.innerHTML = '<option value="">-- اختر الموظف --</option>';
        employeesLog.filter(e => e.active !== false).forEach(e => {
            const opt = document.createElement('option');
            opt.value = e.id;
            opt.textContent = e.name;
            commEmpFilter.appendChild(opt);
        });
        if(prevEmp) {
            const ok = Array.from(commEmpFilter.options).some(o => o.value === String(prevEmp));
            if(ok) commEmpFilter.value = prevEmp;
        }

        if(commDaySel) {
            const dayMap2 = new Map();
            [attendanceLog, salesLog, returnsLog].forEach(list => list.forEach(r => {
                const key = normEmpDate(r.date);
                if(key && !dayMap2.has(key)) dayMap2.set(key, r.date);
            }));
            const prevDay = commDaySel.value;
            commDaySel.innerHTML = '';
            [...dayMap2.keys()].sort((a, b) => (a < b ? 1 : a > b ? -1 : 0)).forEach(k => {
                const opt = document.createElement('option');
                opt.value = dayMap2.get(k);
                opt.textContent = dayMap2.get(k);
                commDaySel.appendChild(opt);
            });
            if(prevDay) {
                const m = Array.from(commDaySel.options).find(o => o.value === prevDay);
                if(m) commDaySel.value = m.value;
            }
        }
        if(commDayContainer) commDayContainer.style.display = commFilterSel && commFilterSel.value === 'daily' ? 'block' : 'none';

        const undoBtn = document.getElementById('btn-undo-commissions-reset');
        if(undoBtn) undoBtn.style.display = getCommissionsResetDay() ? 'inline-flex' : 'none';

        const empId = commEmpFilter.value;
        if(!empId) {
            commTableBody.innerHTML = '<tr><td colspan="11" style="text-align:center; padding:30px; color:var(--text-muted);"><i class="fas fa-user" style="font-size:32px; margin-bottom:15px; display:block; opacity:0.3;"></i> اختر الموظف لعرض تفاصيل حسابه</td></tr>';
            return;
        }
        const emp = employeesLog.find(e => e.id == empId);
        if(!emp) { commTableBody.innerHTML = ''; return; }

        const empSalesRaw = salesLog.filter(s => (s.empName === emp.name || s.empId == empId) && inCommissionPeriod(s.date));
        const empAttRaw = attendanceLog.filter(a => a.empId == empId && inCommissionPeriod(a.date));
        const empWithdrawals = loansLog.filter(l => l.empName === emp.name && inCommissionPeriod(l.date));

        const returnsForPeriod = returnsLog.filter(r => r.empName === emp.name && inCommissionPeriod(r.date));
        const returnedInvoices = new Set(returnsForPeriod.map(r => String(r.invoice).trim()));
        const empSales = empSalesRaw.filter(s => !returnedInvoices.has(String(s.id).trim()));

        const totalItems = empSales.length;
        const commData = calcCommissionsForEmp(empSales);
        const salesCommission = commData.total;
        const achievedTarget = commData.bonusCount > 0;

        const onlineOrders = onlineOrdersLog.filter(o => o.empName === emp.name && inCommissionPeriod(o.date) && (['delivered', 'completed', 'مكتمل', 'تم التوصيل', 'مكتملة'].indexOf(String(o.status).toLowerCase()) > -1));
        const onlineCommissionTotal = onlineOrders.length * (Number(storeSettings.onlineOrderCommission) || 10);

        const allowancesTotal = calcAllowances(emp, empAttRaw);

        let hoursBonus = 0, hoursPenalty = 0, totalLateMinsForUI = 0;
        empAttRaw.forEach(a => {
            const r = calcHoursForAtt(a, emp);
            hoursBonus += r.bonus; hoursPenalty += r.penalty; totalLateMinsForUI += r.lateMins;
        });

        const totalWithdrawals = empWithdrawals.reduce((s, w) => s + (Number(w.amount) || 0), 0);
        const netHoursCommission = hoursBonus - hoursPenalty;
        const totalDue = salesCommission + onlineCommissionTotal + allowancesTotal + netHoursCommission - totalWithdrawals;

        const lateHoursUI = Math.floor(totalLateMinsForUI / 60);
        const lateMinsUI = Math.floor(totalLateMinsForUI % 60);
        const delayText = totalLateMinsForUI > 0 ? `${lateHoursUI}س و${lateMinsUI}د` : '-';
        const cur = storeSettings.currency;

        commTableBody.innerHTML = `
            <tr>
                <td><strong>${emp.name}</strong>${achievedTarget ? ' <span title="حقق هدف المبيعات اليومي!" style="display:inline-flex; align-items:center; justify-content:center; width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#7c3aed); color:#fff; font-size:18px; margin-right:8px; box-shadow:0 4px 14px rgba(124,58,237,.45); vertical-align:middle; animation:recPulse 1.6s ease-in-out infinite;"><i class="fas fa-bullseye"></i></span>' : ''}</td>
                <td style="font-weight:700;">${totalItems}</td>
                <td style="font-weight:700; color:var(--primary);">${salesCommission.toFixed(2)} ${cur}</td>
                <td style="font-weight:700; color:var(--success);">+${onlineCommissionTotal.toFixed(2)} ${cur}</td>
                <td style="font-weight:700; color:var(--success);">+${allowancesTotal.toFixed(2)} ${cur}</td>
                <td style="font-weight:700; color:var(--success);">+${hoursBonus.toFixed(2)} ${cur}</td>
                <td style="font-weight:700;">${delayText}</td>
                <td style="font-weight:700; color:var(--danger);">-${hoursPenalty.toFixed(2)} ${cur}</td>
                <td style="font-weight:700; color:var(--danger);">-${totalWithdrawals.toFixed(2)} ${cur}</td>
                <td style="font-weight:700;">${netHoursCommission.toFixed(2)} ${cur}</td>
                <td style="font-weight:800; color:var(--text-color);">${totalDue.toFixed(2)} ${cur}</td>
            </tr>`;
    }

    if(commFilterSel) commFilterSel.onchange = () => { saveCommissionSettingsFromPage(); renderCommissions(); };
    if(commEmpFilter) commEmpFilter.onchange = renderCommissions;
    if(commDaySel) commDaySel.onchange = renderCommissions;

    const btnClearCommissions = document.getElementById('btn-clear-commissions');
    if(btnClearCommissions) {
        btnClearCommissions.addEventListener('click', () => {
            showConfirm('تصفير سجل العمولات بالكامل', 'سيتم إخفاء كل العمولات القديمة وتبدأ العمولات من اليوم فصاعداً. هل أنت متأكد؟', () => {
                const now = new Date();
                localStorage.setItem('commissionsResetDay', normEmpDate(now.toLocaleDateString('ar-EG')));
                showToast('تم تصفير سجل العمولات', 'success');
                renderCommissions();
            });
        });
    }
    const btnUndoReset = document.getElementById('btn-undo-commissions-reset');
    if(btnUndoReset) {
        btnUndoReset.addEventListener('click', () => {
            localStorage.removeItem('commissionsResetDay');
            showToast('تم التراجع عن التصفير', 'success');
            renderCommissions();
        });
    }

    const commissionSettingsIds = ['commission-default-amount', 'commission-online-amount', 'commission-target-qty', 'commission-target-amount', 'commission-late-penalty', 'commission-extra-bonus', 'commission-grace-minutes'];
    commissionSettingsIds.forEach(id => {
        const el = document.getElementById(id);
        if(el) el.addEventListener('change', () => { saveCommissionSettingsFromPage(); renderCommissions(); });
    });
    const commissionTargetActiveEl = document.getElementById('commission-target-active');
    if(commissionTargetActiveEl) {
        commissionTargetActiveEl.addEventListener('change', () => {
            const q = document.getElementById('commission-target-qty');
            const a = document.getElementById('commission-target-amount');
            const on = commissionTargetActiveEl.checked;
            if(q) { q.disabled = !on; q.style.opacity = on ? '1' : '0.5'; }
            if(a) { a.disabled = !on; a.style.opacity = on ? '1' : '0.5'; }
            saveCommissionSettingsFromPage();
            renderCommissions();
        });
    }
    const commissionLunchActiveEl = document.getElementById('commission-lunch-active');
    if(commissionLunchActiveEl) {
        commissionLunchActiveEl.addEventListener('change', () => {
            saveCommissionSettingsFromPage();
            renderAllowancesList();
        });
    }

    // =================> 6) السجلات (اليوميات) <=================
    const recordShiftSel = document.getElementById('record-shift-select');
    const recordSearchDesc = document.getElementById('record-search-desc');
    const recordSalesBody = document.getElementById('record-sales-body');
    const recordAttendanceBody = document.getElementById('record-attendance-body');

    function getClearedDays() {
        try { return JSON.parse(localStorage.getItem('clearedDays')) || []; } catch(e) { return []; }
    }
    function saveClearedDays(arr) { localStorage.setItem('clearedDays', JSON.stringify(arr)); }

    function recordsEmptyRow(msg, cols) {
        return `<tr><td colspan="${cols}" style="text-align:center; padding:30px; color:var(--text-muted);">${msg}</td></tr>`;
    }

    function weekdayName(key) {
        const d = parseNormKey(key);
        if(!d) return '';
        try { return d.toLocaleDateString('ar-EG', { weekday: 'long' }); } catch(e) { return ''; }
    }

    function setRecordsSummary(total, pieces, returnsCount) {
        const el = id => document.getElementById(id);
        if(el('record-summary-total')) el('record-summary-total').textContent = fmt(total);
        if(el('record-summary-pieces')) el('record-summary-pieces').textContent = pieces;
        if(el('record-summary-returns')) el('record-summary-returns').textContent = returnsCount;
    }

    function renderRecords() {
        if(!recordShiftSel || !recordSalesBody || !recordAttendanceBody) return;

        const dayMap = new Map();
        [salesLog, attendanceLog, loansLog, returnsLog, notesLog].forEach(list => list.forEach(r => {
            const key = normEmpDate(r.date);
            if(key && !dayMap.has(key)) dayMap.set(key, r.date);
        }));
        const cleared = getClearedDays();
        const prevVal = recordShiftSel.value;
        recordShiftSel.innerHTML = '<option value="">-- اختر يوماً (سجل) --</option>';
        [...dayMap.keys()].sort((a, b) => (a < b ? 1 : a > b ? -1 : 0)).forEach(k => {
            const opt = document.createElement('option');
            opt.value = dayMap.get(k);
            const wd = weekdayName(k);
            opt.textContent = (cleared.includes(k) ? '✅ خالص - ' : '') + (wd ? wd + ' - ' : '') + dayMap.get(k);
            recordShiftSel.appendChild(opt);
        });
        if(prevVal) {
            const ok = Array.from(recordShiftSel.options).some(o => o.value === prevVal);
            if(ok) recordShiftSel.value = prevVal;
        }

        const day = recordShiftSel.value;
        const dayKey = normEmpDate(day);
        const isCleared = !!dayKey && cleared.includes(dayKey);
        const rowStyle = isCleared ? 'opacity:0.45; filter:grayscale(100%);' : '';

        const toggleBtn = document.getElementById('record-toggle-cleared');
        const delDayBtn = document.getElementById('record-delete-day');
        const filterBox = document.getElementById('record-filter-box');
        const showTools = !!dayKey;
        if(toggleBtn) {
            toggleBtn.style.display = showTools ? 'inline-flex' : 'none';
            toggleBtn.innerHTML = isCleared
                ? '<i class="fas fa-times-circle"></i> <span>إلغاء الخالص</span>'
                : '<i class="fas fa-check-circle"></i> <span>تعيين كـ خالص</span>';
            toggleBtn.style.color = isCleared ? '#ef4444' : '#10b981';
            toggleBtn.style.borderColor = isCleared ? '#ef4444' : '#10b981';
        }
        if(delDayBtn) delDayBtn.style.display = showTools ? 'inline-flex' : 'none';
        const printDayBtn = document.getElementById('record-print-day');
        if(printDayBtn) printDayBtn.style.display = showTools ? 'inline-flex' : 'none';
        if(filterBox) filterBox.style.display = showTools ? 'flex' : 'none';

        if(!dayKey) {
            recordSalesBody.innerHTML = recordsEmptyRow('اختر يوماً لعرض سجلاته', 9);
            recordAttendanceBody.innerHTML = '';
            setRecordsSummary(0, 0, 0);
            return;
        }

        const daySalesRaw = salesLog.filter(s => normEmpDate(s.date) === dayKey);
        const dayReturns = returnsLog.filter(r => normEmpDate(r.date) === dayKey);
        const returnedInvoices = new Set(dayReturns.map(r => String(r.invoice).trim()));
        const activeSales = daySalesRaw.filter(s => !returnedInvoices.has(String(s.id).trim()));

        const totalRevenue = activeSales.reduce((sum, x) => sum + (x.totalAmount || 0), 0);
        const totalPieces = activeSales.reduce((sum, x) => sum + (x.totalQty || 0), 0);
        setRecordsSummary(totalRevenue, totalPieces, dayReturns.length);

        const search = (recordSearchDesc ? recordSearchDesc.value.trim().toLowerCase() : '');
        const statusFilter = (document.querySelector('input[name="record-status-filter"]:checked') || {}).value || 'all';

        let salesRows = daySalesRaw.filter(s => {
            const isRet = returnedInvoices.has(String(s.id).trim());
            const st = isRet ? 'returned' : 'sold';
            if(statusFilter !== 'all' && st !== statusFilter) return false;
            if(search) {
                const hay = `${s.id} ${s.empName || ''} ${s.description || ''}`.toLowerCase();
                if(!hay.includes(search)) return false;
            }
            return true;
        });
        salesRows.sort((a, b) => ((a.time || '') > (b.time || '') ? 1 : -1));

        if(salesRows.length === 0) {
            recordSalesBody.innerHTML = recordsEmptyRow('لا توجد مبيعات في هذا اليوم', 9);
        } else {
            recordSalesBody.innerHTML = '';
            salesRows.forEach(s => {
                const isRet = returnedInvoices.has(String(s.id).trim());
                const avg = (s.totalQty || 0) > 0 ? (s.totalAmount / s.totalQty) : s.totalAmount;
                const statusHtml = isRet
                    ? `<span class="status-badge" style="background-color: var(--danger-bg); color: var(--danger);">مرتجع</span>`
                    : `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">تم البيع</span>`;
                const tr = document.createElement('tr');
                tr.setAttribute('style', rowStyle);
                tr.innerHTML = `
                    <td style="font-weight:700;">#${s.id}</td>
                    <td><strong>${s.empName || '-'}</strong></td>
                    <td style="text-align:right;">${s.description || '-'}</td>
                    <td style="font-weight:700;">${s.totalQty || 0}</td>
                    <td style="font-weight:700;">${fmt(avg)}</td>
                    <td style="font-weight:700; color:var(--primary);">${fmt(s.totalAmount)}</td>
                    <td>${s.time || ''} - ${s.date || ''}</td>
                    <td>${statusHtml}</td>
                    <td>
                        <div style="display:flex; justify-content:center; gap:8px;">
                            <button class="btn-icon-only" title="طباعة الفاتورة A4" onclick="window.printInvoice(${s.id})" style="color:var(--primary); background:transparent; border:none; cursor:pointer; font-size:15px;"><i class="fas fa-file-lines"></i></button>
                            <button class="btn-icon-only" title="طباعة حرارية 58مم" onclick="window.printThermalSale(${s.id})" style="color:var(--primary); background:transparent; border:none; cursor:pointer; font-size:15px;"><i class="fas fa-print"></i></button>
                            <button class="btn-icon-only" title="حذف العملية" onclick="window.deleteRecordSale(${s.id})" style="color:var(--danger); background:transparent; border:none; cursor:pointer; font-size:15px;"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </td>`;
                recordSalesBody.appendChild(tr);
            });

            const sumQty = salesRows.reduce((s, x) => s + (x.totalQty || 0), 0);
            const sumAmt = salesRows.reduce((s, x) => s + (x.totalAmount || 0), 0);
            const avgOverall = sumQty > 0 ? (sumAmt / sumQty) : 0;
            const footTr = document.createElement('tr');
            footTr.innerHTML = `
                <td colspan="3" style="text-align:left; font-weight:800; background:var(--surface-2);">إجمالي اليوم</td>
                <td style="font-weight:800; background:var(--surface-2);">${sumQty}</td>
                <td style="font-weight:700; background:var(--surface-2);">${fmt(avgOverall)}</td>
                <td style="font-weight:800; color:var(--primary); background:var(--surface-2);">${fmt(sumAmt)}</td>
                <td colspan="2" style="background:var(--surface-2);"></td>
                <td style="background:var(--surface-2);"></td>`;
            recordSalesBody.appendChild(footTr);
        }

        const dayAtt = attendanceLog.filter(a => normEmpDate(a.date) === dayKey);
        if(dayAtt.length === 0) {
            recordAttendanceBody.innerHTML = recordsEmptyRow('لا يوجد حضور في هذا اليوم', 7);
        } else {
            recordAttendanceBody.innerHTML = '';
            dayAtt.forEach(a => {
                const hours = (a.timeInMs && a.timeOutMs) ? (Math.max(0, (a.timeOutMs - a.timeInMs - (a.breakTotalMs || 0)) / 3600000)) : 0;
                const statusHtml = a.status === 'active'
                    ? `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">منتظم</span>`
                    : (a.status === 'absent'
                        ? `<span class="status-badge" style="background-color: var(--danger-bg); color: var(--danger);">غائب</span>`
                        : `<span class="status-badge" style="background-color: var(--warning); color: white;">منصرف</span>`);
                const tr = document.createElement('tr');
                tr.setAttribute('style', rowStyle);
                tr.innerHTML = `
                    <td><strong>${a.empName || '-'}</strong></td>
                    <td>${a.date || ''}</td>
                    <td style="font-weight:700;">${a.timeIn || '-'}</td>
                    <td style="font-weight:700;">${a.timeOut || '-'}</td>
                    <td style="font-weight:700;">${hours ? hours.toFixed(1) + ' س' : '-'}</td>
                    <td>${statusHtml}</td>
                    <td>
                        <button class="btn-icon-only" title="حذف الحضور" onclick="window.deleteRecordAttendance(${a.id})" style="color:var(--danger); background:transparent; border:none; cursor:pointer; font-size:15px;"><i class="fas fa-trash-alt"></i></button>
                    </td>`;
                recordAttendanceBody.appendChild(tr);
            });
        }
    }

    window.deleteRecordSale = function(id) {
        showConfirm('حذف العملية', 'هل أنت متأكد من حذف عملية البيع هذه؟', () => {
            salesLog = salesLog.filter(s => s.id !== id);
            saveSales();
            renderRecords();
            showToast('تم حذف العملية', 'success');
        });
    };

    window.deleteRecordAttendance = function(id) {
        showConfirm('حذف الحضور', 'هل أنت متأكد من حذف سجل الحضور هذا؟', () => {
            attendanceLog = attendanceLog.filter(a => a.id !== id);
            saveAttendance();
            renderRecords();
            showToast('تم حذف الحضور', 'success');
        });
    };

    if(recordShiftSel) recordShiftSel.onchange = renderRecords;
    if(recordSearchDesc) recordSearchDesc.addEventListener('keyup', renderRecords);

    const recordToggleClearedBtn = document.getElementById('record-toggle-cleared');
    if(recordToggleClearedBtn) {
        recordToggleClearedBtn.addEventListener('click', () => {
            const key = normEmpDate(recordShiftSel.value);
            if(!key) return;
            let cleared = getClearedDays();
            if(cleared.includes(key)) cleared = cleared.filter(x => x !== key);
            else cleared.push(key);
            saveClearedDays(cleared);
            showToast(cleared.includes(key) ? 'تم تعيين اليوم كـ خالص' : 'تم إلغاء الخالص', 'success');
            renderRecords();
        });
    }
    const recordDeleteDayBtn = document.getElementById('record-delete-day');
    if(recordDeleteDayBtn) {
        recordDeleteDayBtn.addEventListener('click', () => {
            const key = normEmpDate(recordShiftSel.value);
            if(!key) return;
            showConfirm('مسح اليوم بالكامل', 'سيتم حذف مبيعات وحضور وسحوبات ومرتجعات وملاحظات هذا اليوم نهائياً. هل أنت متأكد؟', () => {
                salesLog = salesLog.filter(s => normEmpDate(s.date) !== key);
                attendanceLog = attendanceLog.filter(a => normEmpDate(a.date) !== key);
                loansLog = loansLog.filter(l => normEmpDate(l.date) !== key);
                returnsLog = returnsLog.filter(r => normEmpDate(r.date) !== key);
                notesLog = notesLog.filter(n => normEmpDate(n.date) !== key);
                expensesLog = expensesLog.filter(e => normEmpDate(e.date) !== key);
                damageLog = damageLog.filter(d => normEmpDate(d.date) !== key);
                saveSales(); saveAttendance(); saveLoans(); saveReturns(); saveNotes(); saveExpenses(); saveDamage();
                showToast('تم مسح سجلات اليوم', 'success');
                renderRecords();
            });
        });
    }
    document.querySelectorAll('input[name="record-status-filter"]').forEach(r => {
        r.addEventListener('change', () => {
            document.querySelectorAll('.rec-pill').forEach(p => p.classList.remove('active'));
            if(r.checked && r.closest) r.closest('.rec-pill').classList.add('active');
            renderRecords();
        });
    });

    function printDayReport() {
        const day = recordShiftSel.value;
        const key = normEmpDate(day);
        if(!key || !recordShiftSel) return;
        const daySales = salesLog.filter(s => normEmpDate(s.date) === key);
        const dayReturns = returnsLog.filter(r => normEmpDate(r.date) === key);
        const retInvoices = new Set(dayReturns.map(r => String(r.invoice).trim()));
        const active = daySales.filter(s => !retInvoices.has(String(s.id).trim()));
        const dayAtt = attendanceLog.filter(a => normEmpDate(a.date) === key);
        const totalRev = active.reduce((s, x) => s + (x.totalAmount || 0), 0);
        const totalQty = active.reduce((s, x) => s + (x.totalQty || 0), 0);

        const salesHtml = active.length === 0
            ? '<tr><td colspan="8" style="text-align:center;color:#94a3b8;padding:12px;">لا توجد مبيعات</td></tr>'
            : [...active].map(s => {
                const isRet = retInvoices.has(String(s.id).trim());
                const avg = (s.totalQty || 0) > 0 ? (s.totalAmount / s.totalQty) : s.totalAmount;
                const st = isRet ? '<span style="color:#dc2626;font-weight:700;">مرتجع</span>' : '<span style="color:#16a34a;font-weight:700;">تم البيع</span>';
                return `<tr><td>#${s.id}</td><td>${s.empName || '-'}</td><td style="text-align:right;">${s.description || '-'}</td><td>${s.totalQty || 0}</td><td>${fmt(avg)}</td><td style="font-weight:700;">${fmt(s.totalAmount)}</td><td>${s.time || ''}</td><td>${st}</td></tr>`;
            }).join('');

        const attHtml = dayAtt.length === 0
            ? '<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:12px;">لا يوجد حضور</td></tr>'
            : dayAtt.map(a => {
                const hours = (a.timeInMs && a.timeOutMs) ? (Math.max(0, (a.timeOutMs - a.timeInMs - (a.breakTotalMs || 0)) / 3600000)) : 0;
                const st = a.status === 'active' ? '<span style="color:#16a34a;font-weight:700;">منتظم</span>' : (a.status === 'absent' ? '<span style="color:#dc2626;font-weight:700;">غائب</span>' : '<span style="color:#d97706;font-weight:700;">منصرف</span>');
                return `<tr><td>${a.empName || '-'}</td><td>${a.date || ''}</td><td>${a.timeIn || '-'}</td><td>${a.timeOut || '-'}</td><td>${hours ? hours.toFixed(1) + ' س' : '-'}</td><td>${st}</td></tr>`;
            }).join('');

        const storeName = (storeSettings.storeName || 'DataGris Store').trim();
        const initial = storeName.charAt(0).toUpperCase() || 'D';
        const wd = weekdayName(key);
        const dateLabel = day || '';

        const win = window.open('', '_blank', 'width=720,height=800');
        if(!win) { showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'error'); return; }

        win.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>تقرير يومي</title>
                <style>
                    * { box-sizing: border-box; margin: 0; padding: 0; }
                    body { font-family: 'Segoe UI', 'Cairo', Tahoma, sans-serif; background: #eef1f6; padding: 24px; color: #1e293b; }
                    .report { max-width: 720px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 12px 32px rgba(15,36,64,0.18); }
                    .header { background: linear-gradient(135deg,#0f2440,#1e3a5f); color:#fff; padding: 24px 20px; text-align:center; position:relative; }
                    .header::after { content:''; position:absolute; bottom:0; right:0; left:0; height:4px; background: linear-gradient(90deg,#e8b460,#f7c977,#e8b460); }
                    .logo { width: 58px; height: 58px; border-radius:50%; background: linear-gradient(135deg,#e8b460,#f7c977); color:#0f2440; font-weight:900; font-size:28px; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; box-shadow:0 6px 14px rgba(0,0,0,0.25); }
                    .store-name { font-size: 21px; font-weight:800; }
                    .store-tag { font-size: 13px; opacity:0.85; margin-top:4px; }
                    .summary { display:flex; justify-content:space-around; gap:10px; margin:16px 20px 6px; padding:12px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; }
                    .summary div { text-align:center; }
                    .summary .v { font-size:19px; font-weight:800; color:#0f2440; }
                    .summary .k { font-size:12px; color:#64748b; margin-top:2px; }
                    h4.sec { margin:18px 20px 8px; color:#0f2440; font-size:15px; font-weight:800; }
                    table.t { width:calc(100% - 40px); margin:0 20px 8px; border-collapse:collapse; font-size:13px; }
                    .t th { background:#f8fafc; color:#0f2440; padding:8px 6px; border-bottom:2px solid #e8b460; font-size:12px; }
                    .t td { padding:7px 6px; border-bottom:1px solid #f1f5f9; }
                    .total-line { text-align:center; margin:10px 20px; padding:12px; background:#fff7ed; border:1px dashed #e8b460; border-radius:10px; font-size:15px; }
                    .total-line b { color:#b45309; font-size:20px; }
                    .footer { text-align:center; padding:14px 20px 20px; font-size:12px; color:#94a3b8; }
                    .footer .divider { border-top:1px dashed #e2e8f0; margin:10px 0; }
                    @media print { body { background:#fff; padding:0; } .report { box-shadow:none; border-radius:0; max-width:100%; } }
                </style>
            </head>
            <body>
                <div class="report">
                    <div class="header">
                        <div class="logo">${initial}</div>
                        <div class="store-name">${storeName}</div>
                        <div class="store-tag">تقرير يومي ${wd ? wd + ' - ' : ''}${dateLabel}</div>
                    </div>
                    <div class="summary">
                        <div><div class="v">${fmt(totalRev)}</div><div class="k">إجمالي المبيعات</div></div>
                        <div><div class="v">${totalQty}</div><div class="k">قطع ناجحة</div></div>
                        <div><div class="v">${dayReturns.length}</div><div class="k">مرتجعات</div></div>
                        <div><div class="v">${dayAtt.length}</div><div class="k">موظفين حاضرين</div></div>
                    </div>
                    <h4 class="sec">المبيعات (${active.length})</h4>
                    <table class="t">
                        <thead><tr><th>رقم</th><th>الموظف</th><th>الوصف</th><th>قطع</th><th>سعر القطعة</th><th>الإجمالي</th><th>الوقت</th><th>الحالة</th></tr></thead>
                        <tbody>${salesHtml}</tbody>
                    </table>
                    <div class="total-line"><b>${fmt(totalRev)}</b> إجمالي مبيعات اليوم</div>
                    <h4 class="sec">الحضور والانصراف (${dayAtt.length})</h4>
                    <table class="t">
                        <thead><tr><th>الموظف</th><th>التاريخ</th><th>حضور</th><th>انصراف</th><th>ساعات العمل</th><th>الحالة</th></tr></thead>
                        <tbody>${attHtml}</tbody>
                    </table>
                    <div class="footer">
                        <div class="divider"></div>
                        <div>${storeName} • ${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</div>
                    </div>
                </div>
                <script>window.onload = function(){ window.focus(); window.print(); }<\/script>
            </body>
            </html>`);
        win.document.close();
    }

    const recordPrintDayBtn = document.getElementById('record-print-day');
    if(recordPrintDayBtn) recordPrintDayBtn.addEventListener('click', printDayReport);

    // =================> 7) المرتبات <=================
    const salariesTbody = document.getElementById('salaries-tbody');
    const btnAddSalary = document.getElementById('btn-add-salary');
    const salaryModal = document.getElementById('salary-modal');
    const btnSaveSalary = document.getElementById('btn-save-salary');
    let editingSalaryId = null;

    function renderSalaries() {
        if(salariesTbody) {
            if(salariesLog.length === 0) {
                salariesTbody.innerHTML = `
                    <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">
                        <i class="fas fa-file-invoice-dollar" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                        لا توجد مرتبات مسجلة
                    </td></tr>`;
            } else {
                salariesTbody.innerHTML = '';
                [...salariesLog].reverse().forEach(s => {
                    const tr = document.createElement('tr');
                    const statusHtml = s.paid
                        ? `<span class="status-badge" style="background-color: var(--success-bg); color: var(--success);">مدفوع</span>`
                        : `<span class="status-badge" style="background-color: var(--warning); color: white;">لم يُدفع</span>`;
                    tr.innerHTML = `
                        <td><strong>${s.empName}</strong></td>
                        <td style="color:var(--text-muted);">${s.month || '-'}</td>
                        <td>${fmt(s.base || 0)}</td>
                        <td style="color: var(--success); font-weight:700;">+ ${fmt(s.additions || 0)}</td>
                        <td style="color: var(--danger); font-weight:700;">- ${fmt(s.deductions || 0)}</td>
                        <td style="font-weight:800; color:var(--primary);">${fmt(s.net || 0)}</td>
                        <td>${statusHtml}</td>
                        <td class="admin-table-cell">
                            <div style="display:flex; justify-content:center; gap:10px;">
                                <button class="btn-icon-only" title="تعديل" onclick="window.editSalary(${s.id})" style="color: var(--gold-deep); background:transparent; border:none; cursor:pointer; font-size:16px;"><i class="fas fa-edit"></i></button>
                                <button class="btn-icon-only" title="حذف" onclick="window.deleteSalary(${s.id})" style="color: var(--danger); background:transparent; border:none; cursor:pointer; font-size:16px;"><i class="fas fa-trash-alt"></i></button>
                            </div>
                        </td>`;
                    salariesTbody.appendChild(tr);
                });
            }
        }
        renderSalaryCalc();
    }

    function inSalaryPeriod(dateStr) {
        const key = normEmpDate(dateStr);
        if(!key) return false;
        const filter = salariesFilter ? salariesFilter.value : 'monthly';
        const d = parseNormKey(key);
        if(!d) return true;
        const now = new Date();
        if(filter === 'monthly') {
            return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        } else if(filter === 'weekly') {
            const weekAgo = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
            return d >= weekAgo && d <= now;
        }
        return true;
    }

    function calcBaseSalary(emp, attArr) {
        const base = Number(emp.baseSalary) || 0;
        if(!base) return 0;
        const type = emp.salaryType || 'monthly';
        const attended = (attArr || []).filter(a => a.timeInMs && a.status !== 'absent').length;
        if(type === 'hourly') {
            let hrs = 0;
            (attArr || []).forEach(a => {
                if(a.timeInMs) hrs += ((a.timeOutMs ? Math.max(0, (a.timeOutMs - a.timeInMs - (a.breakTotalMs || 0))) : Math.max(0, (Date.now() - a.timeInMs - (a.breakTotalMs || 0)))) / 3600000);
                else hrs += (Number(a.workHours) || 0);
            });
            return hrs * base;
        } else if(type === 'weekly') {
            return attended * (base / 7);
        }
        return attended * (base / 30);
    }

    function renderSalaryCalc() {
        const empTbody = document.getElementById('salaries-emp-tbody');
        if(!empTbody) return;
        const sumEmp = document.getElementById('salaries-summary-emp');
        const sumTotal = document.getElementById('salaries-summary-total');
        const sumLoans = document.getElementById('salaries-summary-loans');
        const activeEmps = employeesLog.filter(e => e.active !== false);
        const cur = storeSettings.currency;
        if(activeEmps.length === 0) {
            empTbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:30px; color:var(--text-muted);">
                <i class="fas fa-user-slash" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                لا يوجد موظفون نشطون
            </td></tr>`;
            if(sumEmp) sumEmp.textContent = '0';
            if(sumTotal) sumTotal.textContent = fmt(0);
            if(sumLoans) sumLoans.textContent = fmt(0);
            return;
        }
        let rows = '';
        let grandDue = 0, grandLoans = 0, emptyForPeriod = true;
        activeEmps.forEach(emp => {
            const empSalesRaw = salesLog.filter(s => (s.empName === emp.name || s.empId == emp.id) && inSalaryPeriod(s.date));
            const empAttRaw = attendanceLog.filter(a => a.empId == emp.id && inSalaryPeriod(a.date));
            const empWithdrawals = loansLog.filter(l => (l.empName === emp.name || l.empId == emp.id) && inSalaryPeriod(l.date));
            const returnsForPeriod = returnsLog.filter(r => r.empName === emp.name && inSalaryPeriod(r.date));
            const returnedInvoices = new Set(returnsForPeriod.map(r => String(r.invoice).trim()));
            const empSales = empSalesRaw.filter(s => !returnedInvoices.has(String(s.id).trim()));

            const baseSalary = calcBaseSalary(emp, empAttRaw);
            const commData = calcCommissionsForEmp(empSales);
            const salesCommission = commData.total;
            const onlineCommissionTotal = onlineOrdersLog.filter(o => o.empName === emp.name && inSalaryPeriod(o.date) && (['delivered', 'completed', 'مكتمل', 'تم التوصيل', 'مكتملة'].indexOf(String(o.status).toLowerCase()) > -1)).length * (Number(storeSettings.onlineOrderCommission) || 10);
            const allowancesTotal = calcAllowances(emp, empAttRaw);
            let hoursBonus = 0, hoursPenalty = 0, totalLateMinsForUI = 0;
            empAttRaw.forEach(a => {
                const r = calcHoursForAtt(a, emp);
                hoursBonus += r.bonus; hoursPenalty += r.penalty; totalLateMinsForUI += r.lateMins;
            });
            const totalWithdrawals = empWithdrawals.reduce((s, w) => s + (Number(w.amount) || 0), 0);
            const netHoursCommission = hoursBonus - hoursPenalty;
            const totalDue = baseSalary + salesCommission + onlineCommissionTotal + allowancesTotal + netHoursCommission - totalWithdrawals;

            if(empSales.length > 0 || empAttRaw.length > 0 || empWithdrawals.length > 0) emptyForPeriod = false;

            const lateHoursUI = Math.floor(totalLateMinsForUI / 60);
            const lateMinsUI = Math.floor(totalLateMinsForUI % 60);
            const delayText = totalLateMinsForUI > 0 ? `${lateHoursUI}س و${lateMinsUI}د` : '-';

            rows += `
                <tr>
                    <td><strong>${emp.name}</strong></td>
                    <td style="font-weight:700;">${fmt(baseSalary)}</td>
                    <td style="font-weight:700; color:var(--primary);">${salesCommission.toFixed(2)} ${cur}</td>
                    <td style="font-weight:700; color:var(--success);">+${onlineCommissionTotal.toFixed(2)} ${cur}</td>
                    <td style="font-weight:700; color:var(--success);">+${allowancesTotal.toFixed(2)} ${cur}</td>
                    <td style="font-weight:700; color:var(--success);">+${hoursBonus.toFixed(2)} ${cur}</td>
                    <td style="font-weight:700;">${delayText}</td>
                    <td style="font-weight:700; color:var(--danger);">-${hoursPenalty.toFixed(2)} ${cur}</td>
                    <td style="font-weight:700; color:var(--danger);">-${totalWithdrawals.toFixed(2)} ${cur}</td>
                    <td style="font-weight:800; color:var(--text-color);">${totalDue.toFixed(2)} ${cur}</td>
                </tr>`;
            grandDue += totalDue;
            grandLoans += totalWithdrawals;
        });
        if(emptyForPeriod) {
            empTbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:30px; color:var(--text-muted);">
                <i class="fas fa-file-invoice-dollar" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                لا توجد حسابات للموظفين في هذه الفترة
            </td></tr>`;
        } else {
            empTbody.innerHTML = rows;
        }
        if(sumEmp) sumEmp.textContent = activeEmps.length;
        if(sumTotal) sumTotal.textContent = fmt(grandDue);
        if(sumLoans) sumLoans.textContent = fmt(grandLoans);
    }

    const salariesFilter = document.getElementById('salaries-filter');
    if(salariesFilter) salariesFilter.addEventListener('change', renderSalaries);

    window.editSalary = function(id) {
        const s = salariesLog.find(x => x.id === id);
        if(!s) return;
        editingSalaryId = id;
        document.getElementById('salary-modal-title').textContent = 'تعديل المرتب';
        document.getElementById('salary-emp-select').value = employeesLog.find(e => e.name === s.empName) ? employeesLog.find(e => e.name === s.empName).id : '';
        document.getElementById('salary-month').value = s.month || '';
        document.getElementById('salary-base').value = s.base || 0;
        document.getElementById('salary-additions').value = s.additions || 0;
        document.getElementById('salary-deductions').value = s.deductions || 0;
        document.getElementById('salary-paid').checked = !!s.paid;
        salaryModal.classList.remove('hidden');
    };

    window.deleteSalary = function(id) {
        showConfirm('حذف مرتب', 'هل أنت متأكد من حذف هذا المرتب؟', () => {
            salariesLog = salariesLog.filter(x => x.id !== id);
            saveSalaries();
            renderSalaries();
            showToast('تم حذف المرتب', 'success');
        });
    };

    if(btnAddSalary && salaryModal) {
        btnAddSalary.addEventListener('click', () => {
            editingSalaryId = null;
            document.getElementById('salary-modal-title').textContent = 'تسجيل مرتب';
            populateEmployeeSelects();
            const now = new Date();
            document.getElementById('salary-month').value = now.toISOString().slice(0, 7);
            // تعبئة الراتب الأساسي تلقائياً من الموظف المختار
            const sel = document.getElementById('salary-emp-select');
            sel.onchange = function() {
                const emp = employeesLog.find(e => e.id == sel.value);
                if(emp) document.getElementById('salary-base').value = emp.baseSalary || 0;
            };
            document.getElementById('salary-base').value = '0';
            document.getElementById('salary-additions').value = '0';
            document.getElementById('salary-deductions').value = '0';
            document.getElementById('salary-paid').checked = true;
            salaryModal.classList.remove('hidden');
        });
    }

    if(btnSaveSalary) {
        btnSaveSalary.addEventListener('click', () => {
            const sel = document.getElementById('salary-emp-select');
            if(!sel.value || !sel.selectedOptions[0]) {
                showToast('الرجاء اختيار الموظف', 'error'); return;
            }
            const empName = sel.selectedOptions[0].text;
            const month = document.getElementById('salary-month').value;
            const base = parseFloat(document.getElementById('salary-base').value) || 0;
            const additions = parseFloat(document.getElementById('salary-additions').value) || 0;
            const deductions = parseFloat(document.getElementById('salary-deductions').value) || 0;
            const net = base + additions - deductions;
            const paid = document.getElementById('salary-paid').checked;

            if(editingSalaryId) {
                const s = salariesLog.find(x => x.id === editingSalaryId);
                if(s) {
                    s.empName = empName; s.month = month; s.base = base;
                    s.additions = additions; s.deductions = deductions; s.net = net; s.paid = paid;
                }
                showToast('تم تعديل المرتب بنجاح', 'success');
            } else {
                salariesLog.push({ id: Date.now(), empName, month, base, additions, deductions, net, paid });
                showToast('تم تسجيل المرتب بنجاح', 'success');
                addNotification(`مرتب ${empName} (${month || 'الشهر الحالي'}) تم تسجيله - صافي ${fmt(net)}`, 'salary');
            }
            saveSalaries();
            renderSalaries();
            salaryModal.classList.add('hidden');
        });
    }

    // =================> 8) المرتجعات <=================
    const returnsTbody = document.getElementById('returns-tbody');
    const returnInvoice = document.getElementById('return-invoice');
    const returnProduct = document.getElementById('return-product');
    const returnQty = document.getElementById('return-qty');
    const returnAmount = document.getElementById('return-amount');
    const returnReason = document.getElementById('return-reason');
    const btnAddReturn = document.getElementById('btn-add-return');

    function renderReturns() {
        if(!returnsTbody) return;
        const sTotal = document.getElementById('returns-summary-total');
        const sCount = document.getElementById('returns-summary-count');
        if(returnsLog.length === 0) {
            returnsTbody.innerHTML = `
                <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-undo" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    لا توجد مرتجعات مسجلة
                </td></tr>`;
            if(sTotal) sTotal.textContent = fmt(0);
            if(sCount) sCount.textContent = '0';
            return;
        }
        returnsTbody.innerHTML = '';
        let totalAmount = 0;
        [...returnsLog].reverse().forEach(r => {
            const relatedSale = salesLog.find(s => String(s.id) === String(r.invoice));
            const emp = r.empName || (relatedSale ? relatedSale.empName : '') || '-';
            const saleDate = relatedSale ? (relatedSale.date ? relatedSale.date + (relatedSale.time ? ' ' + relatedSale.time : '') : '-') : '-';
            totalAmount += (Number(r.amount) || 0);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>#${r.invoice || '-'}</strong></td>
                <td><strong>${emp}</strong></td>
                <td style="text-align:right;">${r.product || '-'}</td>
                <td style="font-weight:700;">${r.qty || '-'}</td>
                <td style="font-weight:700; color:var(--danger);">${fmt(r.amount)}</td>
                <td style="color:var(--text-muted);">${saleDate}</td>
                <td>${r.date} ${r.time}</td>
                <td class="admin-table-cell">
                    <button class="btn-icon-only" title="حذف" onclick="window.deleteReturn(${r.id})" style="color: var(--danger); background:transparent; border:none; cursor:pointer; font-size:16px;"><i class="fas fa-trash-alt"></i></button>
                </td>
            `;
            returnsTbody.appendChild(tr);
        });
        if(sTotal) sTotal.textContent = fmt(totalAmount);
        if(sCount) sCount.textContent = returnsLog.length;
    }

    window.deleteReturn = function(id) {
        showConfirm('حذف مرتجع', 'هل أنت متأكد من حذف هذا المرتجع؟', () => {
            returnsLog = returnsLog.filter(x => x.id !== id);
            saveReturns();
            renderReturns();
            showToast('تم حذف المرتجع', 'success');
        });
    };

    if(btnAddReturn) {
        btnAddReturn.addEventListener('click', () => {
            const invoice = returnInvoice.value.trim();
            const product = returnProduct.value.trim();
            const qty = parseInt(returnQty.value) || 1;
            const amount = parseFloat(returnAmount.value);
            const reason = returnReason.value.trim();

            if(!invoice && !product) {
                showToast('أدخل رقم الفاتورة أو اسم المنتج على الأقل', 'error'); return;
            }
            if(!amount || amount <= 0) {
                showToast('الرجاء إدخال مبلغ صحيح', 'error'); return;
            }

            const now = new Date();
            // البحث عن صاحب البيع لربط المرتجع
            const relatedSale = salesLog.find(s => String(s.id) === String(invoice) || (s.description && s.description.includes(product || '__none__')));
            const empName = relatedSale ? relatedSale.empName : '';

            returnsLog.push({
                id: Date.now(),
                invoice: invoice,
                product: product || '-',
                qty: qty,
                amount: amount,
                reason: reason || '-',
                empName: empName,
                date: now.toLocaleDateString('ar-EG'),
                time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
            });
            saveReturns();
            renderReturns();
            returnInvoice.value = '';
            returnProduct.value = '';
            returnQty.value = '';
            returnAmount.value = '';
            returnReason.value = '';
            showToast(`تم تسجيل مرتجع بقيمة ${fmt(amount)}`, 'success');
            addNotification(`مرتجع ${fmt(amount)} على فاتورة #${invoice || 'بدون رقم'}`, 'return');
        });
    }

    // =================> 9) الإشعارات <=================
    const notificationsTbody = document.getElementById('notifications-tbody');
    const btnMarkAllRead = document.getElementById('btn-mark-all-read');

    function updateNotificationBadge() {
        const badge = document.getElementById('nav-notifications-badge');
        if(!badge) return;
        const unread = notificationsLog.filter(n => !n.read).length;
        if(unread > 0) {
            badge.style.display = 'inline-flex';
            badge.textContent = unread > 99 ? '99+' : unread;
        } else {
            badge.style.display = 'none';
        }
    }

    function renderNotifications() {
        if(!notificationsTbody) return;
        const sTotal = document.getElementById('notifications-summary-total');
        const sNew = document.getElementById('notifications-summary-new');
        if(sTotal) sTotal.textContent = notificationsLog.length;
        if(sNew) sNew.textContent = notificationsLog.filter(n => !n.read).length;
        updateNotificationBadge();
        if(notificationsLog.length === 0) {
            notificationsTbody.innerHTML = `
                <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-bell-slash" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    لا توجد إشعارات
                </td></tr>`;
            return;
        }
        notificationsTbody.innerHTML = '';
        [...notificationsLog].reverse().forEach(n => {
            const tr = document.createElement('tr');
            const icons = { commission: 'fas fa-hand-holding-dollar', salary: 'fas fa-file-invoice-dollar', return: 'fas fa-arrow-rotate-left', warning: 'fas fa-triangle-exclamation', sale: 'fas fa-cart-plus', withdrawal: 'fas fa-hand-holding-usd', online: 'fas fa-globe', system: 'fas fa-gears', info: 'fas fa-info-circle' };
            const icon = icons[n.type] || icons.info;
            const readHtml = n.read
                ? `<span class="status-badge" style="background-color: var(--bg-color); color: var(--text-muted);">مقروء</span>`
                : `<span class="status-badge" style="background-color: var(--primary); color: white;">جديد</span>`;
            tr.innerHTML = `
                <td style="text-align:center;"><i class="${icon}" style="color: var(--primary); font-size: 18px;"></i></td>
                <td style="text-align:right; font-weight:600;">${n.message}</td>
                <td>${n.date} ${n.time}</td>
                <td>${readHtml}</td>
                <td class="admin-table-cell">
                    <div style="display:flex; justify-content:center; gap:10px;">
                        ${!n.read ? `<button class="btn-icon-only" title="تحديد كمقروء" onclick="window.markNotificationRead(${n.id})" style="color: var(--primary); background:transparent; border:none; cursor:pointer; font-size:16px;"><i class="fas fa-check-double"></i></button>` : ''}
                        <button class="btn-icon-only" title="حذف" onclick="window.deleteNotification(${n.id})" style="color: var(--danger); background:transparent; border:none; cursor:pointer; font-size:16px;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            `;
            notificationsTbody.appendChild(tr);
        });
    }

    window.markNotificationRead = function(id) {
        const n = notificationsLog.find(x => x.id === id);
        if(!n) return;
        n.read = true;
        saveNotifications();
        renderNotifications();
    };

    window.deleteNotification = function(id) {
        showConfirm('حذف إشعار', 'هل أنت متأكد من حذف هذا الإشعار؟', () => {
            notificationsLog = notificationsLog.filter(x => x.id !== id);
            saveNotifications();
            renderNotifications();
            showToast('تم حذف الإشعار', 'success');
        });
    };

    if(btnMarkAllRead) {
        btnMarkAllRead.addEventListener('click', () => {
            notificationsLog.forEach(n => n.read = true);
            saveNotifications();
            renderNotifications();
            showToast('تم تحديد جميع الإشعارات كمقروءة', 'success');
        });
    }

    // =================> 10) الإعدادات <=================
    const btnSaveSettings = document.getElementById('btn-save-settings');
    const btnExportBackup = document.getElementById('btn-export-backup');
    const btnClearAllData = document.getElementById('btn-clear-all-data');

    function loadSettings() {
        const set = id => {
            const el = document.getElementById(id);
            if(el) el.value = storeSettings[id.replace('settings-', '')] !== undefined ? storeSettings[id.replace('settings-', '')] : '';
        };
        set('settings-store-name');
        set('settings-currency');
        set('settings-default-discount');
        const ac = document.getElementById('settings-auto-cleanup');
        if(ac) ac.value = storeSettings.autoCleanupDays != null ? storeSettings.autoCleanupDays : 0;
        renderNavVisibilityList();
        renderNotifSettings();
        renderWaSettings();
        const endEnable = document.getElementById('settings-endday-pass-enable');
        if(endEnable) endEnable.checked = !!String(storeSettings.endOfDayPassword || '');
        const autoBackup = document.getElementById('settings-auto-backup');
        if(autoBackup) autoBackup.checked = !!storeSettings.autoBackupEnabled;
        renderBackupPathsUI();

        // إعدادات الضريبة والطباعة
        const taxEnableEl = document.getElementById('settings-tax-enabled');
        if(taxEnableEl) taxEnableEl.checked = storeSettings.taxEnabled !== false;
        const taxPercentEl = document.getElementById('settings-tax-percent');
        if(taxPercentEl) taxPercentEl.value = storeSettings.taxPercent != null ? storeSettings.taxPercent : 14;
        const taxIncEl = document.getElementById('settings-tax-included');
        if(taxIncEl) taxIncEl.value = storeSettings.taxIncluded === true ? 'included' : 'excluded';
        const thermalAutoEl = document.getElementById('settings-thermal-autoprint');
        if(thermalAutoEl) thermalAutoEl.checked = !!storeSettings.thermalAutoPrint;

        if(taxEnableEl) taxEnableEl.addEventListener('change', () => {
            storeSettings.taxEnabled = taxEnableEl.checked;
            saveSettings();
            updateInvoiceTotals();
            showToast('تم تحديث إعداد الضريبة', 'success');
        });
        if(taxPercentEl) taxPercentEl.addEventListener('input', () => {
            storeSettings.taxPercent = parseFloat(taxPercentEl.value) || 0;
            saveSettings();
            updateInvoiceTotals();
        });
        if(taxIncEl) taxIncEl.addEventListener('change', () => {
            storeSettings.taxIncluded = taxIncEl.value === 'included';
            saveSettings();
            updateInvoiceTotals();
            showToast('تم تحديث طريقة احتساب الضريبة', 'success');
        });
        if(thermalAutoEl) thermalAutoEl.addEventListener('change', () => {
            storeSettings.thermalAutoPrint = thermalAutoEl.checked;
            saveSettings();
            showToast(thermalAutoEl.checked ? 'تم تفعيل الطباعة الحرارية بعد البيع' : 'تم إيقاف الطباعة الحرارية', 'success');
        });
    }

    function navSectionIdFor(item) {
        const direct = item.getAttribute('data-nav-section');
        if(direct) return direct;
        const text = item.textContent.trim();
        const map = {
            'المبيعات': 'section-sales',
            'لوحة التحكم': 'section-dashboard',
            'الطلبات الأونلاين': 'section-online',
            'الحضور والانصراف': 'section-attendance',
            'الملاحظات': 'section-notes',
            'السلف': 'section-loans',
            'المشتريات': 'section-purchases',
            'مناديب التوصيل': 'section-delivery',
            'قاعدة بيانات العملاء': 'section-customers',
            'المنتجات': 'section-products',
            'الموظفين': 'section-employees',
            'التقارير': 'section-reports',
            'الإحصائيات': 'section-stats',
            'إحصائيات الموظفين': 'section-employee-stats',
            'العمولات': 'section-commissions',
            'السجلات': 'section-records',
            'المرتبات': 'section-salaries',
            'المرتجعات': 'section-returns',
            'الإشعارات': 'section-notifications',
            'الإعدادات': 'section-settings'
        };
        for(const k in map) { if(text.includes(k)) return map[k]; }
        return null;
    }

    function applyNavVisibility() {
        const hidden = storeSettings.hiddenNavSections || [];
        document.querySelectorAll('.nav-item').forEach(item => {
            const sid = navSectionIdFor(item);
            if(!sid) return;
            const isHidden = hidden.indexOf(sid) > -1;
            item.style.display = isHidden ? 'none' : '';
        });
    }

    function renderNavVisibilityList() {
        const cont = document.getElementById('settings-nav-visibility-list');
        if(!cont) return;
        const hidden = storeSettings.hiddenNavSections || [];
        let html = '';
        document.querySelectorAll('.nav-item').forEach(item => {
            const sid = navSectionIdFor(item);
            if(!sid) return;
            const label = item.textContent.trim();
            const iconEl = item.querySelector('i');
            const icon = iconEl ? iconEl.className : 'fas fa-circle';
            const checked = hidden.indexOf(sid) === -1;
            html += `
                <div class="prototype-row">
                    <label class="toggle-label"><i class="${icon}"></i> ${label}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" data-nav-sec="${sid}" ${checked ? 'checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </div>`;
        });
        cont.innerHTML = html;
        cont.querySelectorAll('input[data-nav-sec]').forEach(inp => {
            inp.addEventListener('change', () => {
                const sid = inp.getAttribute('data-nav-sec');
                let hidden = storeSettings.hiddenNavSections || [];
                if(inp.checked) hidden = hidden.filter(x => x !== sid);
                else { if(hidden.indexOf(sid) === -1) hidden.push(sid); }
                storeSettings.hiddenNavSections = hidden;
                saveSettings();
                applyNavVisibility();
            });
        });
    }

    const notifTypes = [
        { key: 'sale', icon: 'fas fa-cart-plus', label: 'إشعارات المبيعات' },
        { key: 'commission', icon: 'fas fa-hand-holding-dollar', label: 'إشعارات العمولات وأهداف المبيعات' },
        { key: 'withdrawal', icon: 'fas fa-hand-holding-usd', label: 'إشعارات السحب والخصومات' },
        { key: 'salary', icon: 'fas fa-file-invoice-dollar', label: 'إشعارات المرتبات' },
        { key: 'return', icon: 'fas fa-arrow-rotate-left', label: 'إشعارات المرتجعات' },
        { key: 'online', icon: 'fas fa-globe', label: 'إشعارات الطلبات الأونلاين' },
        { key: 'warning', icon: 'fas fa-triangle-exclamation', label: 'إشعارات التحذير' },
        { key: 'system', icon: 'fas fa-gears', label: 'إشعارات النظام والإعدادات' }
    ];

    function renderNotifSettings() {
        const cont = document.getElementById('settings-notif-list');
        if(!cont) return;
        if(!storeSettings.notifEnabled || typeof storeSettings.notifEnabled !== 'object') storeSettings.notifEnabled = {};
        let html = '';
        notifTypes.forEach(t => {
            const on = storeSettings.notifEnabled[t.key] !== false;
            html += `
                <div class="prototype-row">
                    <label class="toggle-label"><i class="${t.icon}"></i> ${t.label}</label>
                    <label class="toggle-switch">
                        <input type="checkbox" data-notif-key="${t.key}" ${on ? 'checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </div>`;
        });
        cont.innerHTML = html;
        cont.querySelectorAll('input[data-notif-key]').forEach(inp => {
            inp.addEventListener('change', () => {
                const key = inp.getAttribute('data-notif-key');
                storeSettings.notifEnabled[key] = inp.checked;
                saveSettings();
                showToast('تم تحديث إعداد الإشعارات', 'success');
            });
        });
    }

    function applyAutoCleanup() {
        const days = Number(storeSettings.autoCleanupDays) || 0;
        if(days <= 0) return;
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        const filterByDate = (arr) => arr.filter(r => {
            const k = normEmpDate(r.date);
            if(!k) return false;
            const d = parseNormKey(k);
            return d && d >= cutoff;
        });
        const beforeCount = salesLog.length + attendanceLog.length + loansLog.length + returnsLog.length + expensesLog.length + damageLog.length;
        salesLog = filterByDate(salesLog);
        attendanceLog = filterByDate(attendanceLog);
        loansLog = filterByDate(loansLog);
        returnsLog = filterByDate(returnsLog);
        expensesLog = filterByDate(expensesLog);
        damageLog = filterByDate(damageLog);
        if(salesLog.length + attendanceLog.length + loansLog.length + returnsLog.length + expensesLog.length + damageLog.length !== beforeCount) {
            saveSales(); saveAttendance(); saveLoans(); saveReturns(); saveExpenses(); saveDamage();
        }
    }

    if(btnSaveSettings) {
        btnSaveSettings.addEventListener('click', () => {
            storeSettings.storeName = document.getElementById('settings-store-name').value.trim() || 'DataGris Store';
            storeSettings.currency = document.getElementById('settings-currency').value.trim() || 'ج.م';
            storeSettings.defaultDiscount = parseFloat(document.getElementById('settings-default-discount').value) || 0;
            saveSettings();
            // تحديث العنوان في الشاشة الترحيبية
            const titleEl = document.querySelector('.welcome-title');
            if(titleEl) titleEl.textContent = storeSettings.storeName;
            const logoTxt = document.querySelector('.logo-text');
            if(logoTxt) logoTxt.textContent = storeSettings.storeName;
            showToast('تم حفظ الإعدادات بنجاح', 'success');
            addNotification('تم تحديث إعدادات المتجر', 'system');
        });
    }

    if(btnExportBackup) {
        btnExportBackup.addEventListener('click', () => {
            const backup = {
                storeSettings,
                employeesLog,
                salesLog,
                attendanceLog,
                notesLog,
                loansLog,
                purchasesLog,
                suppliersLog,
                deliveryLog,
                deliveryShipmentsLog,
                customersLog: window.customersLog,
                productsLog: window.productsLog,
                categoriesLog: window.categoriesLog,
                commissionsLog,
                salariesLog,
                returnsLog,
                expensesLog,
                damageLog,
                notificationsLog,
                onlineOrdersLog,
                privateNotesLog,
                scheduledNotesLog
            };
            const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const d = new Date();
            a.href = url;
            a.download = `backup-${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('تم تصدير النسخة الاحتياطية بنجاح', 'success');
        });
    }

    if(btnClearAllData) {
        btnClearAllData.addEventListener('click', () => {
            showConfirm('مسح جميع البيانات', 'هل أنت متأكد من مسح جميع بيانات النظام نهائياً؟ لا يمكن التراجع عن هذا الإجراء!', () => {
                const keys = [
                    'salesLog','attendanceLog','notesLog','loansLog','purchasesLog','suppliersLog',
                    'deliveryLog','deliveryShipmentsLog','customersLog','productsLog','categoriesLog',
                    'employeesLog','commissionsLog','salariesLog','returnsLog','notificationsLog',
                    'expensesLog','damageLog','onlineOrdersLog','privateNotesLog','scheduledNotesLog'
                ];
                keys.forEach(k => localStorage.removeItem(k));
                // إعادة تهيئة المتغيرات
                salesLog = []; attendanceLog = []; notesLog = []; loansLog = [];
                purchasesLog = []; suppliersLog = []; deliveryLog = []; deliveryShipmentsLog = [];
                window.customersLog = []; window.productsLog = []; window.categoriesLog = ['الكل'];
                employeesLog = []; commissionsLog = []; salariesLog = []; returnsLog = []; notificationsLog = [];
                expensesLog = []; damageLog = []; onlineOrdersLog = []; privateNotesLog = []; scheduledNotesLog = [];
                renderCustomers(); renderEmployees(); populateEmployeeSelects();
                showToast('تم مسح جميع البيانات', 'success');
                setTimeout(() => window.location.reload(), 800);
            });
        });
    }

    // استعادة البيانات من ملف نسخة احتياطية
    const btnRestoreBackup = document.getElementById('btn-restore-backup');
    const restoreFileInput = document.getElementById('restore-file-input');
    if(btnRestoreBackup && restoreFileInput) {
        btnRestoreBackup.addEventListener('click', () => restoreFileInput.click());
        restoreFileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if(!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                let data = null;
                try { data = JSON.parse(ev.target.result); } catch(err) { showToast('الملف غير صالح أو تالف', 'error'); return; }
                showConfirm('استعادة البيانات', 'سيتم استبدال جميع البيانات الحالية بالنسخة المحفوظة. هل أنت متأكد؟', () => {
                    Object.keys(data).forEach(k => {
                        try { localStorage.setItem(k, JSON.stringify(data[k])); } catch(err) {}
                    });
                    showToast('تمت استعادة البيانات بنجاح', 'success');
                    setTimeout(() => window.location.reload(), 900);
                });
            };
            reader.readAsText(file);
            restoreFileInput.value = '';
        });
    }

    // تغيير كلمة مرور المدير + جملة الاستعادة
    const btnChangeAdminPassword = document.getElementById('btn-change-admin-password');
    if(btnChangeAdminPassword) {
        btnChangeAdminPassword.addEventListener('click', () => {
            const oldP = document.getElementById('settings-admin-password').value.trim();
            const newP = document.getElementById('settings-new-password').value.trim();
            const rec = document.getElementById('settings-recovery-phrase').value.trim();
            const current = String(storeSettings.adminPassword || '0');
            if(oldP !== '' && oldP !== current) { showToast('كلمة المرور الحالية غير صحيحة', 'error'); return; }
            if(!newP && !rec) { showToast('أدخل كلمة مرور جديدة أو جملة استعادة على الأقل', 'error'); return; }
            if(newP) storeSettings.adminPassword = newP;
            if(rec) storeSettings.recoveryPhrase = rec;
            saveSettings();
            document.getElementById('settings-admin-password').value = '';
            document.getElementById('settings-new-password').value = '';
            document.getElementById('settings-recovery-phrase').value = '';
            showToast('تم تحديث كلمة المرور وبيانات الاستعادة', 'success');
            addNotification('تم تغيير كلمة مرور المدير', 'system');
        });
    }

    // ============ قوالب رسائل الواتساب ============
    const waTemplateKeys = { 'waTemplatePreparing': 'preparing', 'waTemplateDelivering': 'delivering', 'waTemplateDelivered': 'delivered', 'waTemplateCustomer': 'customer' };
    let lastFocusedWa = null;

    function autoResizeTextarea(el) {
        if(!el) return;
        el.style.setProperty('height', 'auto', 'important');
        el.style.setProperty('height', Math.max(64, el.scrollHeight || 0) + 'px', 'important');
    }

    function renderWaSettings() {
        const tpls = storeSettings.waTemplates || {};
        for(const id in waTemplateKeys) {
            const el = document.getElementById(id);
            if(!el) continue;
            el.value = tpls[waTemplateKeys[id]] || '';
            autoResizeTextarea(el);
        }
    }

    document.querySelectorAll('.wa-textarea').forEach(ta => {
        ta.addEventListener('focus', () => { lastFocusedWa = ta; });
        ta.addEventListener('input', () => {
            autoResizeTextarea(ta);
            const key = waTemplateKeys[ta.id];
            if(key) {
                if(!storeSettings.waTemplates) storeSettings.waTemplates = {};
                storeSettings.waTemplates[key] = ta.value;
                saveSettings();
            }
        });
    });

    const btnWaPreview = document.getElementById('btn-wa-preview');
    const waPreviewBox = document.getElementById('wa-preview-box');
    if(btnWaPreview && waPreviewBox) {
        btnWaPreview.addEventListener('click', () => {
            const sampleVars = {
                'الاسم': 'عميل تجريبي',
                'رقم_الطلب': '#2',
                'المنتج': '- شيبسي × 2\n- كوكاكولا × 1',
                'العدد': 3,
                'السعر': '85.00'
            };
            const labels = { preparing: 'قيد التجهيز', delivering: 'في التوصيل', delivered: 'تم التسليم', customer: 'رسالة العميل العامة' };
            const tpls = storeSettings.waTemplates || {};
            let html = '';
            for(const key in labels) {
                const raw = tpls[key] || '';
                const msg = fillTemplate(raw, sampleVars);
                html += `
                    <div style="border:1px solid var(--border-color); border-radius:10px; padding:10px 12px; margin-bottom:10px; background:var(--card-bg);">
                        <div style="font-size:12px; font-weight:800; color:var(--primary); margin-bottom:6px;"><i class="fab fa-whatsapp"></i> ${labels[key]}</div>
                        <div style="font-size:13px; white-space:pre-wrap; line-height:1.7; color:var(--text-color);">${raw ? msg : '<span style="color:var(--text-muted);">القالب فارغ</span>'}</div>
                    </div>`;
            }
            waPreviewBox.innerHTML = html;
            waPreviewBox.style.display = 'block';
        });
    }

    document.querySelectorAll('#wa-template-pills .chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const tag = chip.getAttribute('data-wa-tag');
            if(!lastFocusedWa) { showToast('اضغط على القالب أولاً لاختيار مكان الإدراج', 'error'); return; }
            const start = lastFocusedWa.selectionStart !== undefined ? lastFocusedWa.selectionStart : lastFocusedWa.value.length;
            const end = lastFocusedWa.selectionEnd !== undefined ? lastFocusedWa.selectionEnd : lastFocusedWa.value.length;
            const text = lastFocusedWa.value;
            lastFocusedWa.value = text.substring(0, start) + tag + text.substring(end);
            lastFocusedWa.selectionStart = lastFocusedWa.selectionEnd = start + tag.length;
            lastFocusedWa.focus();
            lastFocusedWa.dispatchEvent(new Event('input'));
        });
    });

    function fillTemplate(tpl, vars) {
        return String(tpl || '').replace(/\{([^}]+)\}/g, (m, k) => vars && vars[k] !== undefined ? vars[k] : m);
    }

    function waPhone(p) {
        let s = String(p || '').replace(/[^\d]/g, '');
        if(/^00/.test(s)) s = s.slice(2);
        if(/^20/.test(s)) return s;
        if(/^01[0-9]{9}$/.test(s)) return '20' + s.slice(1);
        if(/^0/.test(s)) return '20' + s.slice(1);
        return s;
    }

    function waLink(phone, message) {
        const p = waPhone(phone);
        return 'https://wa.me/' + p + '?text=' + encodeURIComponent(message || '');
    }

    window.chatCustomerWhatsApp = function(name, phone) {
        const p = waPhone(phone);
        if(!p) { showToast('لا يوجد رقم هاتف لهذا العميل', 'error'); return; }
        const tpl = (storeSettings.waTemplates || {}).customer || '';
        const message = fillTemplate(tpl, { 'الاسم': name || 'عميلنا' });
        window.open(waLink(phone, message), '_blank');
    };

    window.sendOrderWhatsApp = function(id) {
        const order = onlineOrdersLog.find(o => o.id === id);
        if(!order) return;
        const p = waPhone(order.phone);
        if(!p) { showToast('لا يوجد رقم هاتف لهذا الطلب', 'error'); return; }
        const tpl = (storeSettings.waTemplates || {})[order.status] || '';
        const items = order.items.map(i => i.name + ' × ' + i.qty).join('\n- ');
        const qty = order.items.reduce((s, i) => s + (i.qty || 0), 0);
        const price = fmt(order.total);
        const message = fillTemplate(tpl, {
            'الاسم': order.customerName || 'عميلنا',
            'رقم_الطلب': '#' + order.id,
            'المنتج': items,
            'العدد': qty,
            'السعر': price
        });
        window.open(waLink(order.phone, message), '_blank');
    };

    // ============ كلمة مرور إنهاء اليوم ============
    const btnSaveEnddayPass = document.getElementById('btn-save-endday-pass');
    const btnRemoveEnddayPass = document.getElementById('btn-remove-endday-pass');
    const enddayEnable = document.getElementById('settings-endday-pass-enable');

    if(btnSaveEnddayPass) {
        btnSaveEnddayPass.addEventListener('click', () => {
            const newP = document.getElementById('settings-endday-new-pass').value.trim();
            const confirmP = document.getElementById('settings-endday-confirm-pass').value.trim();
            const oldP = document.getElementById('settings-endday-old-pass').value.trim();
            const current = String(storeSettings.endOfDayPassword || '');
            if(oldP !== '' && oldP !== current) { showToast('كلمة مرور إنهاء اليوم الحالية غير صحيحة', 'error'); return; }
            if(!newP) { showToast('أدخل كلمة المرور الجديدة', 'error'); return; }
            if(newP !== confirmP) { showToast('كلمتا المرور غير متطابقتين', 'error'); return; }
            storeSettings.endOfDayPassword = newP;
            saveSettings();
            document.getElementById('settings-endday-new-pass').value = '';
            document.getElementById('settings-endday-confirm-pass').value = '';
            document.getElementById('settings-endday-old-pass').value = '';
            if(enddayEnable) enddayEnable.checked = true;
            showToast('تم حفظ كلمة مرور إنهاء اليوم', 'success');
            addNotification('تم تفعيل كلمة مرور إنهاء اليوم', 'system');
        });
    }

    if(btnRemoveEnddayPass) {
        btnRemoveEnddayPass.addEventListener('click', () => {
            const oldP = document.getElementById('settings-endday-old-pass').value.trim();
            const current = String(storeSettings.endOfDayPassword || '');
            if(!current) { showToast('لا توجد كلمة مرور محددة', 'error'); return; }
            if(oldP !== current) { showToast('أدخل كلمة مرور إنهاء اليوم الحالية أولاً لإزالتها', 'error'); return; }
            storeSettings.endOfDayPassword = '';
            saveSettings();
            if(enddayEnable) enddayEnable.checked = false;
            showToast('تمت إزالة كلمة مرور إنهاء اليوم', 'success');
            addNotification('تم إلغاء كلمة مرور إنهاء اليوم', 'system');
        });
    }

    if(enddayEnable) {
        enddayEnable.addEventListener('change', () => {
            if(enddayEnable.checked && !String(storeSettings.endOfDayPassword || '')) {
                showToast('اكتب كلمة مرور جديدة ثم اضغط حفظ', 'error');
                enddayEnable.checked = false;
            }
        });
    }

    // ============ النسخ الاحتياطي التلقائي ============
    const backupHandles = {};
    const BACKUP_FILENAME = 'data-gris-backup.json';

    function idbOpen() {
        return new Promise((resolve, reject) => {
            try {
                const req = indexedDB.open('dataGrisBackup', 1);
                req.onupgradeneeded = () => { req.result.createObjectStore('handles'); };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            } catch(err) { reject(err); }
        });
    }
    async function idbSet(key, value) {
        try { const db = await idbOpen(); return await new Promise((res, rej) => { const tx = db.transaction('handles', 'readwrite'); tx.objectStore('handles').put(value, key); tx.oncomplete = res; tx.onerror = () => rej(tx.error); }); } catch(err) {}
    }
    async function idbGet(key) {
        try { const db = await idbOpen(); return await new Promise((res, rej) => { const tx = db.transaction('handles', 'readonly'); const req = tx.objectStore('handles').get(key); req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); }); } catch(err) { return undefined; }
    }

    function collectBackupData() {
        return {
            storeSettings,
            employeesLog,
            salesLog,
            attendanceLog,
            notesLog,
            loansLog,
            purchasesLog,
            suppliersLog,
            deliveryLog,
            deliveryShipmentsLog,
            customersLog: window.customersLog,
            productsLog: window.productsLog,
            categoriesLog: window.categoriesLog,
            commissionsLog,
            salariesLog,
            returnsLog,
            expensesLog,
            damageLog,
            notificationsLog,
            onlineOrdersLog,
            privateNotesLog,
            scheduledNotesLog
        };
    }

    async function writeBackupToHandle(handle, data) {
        try {
            const fileHandle = await handle.getFileHandle(BACKUP_FILENAME, { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(JSON.stringify(data, null, 2));
            await writable.close();
            return true;
        } catch(err) { return false; }
    }

    async function pickBackupFolder(target) {
        if(!window.showDirectoryPicker) {
            showToast('المتصفح الحالي لا يدعم اختيار المجلدات — استخدم Chrome أو Edge', 'error');
            return;
        }
        try {
            const handle = await window.showDirectoryPicker({ mode: 'readwrite' });
            backupHandles[target] = handle;
            await idbSet('handle_' + target, handle);
            if(target === 'cloud') storeSettings.cloudBackupPath = handle.name;
            else storeSettings.localBackupPath = handle.name;
            saveSettings();
            renderBackupPathsUI();
            showToast('تم اختيار المجلد: ' + handle.name, 'success');
            addNotification('تم اختيار مجلد النسخ الاحتياطي: ' + handle.name, 'system');
        } catch(err) { /* المستخدم ألغى الاختيار */ }
    }

    function renderBackupPathsUI() {
        const cloudInput = document.getElementById('settings-cloud-backup-path');
        const localInput = document.getElementById('settings-local-backup-path');
        if(cloudInput) cloudInput.value = storeSettings.cloudBackupPath || '';
        if(localInput) localInput.value = storeSettings.localBackupPath || '';
    }

    async function loadBackupHandles() {
        const cloud = await idbGet('handle_cloud');
        const local = await idbGet('handle_local');
        if(cloud) backupHandles.cloud = cloud;
        if(local) backupHandles.local = local;
        if((cloud || local) && !storeSettings.cloudBackupPath && !storeSettings.localBackupPath) {
            if(cloud) storeSettings.cloudBackupPath = cloud.name;
            if(local) storeSettings.localBackupPath = local.name;
            saveSettings();
        }
        renderBackupPathsUI();
    }

    let lastBackupSignature = '';
    let backupRunning = false;
    function dataSignature() {
        let sig = 0;
        const arrs = [salesLog, attendanceLog, loansLog, returnsLog, notificationsLog, onlineOrdersLog, employeesLog, purchasesLog, commissionsLog, expensesLog, damageLog];
        arrs.forEach(a => { sig += (a.length * 7 + a.reduce((s, x) => s + (x.id || 0) + (x.date ? String(x.date).length : 0), 0)) % 1000003; });
        return String(sig);
    }

    async function performBackup(silent) {
        const data = collectBackupData();
        let written = 0;
        if(backupHandles.cloud) { if(await writeBackupToHandle(backupHandles.cloud, data)) written++; }
        if(backupHandles.local) { if(await writeBackupToHandle(backupHandles.local, data)) written++; }
        if(written > 0) {
            lastBackupSignature = dataSignature();
            if(!silent) showToast('تم أخذ النسخة الاحتياطية (' + written + ')', 'success');
        } else {
            if(!silent) showToast('لم يتم اختيار أي مجلد — اختر مجلداً أولاً أو استخدم التصدير', 'error');
        }
        return written;
    }

    const btnBrowseCloud = document.getElementById('btn-browse-cloud');
    const btnBrowseLocal = document.getElementById('btn-browse-local');
    const btnBackupNow = document.getElementById('btn-backup-now');
    const autoBackupToggle = document.getElementById('settings-auto-backup');

    if(btnBrowseCloud) btnBrowseCloud.addEventListener('click', () => pickBackupFolder('cloud'));
    if(btnBrowseLocal) btnBrowseLocal.addEventListener('click', () => pickBackupFolder('local'));
    if(btnBackupNow) btnBackupNow.addEventListener('click', () => performBackup(false));

    if(autoBackupToggle) {
        autoBackupToggle.addEventListener('change', () => {
            storeSettings.autoBackupEnabled = autoBackupToggle.checked;
            saveSettings();
            showToast(storeSettings.autoBackupEnabled ? 'تم تفعيل النسخ الاحتياطي التلقائي' : 'تم إيقاف النسخ الاحتياطي التلقائي', 'success');
        });
    }

    setInterval(async () => {
        if(!storeSettings.autoBackupEnabled) return;
        if(!backupHandles.cloud && !backupHandles.local) return;
        if(backupRunning) return;
        const sig = dataSignature();
        if(sig !== lastBackupSignature) {
            backupRunning = true;
            const ok = await performBackup(true);
            backupRunning = false;
            if(ok > 0) lastBackupSignature = sig;
        }
    }, 20000);
    loadBackupHandles();


    // إعداد المسح التلقائي للسجلات القديمة
    const settingsAutoCleanup = document.getElementById('settings-auto-cleanup');
    if(settingsAutoCleanup) {
        settingsAutoCleanup.addEventListener('change', () => {
            storeSettings.autoCleanupDays = parseInt(settingsAutoCleanup.value) || 0;
            saveSettings();
            showToast(storeSettings.autoCleanupDays > 0 ? `تم تفعيل المسح التلقائي كل ${storeSettings.autoCleanupDays} يوم` : 'تم إلغاء المسح التلقائي', 'success');
        });
    }

    // تصفية الحسابات وبدء فترة جديدة
    const btnStartNewPeriod = document.getElementById('btn-start-new-period');
    if(btnStartNewPeriod) {
        btnStartNewPeriod.addEventListener('click', () => {
            showConfirm('تصفية الحسابات وبدء فترة جديدة', 'سيتم مسح كافة المبيعات والحضور والسحب والمرتجعات والمصروفات وتصفير سجل العمولات لبدء فترة جديدة. هل أنت متأكد؟', () => {
                const now = new Date();
                localStorage.setItem('commissionsResetDay', normEmpDate(now.toLocaleDateString('ar-EG')));
                salesLog = []; attendanceLog = []; loansLog = []; returnsLog = []; expensesLog = []; damageLog = [];
                saveSales(); saveAttendance(); saveLoans(); saveReturns(); saveExpenses(); saveDamage();
                showToast('تم تصفية الحسابات وبدء فترة جديدة', 'success');
                renderCommissions(); renderSalaries(); renderReturns(); renderRecords();
            });
        });
    }

    // تطبيق إخفاء عناصر القائمة الجانبية + تنظيف السجلات القديمة عند التشغيل
    applyNavVisibility();
    applyAutoCleanup();

    // =================================================================
    // ===================== الأقسام الجديدة (3) ====================
    // ==== (لوحة التحكم - الطلبات الأونلاين - ملاحظات خاصة/مجدولة) ====
    // =================================================================

    let onlineOrdersLog = JSON.parse(localStorage.getItem('onlineOrdersLog')) || [];
    let privateNotesLog = JSON.parse(localStorage.getItem('privateNotesLog')) || [];
    let scheduledNotesLog = JSON.parse(localStorage.getItem('scheduledNotesLog')) || [];
    let onlineActiveStatusFilter = 'all';
    let onlineSearchQuery = '';

    function saveOnlineOrders() { localStorage.setItem('onlineOrdersLog', JSON.stringify(onlineOrdersLog)); }
    function savePrivateNotes() { localStorage.setItem('privateNotesLog', JSON.stringify(privateNotesLog)); }
    function saveScheduledNotes() { localStorage.setItem('scheduledNotesLog', JSON.stringify(scheduledNotesLog)); }

    // =================> 11) لوحة التحكم <=================
    const dashTodaySales = document.getElementById('dash-today-sales');
    const dashBestSeller = document.getElementById('dash-best-seller');
    const dashPresent = document.getElementById('dash-present');
    const dashNetProfit = document.getElementById('dash-net-profit');
    const dashRecentTbody = document.getElementById('dash-recent-tbody');

    function renderDashboard() {
        // مبيعات اليوم (السجل هو مبيعات الوردية الحالية)
        const salesToday = salesLog;
        let todayCount = salesToday.length;
        let todayTotal = 0;
        salesToday.forEach(s => todayTotal += Number(s.totalAmount) || 0);
        if(dashTodaySales) dashTodaySales.textContent = `${fmt(todayTotal)} (${todayCount} فاتورة)`;

        // أفضل بائع (خلال مبيعات الوردية الحالية)
        const salesByEmp = {};
        salesLog.forEach(s => {
            const key = s.empName || s.empId || 'مجهول';
            salesByEmp[key] = (salesByEmp[key] || 0) + 1;
        });
        let bestName = null, bestCount = 0;
        Object.keys(salesByEmp).forEach(k => {
            if(salesByEmp[k] > bestCount) { bestCount = salesByEmp[k]; bestName = k; }
        });
        if(dashBestSeller) dashBestSeller.textContent = bestName ? `${bestName} (${bestCount} عملية)` : 'لا يوجد';

        // الحاضرون اليوم (سجل الحضور هو لليوم الحالي)
        const activeCount = employeesLog.filter(e => e.active).length;
        const presentCount = attendanceLog.filter(a => a.status === 'active').length;
        if(dashPresent) dashPresent.textContent = `${presentCount} / ${activeCount}`;

        // صافي الربح (مبيعات اليوم - تكلفة البضاعة - مصروفات اليوم)
        const dayKey = normEmpDate(new Date().toLocaleDateString('ar-EG'));
        let todayExpenses = 0;
        expensesLog.forEach(e => { if(normEmpDate(e.date) === dayKey) todayExpenses += Number(e.amount) || 0; });
        let todayCost = 0;
        salesToday.forEach(s => {
            if(s.grossProfit != null) {
                todayCost += (Number(s.totalAmount) || 0) - (Number(s.grossProfit) || 0);
            } else if(s.items && Array.isArray(s.items)) {
                s.items.forEach(it => todayCost += (Number(it.cost) || 0) * (Number(it.quantity) || 1));
            }
        });
        if(dashNetProfit) {
            const net = todayTotal - todayCost - todayExpenses;
            dashNetProfit.textContent = fmt(net);
            dashNetProfit.style.color = net >= 0 ? 'var(--success)' : 'var(--danger)';
        }

        // تنبيه المنتجات المنخفضة المخزون
        const lowStockItems = window.productsLog.filter(p => p.qty !== undefined && p.qty !== null && p.qty !== '' && (Number(p.minStock) || 0) > 0 && Number(p.qty) <= (Number(p.minStock) || 0));
        const lowStockBox = document.getElementById('dash-low-stock');
        const lowStockText = document.getElementById('dash-low-stock-text');
        if(lowStockBox && lowStockText) {
            if(lowStockItems.length > 0) {
                const names = lowStockItems.slice(0, 4).map(p => p.name).join('، ');
                lowStockText.textContent = `تنبيه: ${lowStockItems.length} منتج وصل للحد الأدنى للمخزون — ${names}${lowStockItems.length > 4 ? '...' : ''}`;
                lowStockBox.style.display = 'flex';
            } else {
                lowStockBox.style.display = 'none';
            }
        }

        // أحدث العمليات
        if(dashRecentTbody) {
            if(salesLog.length === 0 && returnsLog.length === 0 && expensesLog.length === 0) {
                dashRecentTbody.innerHTML = `
                    <tr><td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">
                        <i class="fas fa-clock" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                        لا توجد عمليات بعد.
                    </td></tr>`;
                return;
            }
            const merged = [];
            salesLog.forEach(s => merged.push({ type: 'sale', text: `فاتورة #${s.id} - ${s.empName}`, desc: s.description || '-', value: s.totalAmount, sort: s.id || 0 }));
            returnsLog.forEach(r => merged.push({ type: 'return', text: `مرتجع - ${r.empName || '-'}`, desc: r.description || r.product || '-', value: -(Number(r.amount) || Number(r.totalValue) || 0), sort: r.id || 0 }));
            expensesLog.forEach(e => merged.push({ type: 'expense', text: `مصروف - ${e.title}`, desc: e.category || '-', value: -(Number(e.amount) || 0), sort: e.id || 0 }));
            merged.sort((a, b) => b.sort - a.sort);
            dashRecentTbody.innerHTML = '';
            merged.slice(0, 10).forEach(op => {
                const tr = document.createElement('tr');
                const isNegative = op.type === 'return' || op.type === 'expense';
                const valueHtml = `<span style="font-weight:700; ${isNegative ? 'color:var(--danger);' : 'color:var(--success);'}">${fmt(op.value)}</span>`;
                const icon = op.type === 'return' ? 'fas fa-arrow-rotate-left' : (op.type === 'expense' ? 'fas fa-receipt' : 'fas fa-cart-plus');
                tr.innerHTML = `
                    <td style="text-align:center;"><i class="${icon}" style="color: var(--primary); font-size: 17px;"></i></td>
                    <td style="text-align:right; font-weight:600;">${op.text}</td>
                    <td>${op.desc}</td>
                    <td>${valueHtml}</td>
                `;
                dashRecentTbody.appendChild(tr);
            });
        }
    }

    // =================> 12) الطلبات الأونلاين <=================
    const onlineOrdersGrid = document.getElementById('online-orders-grid');
    const onlineSearchInput = document.getElementById('online-search-input');
    const btnAddOnlineOrder = document.getElementById('btn-add-online-order');
    const btnOnlineRecords = document.getElementById('btn-online-records');
    const btnClearOnlineOrders = document.getElementById('btn-clear-online-orders');
    const onlineOrderModal = document.getElementById('online-order-modal');
    const btnSaveOnlineOrder = document.getElementById('btn-save-online-order');
    const btnAddOnlineItem = document.getElementById('btn-add-online-item');
    const onlineItemsContainer = document.getElementById('online-order-items');
    const onlineOrderTotal = document.getElementById('online-order-total');

    function onlineStatusLabel(status) {
        const map = { preparing: 'قيد التجهيز', delivering: 'في التوصيل', delivered: 'تم التسليم', cancelled: 'ملغي' };
        return map[status] || status;
    }

    function onlineStatusColor(status) {
        const map = { preparing: 'var(--warning)', delivering: 'var(--primary)', delivered: 'var(--success)', cancelled: 'var(--danger)' };
        return map[status] || 'var(--text-muted)';
    }

    function renderOnlineOrders() {
        if(!onlineOrdersGrid) return;
        let orders = onlineOrdersLog;
        if(onlineActiveStatusFilter !== 'all') orders = orders.filter(o => o.status === onlineActiveStatusFilter);
        if(onlineSearchQuery) {
            const q = onlineSearchQuery.toLowerCase();
            orders = orders.filter(o => {
                const hay = `${o.customerName} ${o.phone} ${o.address} ${o.items.map(i => i.name).join(' ')}`.toLowerCase();
                return hay.includes(q);
            });
        }
        orders = [...orders].sort((a, b) => (b.id || 0) - (a.id || 0));

        // تحديث عدادات الفلاتر
        const filterBtns = document.querySelectorAll('.online-filter-btn');
        filterBtns.forEach(btn => {
            const status = btn.dataset.onlineStatus;
            const count = status === 'all' ? onlineOrdersLog.length : onlineOrdersLog.filter(o => o.status === status).length;
            btn.setAttribute('data-count', count);
            const hiddenSpan = btn.querySelector('span');
            if(!hiddenSpan) btn.innerHTML += ` <span style="background: var(--bg-color); border-radius: 20px; padding: 2px 9px; font-size: 11px; font-weight: 700; color: var(--text-muted);">${count}</span>`;
            else hiddenSpan.textContent = count;
        });

        if(orders.length === 0) {
            onlineOrdersGrid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align:center; padding:60px 20px; color:var(--text-muted); background:var(--card-bg); border:1px solid var(--border-color); border-radius:16px;">
                    <i class="fas fa-inbox" style="font-size: 42px; margin-bottom: 15px; display:block; opacity:0.3;"></i>
                    لا توجد طلبات ${onlineActiveStatusFilter !== 'all' ? 'بهذه الحالة' : 'مسجلة'}.
                </div>`;
            return;
        }

        onlineOrdersGrid.innerHTML = '';
        orders.forEach(order => {
            const card = document.createElement('div');
            card.className = 'premium-card';
            card.style.cssText = 'margin-bottom:0; display:flex; flex-direction:column; gap:12px;';
            const itemsHtml = order.items.map(i => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px dashed var(--border-color);">
                    <span style="font-weight:600;">${i.name} <span style="color:var(--text-muted); font-size:12px;">× ${i.qty}</span></span>
                    <span style="font-weight:700;">${fmt(i.price * i.qty)}</span>
                </div>`).join('');
            const nextAction = order.status === 'preparing'
                ? `<button class="btn-primary btn-lg" style="flex:1; font-size:13px; padding:8px; justify-content:center;" onclick="window.setOnlineOrderStatus(${order.id}, 'delivering')"><i class="fas fa-motorcycle"></i> بدء التوصيل</button>`
                : order.status === 'delivering'
                ? `<button class="btn-primary btn-lg" style="flex:1; font-size:13px; padding:8px; justify-content:center; background-color:var(--success);" onclick="window.setOnlineOrderStatus(${order.id}, 'delivered')"><i class="fas fa-check"></i> تأكيد التسليم</button>`
                : '';
            card.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <div style="font-weight:800; font-size:16px; color:var(--text-main);">${order.customerName || 'عميل'}</div>
                        <div style="font-size:12px; color:var(--text-muted); margin-top:3px;">
                            <i class="fas fa-phone" style="margin-left:4px;"></i>${order.phone || '-'}
                        </div>
                        <div style="font-size:12px; color:var(--text-muted); margin-top:3px;">
                            <i class="fas fa-map-marker-alt" style="margin-left:4px;"></i>${order.address || '-'}
                        </div>
                    </div>
                    <span class="status-badge" style="background: ${onlineStatusColor(order.status)}22; color: ${onlineStatusColor(order.status)}; font-weight:700;">${onlineStatusLabel(order.status)}</span>
                </div>
                <div>${itemsHtml}</div>
                <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-color); padding-top:10px;">
                    <span style="font-size:12px; color:var(--text-muted);"><i class="fas fa-clock" style="margin-left:4px;"></i>${order.date} ${order.time}</span>
                    <span style="font-weight:800; color:var(--primary);">${fmt(order.total)}</span>
                </div>
                <div style="display:flex; gap:8px;">
                    ${nextAction}
                    ${order.status === 'delivered' || order.status === 'cancelled' ? '' : `<button class="btn-soft btn-lg" style="flex:1; font-size:13px; padding:8px;" onclick="window.cancelOnlineOrder(${order.id})" title="إلغاء الطلب"><i class="fas fa-times"></i> إلغاء</button>`}
                    <button class="btn-soft btn-lg" style="flex:1; font-size:13px; padding:8px; color:#25D366;" onclick="window.sendOrderWhatsApp(${order.id})" title="مراسلة العميل عبر واتساب"><i class="fab fa-whatsapp"></i> واتساب</button>
                    <button class="btn-soft btn-lg" style="flex:1; font-size:13px; padding:8px;" onclick="window.deleteOnlineOrder(${order.id})" title="حذف"><i class="fas fa-trash-alt"></i> حذف</button>
                </div>
            `;
            onlineOrdersGrid.appendChild(card);
        });
    }

    window.setOnlineOrderStatus = function(id, status) {
        const order = onlineOrdersLog.find(o => o.id === id);
        if(!order) return;
        order.status = status;
        saveOnlineOrders();
        renderOnlineOrders();
        addNotification(`تم تحديث حالة الطلب #${id} إلى ${onlineStatusLabel(status)}`, 'online');
        showToast('تم تحديث حالة الطلب', 'success');
    };

    window.cancelOnlineOrder = function(id) {
        showConfirm('إلغاء الطلب', 'هل أنت متأكد من إلغاء هذا الطلب؟', () => {
            const order = onlineOrdersLog.find(o => o.id === id);
            if(order) { order.status = 'cancelled'; saveOnlineOrders(); renderOnlineOrders(); addNotification(`إلغاء الطلب #${id}`, 'warning'); }
            showToast('تم إلغاء الطلب', 'success');
        });
    };

    window.deleteOnlineOrder = function(id) {
        showConfirm('حذف الطلب', 'هل أنت متأكد من حذف هذا الطلب؟', () => {
            onlineOrdersLog = onlineOrdersLog.filter(o => o.id !== id);
            saveOnlineOrders();
            renderOnlineOrders();
            showToast('تم حذف الطلب', 'success');
        });
    };

    if(onlineSearchInput) {
        onlineSearchInput.addEventListener('input', () => {
            onlineSearchQuery = onlineSearchInput.value.trim();
            renderOnlineOrders();
        });
    }

    document.querySelectorAll('.online-filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.online-filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            onlineActiveStatusFilter = btn.dataset.onlineStatus;
            renderOnlineOrders();
        });
    });

    if(btnAddOnlineOrder) {
        btnAddOnlineOrder.addEventListener('click', () => {
            openOnlineOrderModal();
        });
    }

    function openOnlineOrderModal() {
        if(!onlineOrderModal) return;
        document.getElementById('online-order-customer').value = '';
        document.getElementById('online-order-phone').value = '';
        document.getElementById('online-order-address').value = '';
        document.getElementById('online-order-status').value = 'preparing';
        document.getElementById('online-order-payment').value = 'cod';
        onlineItemsContainer.innerHTML = `
            <div class="online-order-item" style="display: flex; gap: 8px; margin-bottom: 8px; align-items: center;">
                <input type="text" class="custom-input glass-input online-item-name" placeholder="المنتج" style="flex: 2; min-width: 0;">
                <input type="number" class="custom-input glass-input online-item-qty" placeholder="كمية" min="1" value="1" style="flex: 0.6; min-width: 0; text-align: center;">
                <input type="number" class="custom-input glass-input online-item-price" placeholder="السعر" min="0" style="flex: 1; min-width: 0; text-align: center;">
            </div>`;
        updateOnlineOrderTotal();
        onlineOrderModal.classList.remove('hidden');
        setTimeout(() => document.getElementById('online-order-customer').focus(), 100);
    }

    if(btnAddOnlineItem) {
        btnAddOnlineItem.addEventListener('click', () => {
            const row = document.createElement('div');
            row.className = 'online-order-item';
            row.style.cssText = 'display: flex; gap: 8px; margin-bottom: 8px; align-items: center;';
            row.innerHTML = `
                <input type="text" class="custom-input glass-input online-item-name" placeholder="المنتج" style="flex: 2; min-width: 0;">
                <input type="number" class="custom-input glass-input online-item-qty" placeholder="كمية" min="1" value="1" style="flex: 0.6; min-width: 0; text-align: center;">
                <input type="number" class="custom-input glass-input online-item-price" placeholder="السعر" min="0" style="flex: 1; min-width: 0; text-align: center;">
                <button class="btn-soft-danger btn-icon-only" style="background:transparent; border:none; color:var(--danger); cursor:pointer;" onclick="this.parentElement.remove(); updateOnlineOrderTotal();"><i class="fas fa-times"></i></button>`;
            onlineItemsContainer.appendChild(row);
            updateOnlineOrderTotal();
        });
    }

    function updateOnlineOrderTotal() {
        if(!onlineOrderTotal) return;
        let total = 0;
        document.querySelectorAll('.online-order-item').forEach(row => {
            const price = parseFloat(row.querySelector('.online-item-price').value) || 0;
            const qty = parseInt(row.querySelector('.online-item-qty').value) || 1;
            total += price * qty;
        });
        onlineOrderTotal.textContent = fmt(total);
    }
    window.updateOnlineOrderTotal = updateOnlineOrderTotal;

    document.querySelectorAll('.online-item-price, .online-item-qty').forEach(() => {});
    onlineItemsContainer.addEventListener('input', () => updateOnlineOrderTotal());

    if(btnSaveOnlineOrder) {
        btnSaveOnlineOrder.addEventListener('click', () => {
            const customerName = document.getElementById('online-order-customer').value.trim();
            const phone = document.getElementById('online-order-phone').value.trim();
            const address = document.getElementById('online-order-address').value.trim();
            const status = document.getElementById('online-order-status').value;
            const payment = document.getElementById('online-order-payment').value;

            const items = [];
            let total = 0;
            document.querySelectorAll('.online-order-item').forEach(row => {
                const name = row.querySelector('.online-item-name').value.trim();
                const qty = parseInt(row.querySelector('.online-item-qty').value) || 1;
                const price = parseFloat(row.querySelector('.online-item-price').value) || 0;
                if(name) { items.push({ name: name, qty: qty, price: price }); total += price * qty; }
            });

            if(!customerName || items.length === 0 || total <= 0) {
                showToast('أدخل اسم العميل ومنتج مباع بسعر صحيح على الأقل', 'error');
                return;
            }

            const now = new Date();
            const order = {
                id: onlineOrdersLog.length > 0 ? Math.max.apply(null, onlineOrdersLog.map(o => o.id)) + 1 : 1,
                customerName: customerName,
                phone: phone,
                address: address,
                items: items,
                total: total,
                status: status,
                payment: payment,
                date: now.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
                time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
                ts: Date.now()
            };
            onlineOrdersLog.push(order);
            saveOnlineOrders();
            onlineOrderModal.classList.add('hidden');
            renderOnlineOrders();
            addNotification(`طلب أونلاين جديد #${order.id} بقيمة ${fmt(total)}`, 'online');
            showToast('تم إضافة الطلب الأونلاين بنجاح', 'success');
        });
    }

    if(btnOnlineRecords) {
        btnOnlineRecords.addEventListener('click', () => {
            renderOnlineRecordsTable();
        });
    }

    function renderOnlineRecordsTable() {
        const modal = document.getElementById('online-records-modal');
        if(!modal) return;
        const tbody = document.getElementById('online-records-tbody');
        modal.classList.remove('hidden');
        if(tbody) {
            if(onlineOrdersLog.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">لا توجد طلبات مسجلة</td></tr>`;
                return;
            }
            tbody.innerHTML = '';
            [...onlineOrdersLog].sort((a, b) => (b.id || 0) - (a.id || 0)).forEach(o => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="font-weight:bold; color:var(--primary);">#${o.id}</td>
                    <td>${o.customerName || '-'}</td>
                    <td>${o.items.map(i => `${i.name} (${i.qty})`).join('، ')}</td>
                    <td style="font-weight:700;">${fmt(o.total)}</td>
                    <td><span class="status-badge" style="background:${onlineStatusColor(o.status)}22; color:${onlineStatusColor(o.status)};">${onlineStatusLabel(o.status)}</span></td>
                    <td>${o.date} ${o.time}</td>`;
                tbody.appendChild(tr);
            });
        }
    }

    if(btnClearOnlineOrders) {
        btnClearOnlineOrders.addEventListener('click', () => {
            showConfirm('مسح جميع الطلبات', 'هل أنت متأكد من مسح جميع الطلبات الأونلاين؟', () => {
                onlineOrdersLog = [];
                saveOnlineOrders();
                renderOnlineOrders();
                showToast('تم مسح جميع الطلبات', 'success');
            });
        });
    }

    // =================> 13) الملاحظات الخاصة <=================
    const privateNotesTbody = document.getElementById('private-notes-tbody');
    const privateNoteInput = document.getElementById('private-note-input');
    const btnAddPrivateNote = document.getElementById('btn-add-private-note');
    const btnClearPrivateNotes = document.getElementById('btn-clear-private-notes');
    const btnPrivateNotes = document.getElementById('btn-private-notes');
    const btnBackToNotes = document.getElementById('btn-back-to-notes');

    function renderPrivateNotes() {
        if(!privateNotesTbody) return;
        if(privateNotesLog.length === 0) {
            privateNotesTbody.innerHTML = `
                <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-lock" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    لا توجد ملاحظات خاصة.
                </td></tr>`;
            return;
        }
        privateNotesTbody.innerHTML = '';
        [...privateNotesLog].reverse().forEach(n => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="text-align:right; font-weight:600; white-space:pre-wrap;">${n.content}</td>
                <td>${n.date}</td>
                <td>${n.time}</td>
                <td><span class="status-badge" style="background:${n.status === 'completed' ? 'var(--success-bg)' : 'var(--warning-bg)'}; color:${n.status === 'completed' ? 'var(--success)' : 'var(--warning)'};">
                    ${n.status === 'completed' ? 'مكتملة' : 'نشطة'}
                </span></td>
                <td>
                    <div style="display:flex; justify-content:center; gap:10px;">
                        ${n.status !== 'completed' ? `<button class="btn-icon-only" title="تمت" onclick="window.completePrivateNote(${n.id})" style="color:var(--success); background:transparent; border:none; cursor:pointer;"><i class="fas fa-check"></i></button>` : ''}
                        <button class="btn-icon-only" title="حذف" onclick="window.deletePrivateNote(${n.id})" style="color:var(--danger); background:transparent; border:none; cursor:pointer;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>`;
            privateNotesTbody.appendChild(tr);
        });
    }

    window.completePrivateNote = function(id) {
        const n = privateNotesLog.find(x => x.id === id);
        if(n) { n.status = 'completed'; savePrivateNotes(); renderPrivateNotes(); }
    };

    window.deletePrivateNote = function(id) {
        showConfirm('حذف ملاحظة خاصة', 'هل أنت متأكد من حذف هذه الملاحظة؟', () => {
            privateNotesLog = privateNotesLog.filter(x => x.id !== id);
            savePrivateNotes();
            renderPrivateNotes();
            showToast('تم حذف الملاحظة الخاصة', 'success');
        });
    };

    if(btnAddPrivateNote) {
        btnAddPrivateNote.addEventListener('click', () => {
            const content = privateNoteInput.value.trim();
            if(!content) { showToast('اكتب الملاحظة أولاً', 'error'); return; }
            const now = new Date();
            privateNotesLog.push({ id: Date.now(), content: content, date: now.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }), time: now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }), status: 'active' });
            savePrivateNotes();
            renderPrivateNotes();
            privateNoteInput.value = '';
            showToast('تم حفظ الملاحظة الخاصة', 'success');
        });
    }

    if(btnClearPrivateNotes) {
        btnClearPrivateNotes.addEventListener('click', () => {
            showConfirm('مسح جميع الملاحظات الخاصة', 'هل أنت متأكد من مسح جميع الملاحظات الخاصة نهائياً؟', () => {
                privateNotesLog = [];
                savePrivateNotes();
                renderPrivateNotes();
                showToast('تم مسح جميع الملاحظات الخاصة', 'success');
            });
        });
    }

    // =================> 14) الملاحظات المجدولة <=================
    const scheduledNotesTbody = document.getElementById('scheduled-notes-tbody');
    const scheduledNoteInput = document.getElementById('scheduled-note-input');
    const scheduledNoteEmpSelect = document.getElementById('scheduled-note-emp-select');
    const scheduledNoteType = document.getElementById('scheduled-note-type');
    const scheduledNoteTime = document.getElementById('scheduled-note-time');
    const scheduledNoteTimeContainer = document.getElementById('scheduled-note-time-container');
    const btnAddScheduledNote = document.getElementById('btn-add-scheduled-note');
    const btnScheduledNotes = document.getElementById('btn-scheduled-notes');
    const btnBackToNotes2 = document.getElementById('btn-back-to-notes-2');

    if(scheduledNoteType) {
        scheduledNoteType.addEventListener('change', () => {
            if(scheduledNoteTimeContainer) scheduledNoteTimeContainer.style.display = scheduledNoteType.value === 'specific_time' ? 'block' : 'none';
        });
    }

    function renderScheduledNotes() {
        if(!scheduledNotesTbody) return;
        if(scheduledNotesLog.length === 0) {
            scheduledNotesTbody.innerHTML = `
                <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">
                    <i class="fas fa-calendar-alt" style="font-size: 32px; margin-bottom: 15px; display: block; opacity: 0.3;"></i>
                    لا توجد ملاحظات مجدولة.
                </td></tr>`;
            return;
        }
        scheduledNotesTbody.innerHTML = '';
        [...scheduledNotesLog].reverse().forEach(n => {
            const empName = n.empId === 'all' ? 'الجميع' : ((n.empName) || 'الجميع');
            const typeTime = n.type === 'next_shift' ? 'الشيفت القادم' : (n.targetTime ? new Date(n.targetTime).toLocaleString('ar-EG') : '-');
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="text-align:right; font-weight:600; white-space:pre-wrap;">${n.content}</td>
                <td>${empName}</td>
                <td>${typeTime}</td>
                <td><span class="status-badge" style="background:${n.isTriggered ? 'var(--success-bg)' : 'var(--warning-bg)'}; color:${n.isTriggered ? 'var(--success)' : 'var(--warning)'};">                
                    ${n.isTriggered ? 'تم النشر' : 'قيد الانتظار'}
                </span></td>
                <td>
                    <div style="display:flex; justify-content:center; gap:10px;">
                        <button class="btn-icon-only" title="اكتملت" onclick="window.completeScheduledNote(${n.id})" style="color:var(--success); background:transparent; border:none; cursor:pointer;"><i class="fas fa-check"></i></button>
                        <button class="btn-icon-only" title="حذف" onclick="window.deleteScheduledNote(${n.id})" style="color:var(--danger); background:transparent; border:none; cursor:pointer;"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>`;
            scheduledNotesTbody.appendChild(tr);
        });
    }

    window.completeScheduledNote = function(id) {
        const n = scheduledNotesLog.find(x => x.id === id);
        if(n) { n.isTriggered = true; saveScheduledNotes(); renderScheduledNotes(); showToast('تم تأكيد اكتمال الملاحظة', 'success'); }
    };

    window.deleteScheduledNote = function(id) {
        showConfirm('حذف ملاحظة مجدولة', 'هل أنت متأكد من حذف هذه الملاحظة؟', () => {
            scheduledNotesLog = scheduledNotesLog.filter(x => x.id !== id);
            saveScheduledNotes();
            renderScheduledNotes();
            showToast('تم حذف الملاحظة المجدولة', 'success');
        });
    };

    if(btnAddScheduledNote) {
        btnAddScheduledNote.addEventListener('click', () => {
            const content = scheduledNoteInput.value.trim();
            if(!content) { showToast('اكتب الملاحظة أولاً', 'error'); return; }
            let empId = scheduledNoteEmpSelect ? scheduledNoteEmpSelect.value : 'all';
            if(!empId) empId = 'all';
            const empName = empId === 'all'
                ? 'الجميع'
                : (scheduledNoteEmpSelect.options[scheduledNoteEmpSelect.selectedIndex] ? scheduledNoteEmpSelect.options[scheduledNoteEmpSelect.selectedIndex].text : 'الجميع');
            const type = scheduledNoteType ? scheduledNoteType.value : 'next_shift';
            let targetTime = null;
            if(type === 'specific_time') {
                const timeVal = scheduledNoteTime.value;
                if(!timeVal) { showToast('حدد التاريخ والوقت أولاً', 'error'); return; }
                targetTime = new Date(timeVal).getTime();
            }
            scheduledNotesLog.push({
                id: Date.now(),
                content: content,
                empId: empId,
                empName: empName,
                type: type,
                targetTime: targetTime,
                isTriggered: false,
                createdAt: Date.now()
            });
            saveScheduledNotes();
            renderScheduledNotes();
            scheduledNoteInput.value = '';
            if(scheduledNoteTime) scheduledNoteTime.value = '';
            showToast('تمت جدولة الملاحظة بنجاح', 'success');
        });
    }

    // التنقل بين عروض الملاحظات
    function showNotesView(viewId) {
        const views = ['section-notes', 'section-private-notes', 'section-scheduled-notes'];
        views.forEach(id => {
            const el = document.getElementById(id);
            if(el) el.classList.add('d-none');
        });
        const target = document.getElementById(viewId);
        if(target) target.classList.remove('d-none');
    }

    if(btnPrivateNotes) btnPrivateNotes.addEventListener('click', () => { showNotesView('section-private-notes'); renderPrivateNotes(); });
    if(btnScheduledNotes) btnScheduledNotes.addEventListener('click', () => { showNotesView('section-scheduled-notes'); renderScheduledNotes(); });
    if(btnBackToNotes) btnBackToNotes.addEventListener('click', () => showNotesView('section-notes'));
    if(btnBackToNotes2) btnBackToNotes2.addEventListener('click', () => showNotesView('section-notes'));

    // التشغيل المبدئي: رندر الأقسام الجديدة + تحديث نافذة الـ POS بالعملة
    renderDashboard();
    renderOnlineOrders();
    renderPrivateNotes();
    renderScheduledNotes();
    renderReport();
    refreshReportSummary();
    renderStats();
    renderEmployeeStats();
    renderCommissions();
    renderRecords();
    renderSalaries();
    renderReturns();
    renderExpenses();
    renderNotifications();
    loadSettings();

});

/* ==========================================================================
   تحسينات تجربة الاستخدام (إضافية — لا تؤثر على المنطق الحالي)
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {

    // إغلاق أي مودال مفتوح عند الضغط على Escape
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        document.querySelectorAll('.modal-overlay:not(.hidden)').forEach(modal => {
            modal.classList.add('hidden');
        });
    });

    // إغلاق المودال عند النقر خارج الكارت (مع استثناء مودال التأكيد)
    document.addEventListener('click', (e) => {
        const overlay = e.target.closest('.modal-overlay');
        if (!overlay || overlay.classList.contains('hidden')) return;
        if (overlay.id === 'custom-confirm-modal') return;
        if (e.target === overlay) overlay.classList.add('hidden');
    });

    // إرسال كلمة المرور بمفتاح Enter في مودال تسجيل الدخول
    const adminPassword = document.getElementById('admin-password');
    const btnLoginSubmit = document.getElementById('btn-login-submit');
    if (adminPassword) {
        adminPassword.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && btnLoginSubmit) btnLoginSubmit.click();
        });
    }

    // تركيز تلقائي على حقل كلمة المرور عند فتح مودال الدخول
    document.addEventListener('click', (e) => {
        if (e.target.closest('#btn-show-login')) {
            setTimeout(() => { if (adminPassword) adminPassword.focus(); }, 120);
        }
    });

    // منع تغيير قيم حقول الأرقام بعجلة الفأرة (تجنب الأخطاء)
    document.addEventListener('wheel', (e) => {
        if (e.target.matches('input[type="number"]')) e.target.blur();
    }, { passive: true });

});

/* ==========================================================================
   القوائم المنسدلة المخصصة (Glass Dropdown)
   تعمل فوق كل <select> بأصناف custom-input أو form-input دون تعديل المنطق:
   الحفاظ على القيمة + إطلاق حدث change (والـ inline onchange) عند الاختيار.
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {

    const SELECTOR = 'select.custom-input, select.form-input';
    let openDropdown = null;

    function closeDropdown() {
        if (!openDropdown) return;
        openDropdown.select.classList.remove('dropdown-open');
        openDropdown.el.remove();
        openDropdown = null;
    }

    function openDropdownFor(select) {
        if (select.disabled || select.offsetParent === null) return;
        if (openDropdown && openDropdown.select === select) return;

        closeDropdown();

        const list = document.createElement('div');
        list.className = 'glass-dropdown';
        list.dir = 'rtl';

        let anyEnabled = false;
        [...select.options].forEach((opt, index) => {
            const item = document.createElement('div');
            item.className = 'glass-dropdown-item';
            item.textContent = opt.text;
            item.dataset.index = index;
            if (opt.disabled) {
                item.classList.add('disabled');
            } else {
                anyEnabled = true;
                item.addEventListener('click', () => {
                    select.value = select.options[index].value;
                    closeDropdown();
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                    select.focus({ preventScroll: true });
                });
            }
            if (opt.selected) item.classList.add('selected');
            list.appendChild(item);
        });

        if (!anyEnabled) {
            const note = document.createElement('div');
            note.className = 'empty-note';
            note.textContent = 'لا توجد خيارات متاحة';
            list.appendChild(note);
        }

        document.body.appendChild(list);

        const rect = select.getBoundingClientRect();
        const width = Math.max(rect.width, 220);
        list.style.width = width + 'px';

        let left = rect.right - width;
        if (left < 10) left = 10;
        if (left + width > window.innerWidth - 10) left = Math.max(10, window.innerWidth - width - 10);

        let top = rect.bottom + 8;
        if (top + list.offsetHeight > window.innerHeight - 10) {
            top = Math.max(10, rect.top - list.offsetHeight - 8);
        }

        list.style.left = left + 'px';
        list.style.top = top + 'px';

        select.classList.add('dropdown-open');
        openDropdown = { select, el: list };
    }

    // منع قائمة المتصفح الناتيفية عند الضغط على أي قائمة مخصصة
    document.addEventListener('mousedown', (e) => {
        const target = e.target.closest ? e.target.closest(SELECTOR) : null;
        if (target && !target.disabled) e.preventDefault();
    });

    // فتح/إغلاق القائمة عند النقر، وإغلاقها عند النقر خارجها
    document.addEventListener('click', (e) => {
        const target = e.target.closest ? e.target.closest(SELECTOR) : null;
        if (target && !target.disabled) {
            if (openDropdown && openDropdown.select === target) {
                closeDropdown();
            } else {
                openDropdownFor(target);
                if (openDropdown && document.activeElement !== target) {
                    target.focus({ preventScroll: true });
                }
            }
            return;
        }
        if (openDropdown && !e.target.closest('.glass-dropdown')) closeDropdown();
    });

    // التنقل بالكيبورد (أسهم + Enter + Escape) وإبقاء سلوك الفأرة متوافقاً
    document.addEventListener('keydown', (e) => {
        const focused = e.target.closest ? e.target.closest(SELECTOR) : null;

        if (openDropdown) {
            const items = [...openDropdown.el.querySelectorAll('.glass-dropdown-item:not(.disabled)')];
            if (e.key === 'Escape') {
                e.preventDefault();
                closeDropdown();
                return;
            }
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                if (!items.length) return;
                const current = items.findIndex(i => i.classList.contains('highlighted'));
                const next = e.key === 'ArrowDown'
                    ? (current === -1 ? 0 : (current + 1) % items.length)
                    : (current === -1 ? items.length - 1 : (current - 1 + items.length) % items.length);
                items.forEach(i => i.classList.remove('highlighted'));
                items[next].classList.add('highlighted');
                items[next].scrollIntoView({ block: 'nearest' });
                return;
            }
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const highlighted = items.find(i => i.classList.contains('highlighted'));
                if (highlighted) highlighted.click();
                return;
            }
        }

        if (focused && !focused.disabled && (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === ' ' || e.key === 'Enter')) {
            e.preventDefault();
            if (openDropdown && openDropdown.select === focused) return;
            openDropdownFor(focused);
            const items = openDropdown
                ? [...openDropdown.el.querySelectorAll('.glass-dropdown-item:not(.disabled)')]
                : [];
            if (items.length) {
                const selectedIdx = items.findIndex(i => i.classList.contains('selected'));
                const hl = selectedIdx !== -1 ? selectedIdx : (e.key === 'ArrowUp' ? items.length - 1 : 0);
                items[hl].classList.add('highlighted');
                items[hl].scrollIntoView({ block: 'nearest' });
            }
        }
    });

    // إغلاق القائمة عند تغيير حجم النافذة أو تمرير الصفحة/المودال
    window.addEventListener('resize', closeDropdown);
    window.addEventListener('scroll', closeDropdown, { passive: true });
    document.addEventListener('scroll', (e) => {
        if (e.target !== document && e.target !== window) closeDropdown();
    }, { capture: true, passive: true });

});

// تنبيه عند وصول بيانات جديدة من السحابة أثناء استخدام البرنامج
window.addEventListener('dg-update-ready', () => {
    if(typeof showToast === 'function') {
        showToast('بيانات جديدة وصلت من السحابة — سيتم التحديث تلقائيًا عند الراحة', 'info');
    }
});

