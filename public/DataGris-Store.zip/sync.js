/* sync.js — المزامنة السحابية عبر Supabase (REST) */
(function() {
    'use strict';

    var CONFIG_KEY = 'syncConfig';
    var TS_PREFIX = 'syncTs:';
    var POLL_MS = 12000;

    var origSet = Storage.prototype.setItem;
    var origRemove = Storage.prototype.removeItem;
    var pending = {};
    var remoteTs = {};
    var config = null;
    var pollTimer = null;
    var syncing = false;
    var lastReload = 0;
    var pendingReload = null;
    // فترة سماح عند فتح الصفحة: لا نعيد التحميل في أول 20 ثانية على الإطلاق
    try { lastReload = Date.now(); } catch(e) {}

    function loadConfig() {
        try { return JSON.parse(localStorage.getItem(CONFIG_KEY)); } catch(e) { return null; }
    }

    function isoToMs(iso) {
        var t = Date.parse(iso);
        return isNaN(t) ? 0 : t;
    }

    function api(path, opts) {
        opts = opts || {};
        var headers = Object.assign({
            'apikey': config.anonKey,
            'Authorization': 'Bearer ' + config.anonKey,
            'Content-Type': 'application/json'
        }, opts.headers || {});
        return fetch(config.url + '/rest/v1/' + path, Object.assign({}, opts, { headers: headers }));
    }

    function pull() {
        if(!config || syncing) return Promise.resolve(false);
        return api('kv?select=id,data,updated_at&store_id=eq.' + encodeURIComponent(config.storeId))
            .then(function(r) {
                if(!r.ok) throw new Error('HTTP ' + r.status);
                return r.json();
            })
            .then(function(rows) {
                var changed = false;
                var prefix = config.storeId + ':';
                (rows || []).forEach(function(row) {
                    var remote = isoToMs(row.updated_at);
                    var bare = String(row.id || '').slice(prefix.length);
                    if(!bare) return;
                    remoteTs[bare] = remote;
                    var local = Number(localStorage.getItem(TS_PREFIX + bare) || 0);
                    if(remote > local) {
                        var val = typeof row.data === 'string' ? row.data : JSON.stringify(row.data);
                        origSet.call(localStorage, bare, val);
                        origSet.call(localStorage, TS_PREFIX + bare, String(remote));
                        changed = true;
                    }
                });
                return changed;
            })
            .catch(function(err) {
                console.warn('[sync] pull failed:', err && err.message);
                return false;
            });
    }

    function toJsonb(v) {
        if(v === null) return null;
        try { return JSON.parse(v); } catch(e) { return '"' + v.replace(/"/g, '\\"') + '"'; }
    }

    function flush() {
        if(!config || syncing) return Promise.resolve(false);
        var keys = Object.keys(pending);
        if(keys.length === 0) return Promise.resolve(false);
        syncing = true;
        var upserts = [], deletes = [];
        keys.forEach(function(k) {
            if(remoteTs[k] && pending[k].ts <= remoteTs[k]) return;
            if(pending[k].value === '__REMOVED__') {
                deletes.push(k);
            } else {
                upserts.push({
                    id: config.storeId + ':' + k,
                    store_id: config.storeId,
                    data: toJsonb(pending[k].value),
                    updated_at: new Date(pending[k].ts).toISOString()
                });
            }
        });
        function done(ok) { syncing = false; return ok; }
        function sendUpserts() {
            if(upserts.length === 0) return Promise.resolve(true);
            return api('kv?on_conflict=id', {
                method: 'POST',
                headers: { 'Prefer': 'resolution=merge-duplicates,return=minimal' },
                body: JSON.stringify(upserts)
            }).then(function(r) {
                if(!r.ok) throw new Error('HTTP ' + r.status);
                return true;
            });
        }
        function sendDeletes() {
            if(deletes.length === 0) return Promise.resolve(true);
            var conds = deletes.map(function(k) { return 'id=eq.' + encodeURIComponent(config.storeId + ':' + k); }).join(',');
            return api('kv?store_id=eq.' + encodeURIComponent(config.storeId) + '&or=(' + conds + ')', {
                method: 'DELETE',
                headers: { 'Prefer': 'return=minimal' }
            }).then(function(r) {
                if(!r.ok) throw new Error('HTTP ' + r.status);
                return true;
            });
        }
        return sendUpserts()
            .catch(function(err) { console.warn('[sync] flush failed:', err && err.message); return false; })
            .then(function(ok) {
                if(!ok) return done(false);
                return sendDeletes().then(function(ok2) { return done(ok2); });
            })
            .catch(function(err) { console.warn('[sync] flush failed:', err && err.message); return done(false); })
            .then(function(ok) {
                if(ok) keys.forEach(function(k) { delete pending[k]; });
                return ok;
            });
    }

    Storage.prototype.setItem = function(k, v) {
        origSet.call(this, k, v);
        if(this === localStorage && k !== CONFIG_KEY && k.indexOf(TS_PREFIX) !== 0) {
            pending[k] = { value: String(v), ts: Date.now() };
        }
    };
    Storage.prototype.removeItem = function(k) {
        origRemove.call(this, k);
        if(this === localStorage && k !== CONFIG_KEY && k.indexOf(TS_PREFIX) !== 0) {
            pending[k] = { value: '__REMOVED__', ts: Date.now() };
        }
    };

    function cycle() {
        if(!config) return Promise.resolve(false);
        return pull().then(function(changed) {
            if(changed && window.__appBusy) {
                // أثناء استخدام التطبيق: لا نعيد التحميل إطلاقًا
                if(!pendingReload) {
                    pendingReload = setTimeout(function() {
                        pendingReload = null;
                        if(!window.__appBusy) location.reload();
                    }, 45000);
                    try {
                        window.dispatchEvent(new CustomEvent('dg-update-ready'));
                    } catch(e) {}
                }
            } else if(changed) {
                // على شاشة الترحيب/الضيف: إعادة تحميل آمنة (بـ فاصل زمني)
                var now = Date.now();
                if(!lastReload || now - lastReload > 20000) {
                    lastReload = now;
                    location.reload();
                    return true;
                }
            }
            return flush();
        });
    }

    function start() {
        if(pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(cycle, POLL_MS);
    }

    window.Sync = {
        configured: function() { return !!loadConfig(); },
        getConfig: function() { return loadConfig(); },
        setConfig: function(c, cb) {
            var cfg = c || {};
            var gen = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
            config = {
                url: String(cfg.url || '').trim().replace(/\/+$/, ''),
                anonKey: String(cfg.anonKey || '').trim(),
                storeId: (String(cfg.storeId || '').trim() || ('dg_' + gen)),
                storeName: String(cfg.storeName || '').trim()
            };
            origSet.call(localStorage, CONFIG_KEY, JSON.stringify(config));
            start();
            cycle().then(function(ok) {
                if(cb) cb(ok);
            });
        },
        disable: function() {
            if(pollTimer) { clearInterval(pollTimer); pollTimer = null; }
            config = null;
            origRemove.call(localStorage, CONFIG_KEY);
        },
        test: function(cb) {
            if(!config) { if(cb) cb(false); return; }
            pull().then(function(ok) { if(cb) cb(ok); });
        },
        status: function() {
            return config ? 'on' : 'off';
        },
        cycle: cycle
    };

    document.addEventListener('DOMContentLoaded', function() {
        if(window.__SYNC_CONFIG && !config) {
            config = {
                url: String(window.__SYNC_CONFIG.url || '').trim().replace(/\/+$/, ''),
                anonKey: String(window.__SYNC_CONFIG.anonKey || '').trim(),
                storeId: String(window.__SYNC_CONFIG.storeId || '').trim() || ('dg_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8)),
                storeName: String(window.__SYNC_CONFIG.storeName || '').trim()
            };
            origSet.call(localStorage, CONFIG_KEY, JSON.stringify(config));
            start();
            setTimeout(function() { cycle(); }, 1800);
        }
        if(config) {
            setTimeout(function() {
                cycle();
            }, 1800);
        }

        var elUrl = document.getElementById('sync-url');
        var elAnon = document.getElementById('sync-anon');
        var elStore = document.getElementById('sync-store');
        var elStoreId = document.getElementById('sync-store-id');
        var elStatus = document.getElementById('sync-status');
        var elBtnSave = document.getElementById('btn-sync-save');
        var elBtnTest = document.getElementById('btn-sync-test');
        var elBtnDisable = document.getElementById('btn-sync-disable');

        if(elStatus && config) {
            elStatus.textContent = '✅ متصل';
            elStatus.style.color = '#16a34a';
        }

        function renderStatus(txt, color) {
            if(!elStatus) return;
            elStatus.textContent = txt;
            elStatus.style.color = color || '#334155';
        }

        if(elBtnSave && elUrl && elAnon) {
            elBtnSave.addEventListener('click', function() {
                var url = elUrl.value.trim();
                var anon = elAnon.value.trim();
                if(!url || !anon) { renderStatus('أدخل الرابط ومفتاح الاتصال أولاً', '#dc2626'); return; }
                renderStatus('جارٍ الاتصال...', '#d97706');
                var cfg = {
                    url: url,
                    anonKey: anon,
                    storeName: elStore ? elStore.value.trim() : '',
                    storeId: elStoreId ? elStoreId.value.trim() : ''
                };
                window.Sync.setConfig(cfg, function(ok) {
                    renderStatus(ok ? '✅ متصل وتمت المزامنة' : '⚠️ تم الحفظ لكن الاتصال فشل — تأكد من الرابط والمفتاح', ok ? '#16a34a' : '#d97706');
                    if(elStoreId && !elStoreId.value) elStoreId.value = config.storeId;
                });
            });
        }

        if(elBtnTest) {
            elBtnTest.addEventListener('click', function() {
                if(!window.Sync.configured()) { renderStatus('لا يوجد اتصال مفعل — احفظ الإعدادات أولاً', '#dc2626'); return; }
                window.Sync.test(function(ok) {
                    renderStatus(ok ? '✅ الاتصال ناجح' : '❌ فشل الاتصال', ok ? '#16a34a' : '#dc2626');
                });
            });
        }

        if(elBtnDisable) {
            elBtnDisable.addEventListener('click', function() {
                window.Sync.disable();
                renderStatus('تم تعطيل المزامنة', '#334155');
            });
        }
    });
})();